package com.mnshot.studio;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.os.Build;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import android.os.Environment;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.database.Cursor;
import android.graphics.Bitmap;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

public class MainActivity extends Activity {
    private android.webkit.PermissionRequest pendingPerm;
    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 78) js("if(window.onMediaPermission)window.onMediaPermission(" + hasMediaAccess() + ")");
        if (code == 77 && pendingPerm != null) {
            if (res.length > 0 && res[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) pendingPerm.grant(pendingPerm.getResources());
            else pendingPerm.deny();
            pendingPerm = null;
        }
    }

    private static final int FILE_CHOOSER_REQUEST = 4107;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private File mp4InputFile;
    private FileOutputStream mp4InputStream;
    private volatile Transformer mp4Transformer;
    private volatile boolean nativeMp4Cancelled = false;
    private volatile Uri lastSavedUri = null;
    private volatile ArrayList<Uri> pendingPick = null;
    private final java.util.concurrent.ExecutorService thumbExec = java.util.concurrent.Executors.newFixedThreadPool(2);

    private final class NativeMp4Bridge {
        @JavascriptInterface public synchronized boolean beginMp4Export() {
            try {
                if (mp4Transformer != null || mp4InputStream != null) return false;
                nativeMp4Cancelled = false;
                mp4InputFile = new File(getCacheDir(), "mnshot-input-" + System.currentTimeMillis() + ".webm");
                mp4InputStream = new FileOutputStream(mp4InputFile);
                return true;
            } catch (IOException e) { notifyWeb(false, "Could not prepare MP4 conversion: " + e.getMessage()); return false; }
        }
        @JavascriptInterface public synchronized boolean appendMp4Chunk(String base64) {
            try {
                if (mp4InputStream == null) return false;
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                mp4InputStream.write(bytes);
                return true;
            } catch (Exception e) { notifyWeb(false, "Could not transfer video data: " + e.getMessage()); return false; }
        }
        @JavascriptInterface public synchronized void finishMp4Export() {
            try {
                if (mp4InputStream == null || mp4InputFile == null) throw new IOException("No video data received");
                mp4InputStream.flush(); mp4InputStream.close(); mp4InputStream = null;
                runOnUiThread(() -> convertWebmToMp4(mp4InputFile));
            } catch (Exception e) { notifyWeb(false, "Could not finish video transfer: " + e.getMessage()); }
        }
        @JavascriptInterface public synchronized void abortMp4Export() {
            try { if (mp4InputStream != null) mp4InputStream.close(); } catch (IOException ignored) {}
            mp4InputStream = null;
            if (mp4InputFile != null) mp4InputFile.delete();
            mp4InputFile = null;
        }
        @JavascriptInterface public boolean shareLastVideo(final String pkg) {
            final Uri uri = lastSavedUri;
            if (uri == null) return false;
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("video/mp4");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    if (pkg != null && !pkg.isEmpty()) {
                        Intent direct = new Intent(send);
                        direct.setPackage(pkg);
                        startActivity(direct);
                    } else {
                        startActivity(Intent.createChooser(send, "Share video"));
                    }
                } catch (Exception first) {
                    try { startActivity(Intent.createChooser(send, "Share video")); }
                    catch (Exception ignored) { notifyWeb(false, "Sharing is not available on this device."); }
                }
            });
            return true;
        }
        @JavascriptInterface public void cancelNativeMp4Export() {
            nativeMp4Cancelled = true;
            Transformer active = mp4Transformer;
            if (active != null) {
                try { active.cancel(); } catch (Exception ignored) {}
            } else {
                abortMp4Export();
                notifyWeb(false, "MP4 conversion cancelled.");
            }
        }
    }

    private void js(final String code) {
        if (webView == null) return;
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(code, null); });
    }

    private boolean hasMediaAccess() {
        if (Build.VERSION.SDK_INT >= 33) {
            android.content.pm.PackageManager pm = getPackageManager();
            if (checkSelfPermission("android.permission.READ_MEDIA_VIDEO") == android.content.pm.PackageManager.PERMISSION_GRANTED) return true;
            if (checkSelfPermission("android.permission.READ_MEDIA_IMAGES") == android.content.pm.PackageManager.PERMISSION_GRANTED) return true;
            return Build.VERSION.SDK_INT >= 34 && checkSelfPermission("android.permission.READ_MEDIA_VISUAL_USER_SELECTED") == android.content.pm.PackageManager.PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= 23) return checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED;
        return true;
    }

    private String mediaSelection(String kind, String album, ArrayList<String> args) {
        String type;
        if ("image".equals(kind)) type = "media_type=1";
        else if ("all".equals(kind)) type = "(media_type=1 OR media_type=3)";
        else type = "media_type=3";
        if (album != null && !album.isEmpty()) { args.add(album); return type + " AND bucket_display_name=?"; }
        return type;
    }

    private Cursor queryMedia(String[] proj, String sel, String[] args, String sort, int limit, int offset) {
        Uri uri = MediaStore.Files.getContentUri("external");
        ContentResolver cr = getContentResolver();
        if (Build.VERSION.SDK_INT >= 26) {
            Bundle b = new Bundle();
            b.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel);
            if (args != null) b.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
            b.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort);
            if (limit > 0) { b.putInt(ContentResolver.QUERY_ARG_LIMIT, limit); b.putInt(ContentResolver.QUERY_ARG_OFFSET, offset); }
            return cr.query(uri, proj, b, null);
        }
        return cr.query(uri, proj, sel, args, limit > 0 ? sort + " LIMIT " + limit + " OFFSET " + offset : sort);
    }

    private void loadThumb(final long id, final int type) {
        String data = "";
        try {
            ContentResolver cr = getContentResolver();
            Uri u = ContentUris.withAppendedId(type == 3 ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
            Bitmap bm;
            if (Build.VERSION.SDK_INT >= 29) {
                bm = cr.loadThumbnail(u, new android.util.Size(256, 256), null);
            } else if (type == 3) {
                bm = MediaStore.Video.Thumbnails.getThumbnail(cr, id, MediaStore.Video.Thumbnails.MINI_KIND, null);
            } else {
                bm = MediaStore.Images.Thumbnails.getThumbnail(cr, id, MediaStore.Images.Thumbnails.MINI_KIND, null);
            }
            if (bm != null) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, 72, bos);
                data = "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            }
        } catch (Exception ignored) {}
        if (!data.isEmpty()) js("if(window.__mnThumb)window.__mnThumb(" + id + "," + type + ",'" + data + "')");
    }

    private final class MediaBridge {
        @JavascriptInterface public boolean hasPermission() { return hasMediaAccess(); }

        @JavascriptInterface public void requestPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < 23) { js("if(window.onMediaPermission)window.onMediaPermission(true)"); return; }
                String[] perms;
                if (Build.VERSION.SDK_INT >= 34) perms = new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"};
                else if (Build.VERSION.SDK_INT >= 33) perms = new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES"};
                else perms = new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE};
                requestPermissions(perms, 78);
            });
        }

        @JavascriptInterface public void openSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public String listAlbums(String kind) {
            JSONArray out = new JSONArray();
            Cursor c = null;
            try {
                ArrayList<String> args = new ArrayList<>();
                String sel = mediaSelection(kind, "", args);
                c = queryMedia(new String[]{"bucket_display_name"}, sel, null, "date_added DESC", 20000, 0);
                Map<String, Integer> counts = new HashMap<>();
                ArrayList<String> order = new ArrayList<>();
                if (c != null) {
                    while (c.moveToNext()) {
                        String n = c.getString(0);
                        if (n == null || n.isEmpty()) continue;
                        Integer k = counts.get(n);
                        if (k == null) { order.add(n); counts.put(n, 1); } else counts.put(n, k + 1);
                    }
                }
                for (String n : order) {
                    JSONObject o = new JSONObject();
                    o.put("n", n); o.put("c", counts.get(n));
                    out.put(o);
                }
            } catch (Exception ignored) {
            } finally { if (c != null) c.close(); }
            return out.toString();
        }

        @JavascriptInterface public String listMedia(String kind, String album, int offset, int limit) {
            JSONArray out = new JSONArray();
            ArrayList<String> args = new ArrayList<>();
            String sel = mediaSelection(kind, album, args);
            String[] a = args.isEmpty() ? null : args.toArray(new String[0]);
            String[][] projections = {
                {"_id", "media_type", "duration", "_display_name"},
                {"_id", "media_type", "_display_name"}
            };
            for (String[] proj : projections) {
                Cursor c = null;
                try {
                    c = queryMedia(proj, sel, a, "date_added DESC, _id DESC", limit, offset);
                    if (c == null) continue;
                    boolean hasDur = proj.length == 4;
                    while (c.moveToNext()) {
                        JSONObject o = new JSONObject();
                        o.put("id", c.getLong(0));
                        o.put("type", c.getInt(1));
                        o.put("dur", hasDur ? c.getLong(2) : 0);
                        out.put(o);
                    }
                    return out.toString();
                } catch (Exception ignored) {
                } finally { if (c != null) c.close(); }
            }
            return out.toString();
        }

        @JavascriptInterface public void requestThumbs(String json) {
            try {
                JSONArray arr = new JSONArray(json);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    final long id = o.getLong("id");
                    final int type = o.getInt("type");
                    thumbExec.execute(() -> loadThumb(id, type));
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public boolean setPicked(String json) {
            try {
                JSONArray arr = new JSONArray(json);
                ArrayList<Uri> list = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    long id = o.getLong("id");
                    int type = o.getInt("type");
                    Uri baseUri = type == 3 ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    list.add(ContentUris.withAppendedId(baseUri, id));
                }
                pendingPick = list.isEmpty() ? null : list;
                return true;
            } catch (Exception e) { pendingPick = null; return false; }
        }

        @JavascriptInterface public boolean saveImage(String base64, String name) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                String fname = ((name == null || name.isEmpty()) ? "MN_SHOT_frame" : name) + "-" + System.currentTimeMillis() + ".png";
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, fname);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MN SHOT");
                    Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                    if (u == null) return false;
                    try (OutputStream out = getContentResolver().openOutputStream(u)) {
                        if (out == null) return false;
                        out.write(bytes);
                    }
                    return true;
                }
                File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                if (dir == null) dir = getFilesDir();
                if (!dir.exists() && !dir.mkdirs()) return false;
                try (OutputStream out = new FileOutputStream(new File(dir, fname))) { out.write(bytes); }
                return true;
            } catch (Exception e) { return false; }
        }
    }

    private void notifyWebProgress(String message) {
        if (webView == null) return;
        String safe = message == null ? "" : message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ");
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.onNativeMp4Progress)window.onNativeMp4Progress('" + safe + "')", null); });
    }

    private void notifyWeb(boolean success, String message) {
        if (webView == null) return;
        String safe = message == null ? "" : message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ");
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.onNativeMp4Result)window.onNativeMp4Result(" + success + ", '" + safe + "')", null); });
    }

    private void convertWebmToMp4(File input) {
        try {
            nativeMp4Cancelled = false;
            File output = new File(getCacheDir(), "MN_Cut_export-" + System.currentTimeMillis() + ".mp4");
            if (output.exists()) output.delete();
            mp4Transformer = new Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(new Transformer.Listener() {
                    @Override public void onCompleted(Composition composition, ExportResult exportResult) {
                        try {
                            if (nativeMp4Cancelled) {
                                notifyWeb(false, "MP4 conversion cancelled.");
                            } else if (!output.isFile() || output.length() == 0) {
                                throw new IOException("Converter returned an empty MP4 file");
                            } else {
                                Uri saved = publishMp4(output);
                                lastSavedUri = saved;
                                notifyWeb(true, "MP4 saved to Downloads: " + saved.getLastPathSegment());
                            }
                        } catch (Exception e) { notifyWeb(false, "MP4 could not be saved: " + e.getMessage()); }
                        finally { input.delete(); output.delete(); mp4Transformer = null; }
                    }
                    @Override public void onError(Composition composition, ExportResult exportResult, ExportException exportException) {
                        try {
                            if (nativeMp4Cancelled) notifyWeb(false, "MP4 conversion cancelled.");
                            else notifyWeb(false, "This device could not convert the video to MP4: " + exportException.getMessage());
                        } finally { input.delete(); output.delete(); mp4Transformer = null; }
                    }
                }).build();
            EditedMediaItem item = new EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input))).build();
            mp4Transformer.start(item, output.getAbsolutePath());
            notifyWebProgress("Android MP4 conversion started. Keep MN SHOT open.");
        } catch (Exception e) {
            input.delete();
            mp4Transformer = null;
            notifyWeb(false, "MP4 conversion could not start: " + e.getMessage());
        }
    }

    private Uri publishMp4(File source) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, "MN_Cut_export-" + System.currentTimeMillis() + ".mp4");
            values.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Downloads folder is unavailable");
            try {
                try (InputStream in = new FileInputStream(source); OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Could not open Downloads output");
                    byte[] buffer = new byte[64 * 1024]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }
                values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                return uri;
            } catch (IOException e) {
                getContentResolver().delete(uri, null, null);
                throw e;
            }
        }
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = getFilesDir();
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create app Downloads folder");
        File dest = new File(dir, "MN_Cut_export-" + System.currentTimeMillis() + ".mp4");
        try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(dest)) {
            byte[] buffer = new byte[64 * 1024]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        }
        return Uri.fromFile(dest);
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        getWindow().setStatusBarColor(Color.rgb(23, 19, 28));
        getWindow().setNavigationBarColor(Color.rgb(23, 19, 28));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(23, 19, 28));
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep the editor self-contained; do not navigate away from its local assets.
                return !"file".equals(request.getUrl().getScheme());
            }
        });
        webView.addJavascriptInterface(new NativeMp4Bridge(), "MNCutNativeMp4");
        webView.addJavascriptInterface(new MediaBridge(), "MNCutMedia");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final android.webkit.PermissionRequest r) {
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        pendingPerm = r;
                        requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 77);
                    } else r.grant(r.getResources());
                });
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
                ArrayList<Uri> pend = pendingPick;
                pendingPick = null;
                if (pend != null && !pend.isEmpty()) {
                    callback.onReceiveValue(pend.toArray(new Uri[0]));
                    return true;
                }
                fileCallback = callback;
                boolean multiple = params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE;
                String type = "*/*";
                String[] mimes = null;
                try {
                    String[] accept = params == null ? null : params.getAcceptTypes();
                    ArrayList<String> clean = new ArrayList<>();
                    if (accept != null) for (String s : accept) {
                        if (s == null) continue;
                        for (String part : s.split(",")) { String p = part.trim(); if (!p.isEmpty() && p.indexOf('/') > 0) clean.add(p); }
                    }
                    if (clean.size() == 1) type = clean.get(0);
                    else if (clean.size() > 1) mimes = clean.toArray(new String[0]);
                } catch (Exception ignored) {}
                try {
                    Intent open = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    open.addCategory(Intent.CATEGORY_OPENABLE);
                    open.setType(type);
                    if (mimes != null) open.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
                    open.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
                    open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(open, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception first) {
                    try {
                        Intent get = new Intent(Intent.ACTION_GET_CONTENT);
                        get.addCategory(Intent.CATEGORY_OPENABLE);
                        get.setType(type);
                        if (mimes != null) get.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
                        get.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
                        startActivityForResult(get, FILE_CHOOSER_REQUEST);
                        return true;
                    } catch (Exception second) {
                        fileCallback = null;
                        callback.onReceiveValue(null);
                        return false;
                    }
                }
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] result = parsePicked(resultCode, data);
            if (fileCallback != null) {
                fileCallback.onReceiveValue(result);
                fileCallback = null;
                if (resultCode == RESULT_OK && result == null) diag("Picker returned no file. [" + String.valueOf(data) + "]");
            } else {
                diag("Picker result was lost because the app restarted while choosing. Please try again.");
            }
        }
    }

    private Uri[] parsePicked(int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null) return null;
        java.util.ArrayList<Uri> out = new java.util.ArrayList<>();
        android.content.ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                Uri u = clip.getItemAt(i).getUri();
                if (u != null) out.add(u);
            }
        }
        if (out.isEmpty() && data.getData() != null) out.add(data.getData());
        if (out.isEmpty()) {
            try {
                Uri s = (Uri) data.getParcelableExtra(Intent.EXTRA_STREAM);
                if (s != null) out.add(s);
            } catch (Exception ignored) {}
        }
        return out.isEmpty() ? null : out.toArray(new Uri[0]);
    }

    private void diag(String message) {
        if (webView == null) return;
        String safe = message.replace("\\", "\\\\").replace("'", "\\'");
        webView.evaluateJavascript("if(window.__mnDiag)window.__mnDiag('" + safe + "')", null);
    }

    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("(window.__mnBack && window.__mnBack()) ? '1' : '0'", value -> {
            if (value == null || !value.contains("1")) super.onBackPressed();
        });
    }

    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (mp4Transformer != null) { try { mp4Transformer.cancel(); } catch (Exception ignored) {} mp4Transformer = null; }
        if (mp4InputStream != null) { try { mp4InputStream.close(); } catch (IOException ignored) {} mp4InputStream = null; }
        if (mp4InputFile != null) { mp4InputFile.delete(); mp4InputFile = null; }
        try { thumbExec.shutdownNow(); } catch (Exception ignored) {}
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
