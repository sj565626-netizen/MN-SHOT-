package com.mnshot.studio.model

import android.net.Uri
import java.util.UUID

enum class AppScreen { HOME, PICKER, EDITOR, COLLAGE, EXPORT, PROGRESS }
enum class PickerMode { VIDEO, PHOTO, ALL }

enum class AspectRatioOption(val label: String, val ratio: Float) {
    ORIGINAL("Original", 0f),
    PORTRAIT_9_16("9:16", 9f / 16f),
    SQUARE_1_1("1:1", 1f),
    LANDSCAPE_16_9("16:9", 16f / 9f),
    PORTRAIT_4_5("4:5", 4f / 5f),
    CINEMA_21_9("21:9", 21f / 9f)
}

enum class FilterPreset(val title: String, val brightness: Float, val contrast: Float, val saturation: Float) {
    NONE("Original", 0f, 1f, 1f),
    VIVID("Vivid", 0.04f, 1.18f, 1.35f),
    WARM("Warm", 0.03f, 1.06f, 1.15f),
    COOL("Cool", 0f, 1.08f, 0.90f),
    CINEMA("Cinema", -0.04f, 1.25f, 0.85f),
    BW("B&W", 0.02f, 1.22f, 0f),
    FADE("Fade", 0.08f, 0.84f, 0.82f)
}

enum class MaskShape(val title: String) {
    NONE("None"),
    ROUNDED("Rounded"),
    CIRCLE("Circle")
}

enum class EditorTool(val title: String) {
    CANVAS("Canvas"),
    TRIM("Split/Trim"),
    SPEED("Speed"),
    FILTER("Filter"),
    ADJUST("Adjust"),
    TEXT("Text"),
    STICKER("Sticker"),
    PIP("PIP"),
    MUSIC("Music"),
    VOLUME("Volume"),
    CROP("Zoom/Crop"),
    MASK("Mask"),
    OPACITY("Opacity"),
    ROTATE("Rotate"),
    FLIP("Flip"),
    DUPLICATE("Duplicate"),
    DELETE("Delete")
}

data class MediaAsset(
    val id: Long,
    val uri: Uri,
    val isVideo: Boolean,
    val durationMs: Long,
    val albumName: String
)

data class VideoClip(
    val id: String = UUID.randomUUID().toString(),
    val uri: Uri,
    val isVideo: Boolean = true,
    val sourceDurationMs: Long,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = sourceDurationMs,
    val speed: Float = 1.0f,
    val volume: Float = 1.0f,
    val rotationDeg: Float = 0f,
    val flipH: Boolean = false,
    val zoomScale: Float = 1.0f,
    val opacity: Float = 1.0f,
    val maskShape: MaskShape = MaskShape.NONE,
    val filter: FilterPreset = FilterPreset.NONE,
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f
) {
    val effectiveDurationMs: Long
        get() = (((trimEndMs - trimStartMs).coerceAtLeast(200L)) / speed).toLong()
}

data class OverlayItem(
    val id: String = UUID.randomUUID().toString(),
    val isSticker: Boolean = false,
    val pipUri: Uri? = null,
    val text: String = "",
    val colorHex: Long = 0xFFFFFFFF,
    val bgColorHex: Long = 0x00000000,
    val fontSizeSp: Float = 28f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val scale: Float = 1f,
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    val startMs: Long = 0L,
    val endMs: Long = 5000L
)

data class AudioTrackItem(
    val id: String = UUID.randomUUID().toString(),
    val uri: Uri,
    val title: String,
    val volume: Float = 0.85f
)

data class ProjectState(
    val title: String = "MN SHOT Project",
    val aspectRatio: AspectRatioOption = AspectRatioOption.PORTRAIT_9_16,
    val backgroundColor: Long = 0xFF141418,
    val clips: List<VideoClip> = emptyList(),
    val overlays: List<OverlayItem> = emptyList(),
    val audioTrack: AudioTrackItem? = null,
    val selectedClipIndex: Int = 0,
    val selectedOverlayId: String? = null
) {
    val totalDurationMs: Long
        get() = clips.sumOf { it.effectiveDurationMs }
}
