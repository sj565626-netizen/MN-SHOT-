package com.mnshot.studio

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mnshot.studio.engine.EditorViewModel
import com.mnshot.studio.model.AppScreen
import com.mnshot.studio.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: EditorViewModel = viewModel()
            val permLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) { vm.refreshGallery() }

            LaunchedEffect(Unit) {
                val perms = if (Build.VERSION.SDK_INT >= 33) {
                    arrayOf(
                        Manifest.permission.READ_MEDIA_VIDEO,
                        Manifest.permission.READ_MEDIA_IMAGES,
                        Manifest.permission.READ_MEDIA_AUDIO
                    )
                } else {
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
                permLauncher.launch(perms)
            }

            BackHandler(enabled = vm.currentScreen != AppScreen.HOME) {
                vm.currentScreen = when (vm.currentScreen) {
                    AppScreen.EXPORT -> AppScreen.EDITOR
                    AppScreen.PROGRESS -> AppScreen.EXPORT
                    AppScreen.PICKER -> if (vm.appendOnPick || vm.pickingForPip) AppScreen.EDITOR else AppScreen.HOME
                    else -> AppScreen.HOME
                }
            }

            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color(0xFF141418),
                    surface = Color(0xFF222227),
                    primary = Color(0xFF7C5CFF),
                    secondary = Color(0xFF22D3EE)
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF141418)) {
                    when (vm.currentScreen) {
                        AppScreen.HOME -> HomeScreen(vm)
                        AppScreen.PICKER -> MediaPickerScreen(vm)
                        AppScreen.EDITOR -> NativeEditorScreen(vm)
                        AppScreen.COLLAGE -> CollageScreen(vm)
                        AppScreen.EXPORT -> ExportSettingsScreen(vm)
                        AppScreen.PROGRESS -> ExportProgressScreen(vm)
                    }
                }
            }
        }
    }
}
