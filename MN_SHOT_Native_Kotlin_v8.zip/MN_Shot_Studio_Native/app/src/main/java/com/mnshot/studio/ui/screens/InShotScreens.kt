package com.mnshot.studio.ui.screens

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import coil.request.ImageRequest
import com.mnshot.studio.engine.EditorViewModel
import com.mnshot.studio.model.*
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(vm: EditorViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFDFF6FF), Color(0xFFB7D4FF), Color(0xFFA595FF), Color(0xFF8A74F5))
                )
            )
            .statusBarsPadding()
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(Color(0xFF171533)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("MN", color = Color(0xFF22D3EE), fontWeight = FontWeight.Black, fontSize = 14.sp)
                }
                Spacer(Modifier.width(10.dp))
                Text("MN SHOT", fontSize = 23.sp, fontWeight = FontWeight.Black, color = Color(0xFF171533))
            }
            Surface(color = Color(0xFF171533), shape = RoundedCornerShape(12.dp)) {
                Text(
                    "NATIVE 8.0",
                    color = Color(0xFF22D3EE),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }

        Spacer(Modifier.height(34.dp))
        Text("Cut. Shape. Shoot.", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF171533))
        Text("100% Native Kotlin video & photo studio.", fontSize = 15.sp, color = Color(0xFF2E2A5C))

        Spacer(Modifier.height(28.dp))
        Text("CREATE NEW", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF171533))
        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Color.White.copy(alpha = 0.90f))
                .padding(18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            CreateActionButton("Video", Icons.Default.Videocam, Color(0xFF7C5CFF)) {
                vm.openPicker(PickerMode.VIDEO)
            }
            CreateActionButton("Photo", Icons.Default.Photo, Color(0xFF22D3EE)) {
                vm.openPicker(PickerMode.PHOTO)
            }
            CreateActionButton("Collage", Icons.Default.GridView, Color(0xFF19D17A)) {
                vm.openPicker(PickerMode.PHOTO)
            }
        }

        Spacer(Modifier.height(24.dp))
        Surface(
            color = Color(0xFF171533).copy(alpha = 0.92f),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("WHAT'S NEW IN NATIVE EDITION", color = Color(0xFF22D3EE), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("• Zero WebView lag — ExoPlayer 60fps live preview", color = Color.White, fontSize = 13.sp)
                Text("• Direct Hardware MP4 Export via Media3 Transformer", color = Color.White, fontSize = 13.sp)
                Text("• Multi-clip Timeline, Speed, PIP, Text & Stickers", color = Color.White, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun CreateActionButton(label: String, icon: ImageVector, tint: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Box(
            modifier = Modifier.size(62.dp).clip(RoundedCornerShape(18.dp)).background(tint),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, fontWeight = FontWeight.Bold, color = Color(0xFF171533), fontSize = 14.sp)
    }
}

@Composable
fun MediaPickerScreen(vm: EditorViewModel) {
    val context = LocalContext.current
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF141418)).statusBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = {
                vm.currentScreen = if (vm.appendOnPick || vm.pickingForPip) AppScreen.EDITOR else AppScreen.HOME
            }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text(if (vm.pickingForPip) "SELECT PIP OVERLAY" else "SELECT MEDIA", fontWeight = FontWeight.Bold, color = Color.White)
            Button(
                onClick = { vm.confirmSelectionToEditor() },
                enabled = vm.selectedAssets.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF))
            ) {
                Text("Next (${vm.selectedAssets.size})")
            }
        }

        if (!vm.pickingForPip) {
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PickerMode.entries.forEach { mode ->
                    FilterChip(
                        selected = vm.pickerMode == mode,
                        onClick = { vm.openPicker(mode, vm.appendOnPick, false) },
                        label = { Text(mode.name) }
                    )
                }
            }
        }

        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(vm.albums) { album ->
                FilterChip(
                    selected = vm.selectedAlbum == album,
                    onClick = { vm.selectedAlbum = album },
                    label = { Text(album, fontSize = 12.sp) }
                )
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(vm.filteredAssets, key = { it.id }) { asset ->
                val selIdx = vm.selectedAssets.indexOfFirst { it.id == asset.id }
                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .border(if (selIdx >= 0) 2.dp else 0.dp, Color(0xFF22D3EE), RoundedCornerShape(8.dp))
                        .clickable { vm.toggleAssetSelection(asset) }
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(asset.uri)
                            .decoderFactory(VideoFrameDecoder.Factory())
                            .crossfade(true)
                            .build(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (asset.isVideo) {
                        Text(
                            formatMs(asset.durationMs),
                            color = Color.White,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                    if (selIdx >= 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(4.dp)
                                .size(22.dp)
                                .background(Color(0xFF7C5CFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("${selIdx + 1}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NativeEditorScreen(vm: EditorViewModel) {
    val context = LocalContext.current
    val currentClip = vm.project.clips.getOrNull(vm.project.selectedClipIndex)
    var showTextDialog by remember { mutableStateOf(false) }
    var textDraft by remember { mutableStateOf("") }
    var selectedTextColor by remember { mutableStateOf(0xFFFFFFFF) }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setBackgroundMusic(uri)
    }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
        }
    }

    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    LaunchedEffect(currentClip?.id, currentClip?.uri) {
        currentClip?.let { clip ->
            if (clip.isVideo) {
                exoPlayer.setMediaItem(MediaItem.fromUri(clip.uri))
                exoPlayer.prepare()
                exoPlayer.seekTo(clip.trimStartMs)
            } else {
                exoPlayer.pause()
            }
        }
    }

    LaunchedEffect(vm.isPlaying, currentClip?.speed, currentClip?.volume) {
        exoPlayer.setPlaybackSpeed(currentClip?.speed ?: 1f)
        exoPlayer.volume = currentClip?.volume ?: 1f
        if (vm.isPlaying && currentClip?.isVideo == true) exoPlayer.play() else exoPlayer.pause()
        while (vm.isPlaying) {
            if (currentClip?.isVideo == true) {
                vm.playheadMs = exoPlayer.currentPosition
            } else {
                vm.playheadMs = (vm.playheadMs + 33L) % (vm.project.totalDurationMs.coerceAtLeast(3000L))
            }
            delay(33L)
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF141418)).statusBarsPadding().navigationBarsPadding()) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { vm.isPlaying = false; vm.currentScreen = AppScreen.HOME }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Home", tint = Color.White)
            }
            Text(vm.project.title, color = Color.White, fontWeight = FontWeight.Bold)
            Button(
                onClick = { vm.isPlaying = false; vm.currentScreen = AppScreen.EXPORT },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF))
            ) {
                Text("Export", fontWeight = FontWeight.Bold)
            }
        }

        // Live Video & Overlay Canvas Stage
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(vm.project.backgroundColor)),
            contentAlignment = Alignment.Center
        ) {
            val aspect = if (vm.project.aspectRatio.ratio > 0f) vm.project.aspectRatio.ratio else (9f / 16f)
            val clipShape = when (currentClip?.maskShape) {
                MaskShape.CIRCLE -> CircleShape
                MaskShape.ROUNDED -> RoundedCornerShape(24.dp)
                else -> RoundedCornerShape(6.dp)
            }

            Box(
                modifier = Modifier
                    .fillMaxHeight(0.92f)
                    .aspectRatio(aspect)
                    .clip(clipShape)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (currentClip != null) {
                    val matrix = ColorMatrix().apply {
                        setToSaturation(currentClip.saturation * currentClip.filter.saturation)
                    }
                    val transformMod = Modifier
                        .fillMaxSize()
                        .alpha(currentClip.opacity)
                        .graphicsLayer(
                            rotationZ = currentClip.rotationDeg,
                            scaleX = (if (currentClip.flipH) -1f else 1f) * currentClip.zoomScale,
                            scaleY = currentClip.zoomScale
                        )

                    if (currentClip.isVideo) {
                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    player = exoPlayer
                                    useController = false
                                    layoutParams = FrameLayout.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                }
                            },
                            modifier = transformMod
                        )
                    } else {
                        AsyncImage(
                            model = currentClip.uri,
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            colorFilter = ColorFilter.colorMatrix(matrix),
                            modifier = transformMod
                        )
                    }
                }

                // Multi-touch Draggable/Pinchable Overlays (Text, Stickers, PIP)
                vm.project.overlays.forEach { ov ->
                    val isSelected = vm.project.selectedOverlayId == ov.id
                    Box(
                        modifier = Modifier
                            .graphicsLayer(
                                translationX = ov.offsetX,
                                translationY = ov.offsetY,
                                scaleX = ov.scale,
                                scaleY = ov.scale,
                                rotationZ = ov.rotation
                            )
                            .border(if (isSelected) 1.5.dp else 0.dp, Color(0xFF22D3EE), RoundedCornerShape(8.dp))
                            .pointerInput(ov.id) {
                                detectTransformGestures { _, pan, zoom, rot ->
                                    vm.project = vm.project.copy(selectedOverlayId = ov.id)
                                    vm.updateOverlay(ov.id) {
                                        it.copy(
                                            offsetX = it.offsetX + pan.x,
                                            offsetY = it.offsetY + pan.y,
                                            scale = (it.scale * zoom).coerceIn(0.25f, 5f),
                                            rotation = it.rotation + rot
                                        )
                                    }
                                }
                            }
                            .background(Color(ov.bgColorHex), RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        if (ov.pipUri != null) {
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(ov.pipUri)
                                    .decoderFactory(VideoFrameDecoder.Factory())
                                    .build(),
                                contentDescription = "PIP",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(140.dp).clip(RoundedCornerShape(10.dp))
                            )
                        } else {
                            Text(
                                ov.text,
                                color = Color(ov.colorHex),
                                fontSize = ov.fontSizeSp.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Transport Controls (Undo / Redo / Play / Time)
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row {
                IconButton(onClick = { vm.undo() }, enabled = vm.canUndo) {
                    Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo", tint = Color.White)
                }
                IconButton(onClick = { vm.redo() }, enabled = vm.canRedo) {
                    Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Redo", tint = Color.White)
                }
            }
            IconButton(
                onClick = { vm.isPlaying = !vm.isPlaying },
                modifier = Modifier.size(46.dp).background(Color(0xFF7C5CFF), CircleShape)
            ) {
                Icon(
                    if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = Color.White
                )
            }
            Text(
                "${formatMs(vm.playheadMs)} / ${formatMs(vm.project.totalDurationMs)}",
                color = Color(0xFF8C8C96),
                fontSize = 12.sp
            )
        }

        // Multi-Clip Timeline
        Row(
            modifier = Modifier.fillMaxWidth().height(74.dp).background(Color(0xFF1B1B21)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { vm.openPicker(PickerMode.ALL, append = true) },
                modifier = Modifier.size(44.dp).background(Color(0xFF2B2B31), RoundedCornerShape(10.dp))
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Clip", tint = Color.White)
            }
            Spacer(Modifier.width(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                itemsIndexed(vm.project.clips, key = { _, c -> c.id }) { index, clip ->
                    val selected = index == vm.project.selectedClipIndex
                    Box(
                        modifier = Modifier
                            .width(86.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(8.dp))
                            .border(if (selected) 2.dp else 0.dp, Color(0xFF22D3EE), RoundedCornerShape(8.dp))
                            .clickable { vm.project = vm.project.copy(selectedClipIndex = index) }
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(clip.uri)
                                .decoderFactory(VideoFrameDecoder.Factory())
                                .build(),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Text(
                            formatMs(clip.effectiveDurationMs),
                            color = Color.White,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .background(Color.Black.copy(alpha = 0.6f))
                                .padding(horizontal = 4.dp)
                        )
                    }
                }
            }
        }

        // Active Tool Parameter Sheet
        vm.activeTool?.let { tool ->
            Surface(color = Color(0xFF222227), modifier = Modifier.fillMaxWidth().padding(8.dp), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(tool.title, color = Color.White, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { vm.activeTool = null }) {
                            Icon(Icons.Default.Check, contentDescription = "Done", tint = Color(0xFF22D3EE))
                        }
                    }
                    when (tool) {
                        EditorTool.CANVAS -> LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(AspectRatioOption.entries) { opt ->
                                FilterChip(
                                    selected = vm.project.aspectRatio == opt,
                                    onClick = { vm.project = vm.project.copy(aspectRatio = opt) },
                                    label = { Text(opt.label) }
                                )
                            }
                        }
                        EditorTool.SPEED -> currentClip?.let { clip ->
                            Text("Speed: ${String.format("%.2fx", clip.speed)}", color = Color.White, fontSize = 12.sp)
                            Slider(
                                value = clip.speed,
                                onValueChange = { s -> vm.updateSelectedClip { it.copy(speed = s) } },
                                valueRange = 0.25f..4.0f
                            )
                        }
                        EditorTool.VOLUME -> currentClip?.let { clip ->
                            Text("Clip Volume: ${(clip.volume * 100).toInt()}%", color = Color.White, fontSize = 12.sp)
                            Slider(
                                value = clip.volume,
                                onValueChange = { v -> vm.updateSelectedClip { it.copy(volume = v) } },
                                valueRange = 0f..2.0f
                            )
                        }
                        EditorTool.CROP -> currentClip?.let { clip ->
                            Text("Zoom: ${String.format("%.2fx", clip.zoomScale)}", color = Color.White, fontSize = 12.sp)
                            Slider(
                                value = clip.zoomScale,
                                onValueChange = { z -> vm.updateSelectedClip { it.copy(zoomScale = z) } },
                                valueRange = 0.5f..3.0f
                            )
                        }
                        EditorTool.OPACITY -> currentClip?.let { clip ->
                            Text("Opacity: ${(clip.opacity * 100).toInt()}%", color = Color.White, fontSize = 12.sp)
                            Slider(
                                value = clip.opacity,
                                onValueChange = { o -> vm.updateSelectedClip { it.copy(opacity = o) } },
                                valueRange = 0.1f..1.0f
                            )
                        }
                        EditorTool.MASK -> LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(MaskShape.entries) { shape ->
                                FilterChip(
                                    selected = currentClip?.maskShape == shape,
                                    onClick = { vm.updateSelectedClip { it.copy(maskShape = shape) } },
                                    label = { Text(shape.title) }
                                )
                            }
                        }
                        EditorTool.FILTER -> LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(FilterPreset.entries) { preset ->
                                FilterChip(
                                    selected = currentClip?.filter == preset,
                                    onClick = { vm.updateSelectedClip { it.copy(filter = preset) } },
                                    label = { Text(preset.title) }
                                )
                            }
                        }
                        EditorTool.STICKER -> LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(listOf("🔥", "❤️", "😂", "✨", "🎬", "👑", "💯", "🚀")) { emoji ->
                                Text(
                                    emoji,
                                    fontSize = 28.sp,
                                    modifier = Modifier.clickable {
                                        vm.addTextOverlay(emoji, isSticker = true)
                                        vm.activeTool = null
                                    }
                                )
                            }
                        }
                        else -> {}
                    }
                }
            }
        }

        // InShot Bottom Tool Strip
        LazyRow(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF141418)).padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(EditorTool.entries) { tool ->
                val icon = when (tool) {
                    EditorTool.CANVAS -> Icons.Default.AspectRatio
                    EditorTool.TRIM -> Icons.Default.ContentCut
                    EditorTool.SPEED -> Icons.Default.Speed
                    EditorTool.FILTER -> Icons.Default.AutoFixHigh
                    EditorTool.ADJUST -> Icons.Default.Tune
                    EditorTool.TEXT -> Icons.Default.TextFields
                    EditorTool.STICKER -> Icons.Default.EmojiEmotions
                    EditorTool.PIP -> Icons.Default.PictureInPictureAlt
                    EditorTool.MUSIC -> Icons.Default.MusicNote
                    EditorTool.VOLUME -> Icons.Default.VolumeUp
                    EditorTool.CROP -> Icons.Default.Crop
                    EditorTool.MASK -> Icons.Default.Category
                    EditorTool.OPACITY -> Icons.Default.Opacity
                    EditorTool.ROTATE -> Icons.Default.RotateRight
                    EditorTool.FLIP -> Icons.Default.Flip
                    EditorTool.DUPLICATE -> Icons.Default.ContentCopy
                    EditorTool.DELETE -> Icons.Default.Delete
                }
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            when (tool) {
                                EditorTool.TRIM -> vm.splitSelectedClipAtPlayhead()
                                EditorTool.ROTATE -> vm.updateSelectedClip { it.copy(rotationDeg = (it.rotationDeg + 90f) % 360f) }
                                EditorTool.FLIP -> vm.updateSelectedClip { it.copy(flipH = !it.flipH) }
                                EditorTool.DUPLICATE -> vm.duplicateSelectedClip()
                                EditorTool.DELETE -> vm.deleteSelectedClip()
                                EditorTool.TEXT -> showTextDialog = true
                                EditorTool.PIP -> vm.openPicker(PickerMode.ALL, forPip = true)
                                EditorTool.MUSIC -> audioPicker.launch("audio/*")
                                else -> vm.activeTool = tool
                            }
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(icon, contentDescription = tool.title, tint = Color.White, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.height(4.dp))
                    Text(tool.title, color = Color.White, fontSize = 11.sp)
                }
            }
        }
    }

    if (showTextDialog) {
        AlertDialog(
            onDismissRequest = { showTextDialog = false },
            title = { Text("Add Text Overlay") },
            text = {
                Column {
                    OutlinedTextField(
                        value = textDraft,
                        onValueChange = { textDraft = it },
                        placeholder = { Text("Enter text...") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFF22D3EE, 0xFFFF5252, 0xFF19D17A).forEach { col ->
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color(col))
                                    .border(if (selectedTextColor == col) 2.dp else 0.dp, Color.Magenta, CircleShape)
                                    .clickable { selectedTextColor = col }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (textDraft.isNotBlank()) vm.addTextOverlay(textDraft, colorHex = selectedTextColor)
                    textDraft = ""
                    showTextDialog = false
                }) { Text("Add") }
            }
        )
    }
}

@Composable
fun CollageScreen(vm: EditorViewModel) {
    MediaPickerScreen(vm)
}

@Composable
fun ExportSettingsScreen(vm: EditorViewModel) {
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF141418)).statusBarsPadding().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.currentScreen = AppScreen.EDITOR }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text("Export Video", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(24.dp))
        Text("Resolution", color = Color.Gray)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(480, 720, 1080).forEach { h ->
                FilterChip(selected = vm.exportHeight == h, onClick = { vm.exportHeight = h }, label = { Text("${h}p") })
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Frame Rate", color = Color.Gray)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(24, 30, 60).forEach { fps ->
                FilterChip(selected = vm.exportFps == fps, onClick = { vm.exportFps = fps }, label = { Text("$fps FPS") })
            }
        }
        Spacer(Modifier.weight(1f))
        Button(
            onClick = { vm.startNativeExport() },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF))
        ) {
            Text("EXPORT MP4", fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
    }
}

@Composable
fun ExportProgressScreen(vm: EditorViewModel) {
    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF141418)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(vm.exportStatus, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        LinearProgressIndicator(progress = { vm.exportProgress / 100f }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))
        if (vm.lastExportedUri != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { vm.shareVideo("com.whatsapp") }) { Text("WhatsApp") }
                Button(onClick = { vm.shareVideo("com.zhiliaoapp.musically") }) { Text("TikTok") }
                Button(onClick = { vm.shareVideo("com.google.android.youtube") }) { Text("YouTube") }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { vm.currentScreen = AppScreen.HOME }) { Text("Done") }
        } else {
            OutlinedButton(onClick = { vm.cancelExport() }) { Text("Cancel") }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return "%d:%02d".format(min, sec)
}
