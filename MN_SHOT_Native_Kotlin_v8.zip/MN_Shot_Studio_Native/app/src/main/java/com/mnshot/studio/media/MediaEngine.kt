package com.mnshot.studio.media

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.mnshot.studio.model.MediaAsset
import com.mnshot.studio.model.PickerMode
import com.mnshot.studio.model.ProjectState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

object MediaGalleryRepository {
    suspend fun queryMedia(context: Context, mode: PickerMode, albumFilter: String? = null): List<MediaAsset> =
        withContext(Dispatchers.IO) {
            val result = mutableListOf<MediaAsset>()
            val collection = MediaStore.Files.getContentUri("external")
            val projection = arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.MEDIA_TYPE,
                MediaStore.Video.Media.DURATION,
                MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            )

            val typeSelection = when (mode) {
                PickerMode.VIDEO -> "${MediaStore.Files.FileColumns.MEDIA_TYPE}=3"
                PickerMode.PHOTO -> "${MediaStore.Files.FileColumns.MEDIA_TYPE}=1"
                PickerMode.ALL -> "(${MediaStore.Files.FileColumns.MEDIA_TYPE}=1 OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=3)"
            }
            val selection = if (!albumFilter.isNullOrBlank() && albumFilter != "All") {
                "$typeSelection AND ${MediaStore.MediaColumns.BUCKET_DISPLAY_NAME}=?"
            } else typeSelection
            val args = if (!albumFilter.isNullOrBlank() && albumFilter != "All") arrayOf(albumFilter) else null

            context.contentResolver.query(
                collection,
                projection,
                selection,
                args,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val typeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
                val durCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val albumCol = cursor.getColumnIndex(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val mediaType = cursor.getInt(typeCol)
                    val isVideo = mediaType == 3
                    val baseUri = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                                  else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    val uri = ContentUris.withAppendedId(baseUri, id)
                    val dur = if (durCol >= 0) cursor.getLong(durCol) else 0L
                    val album = if (albumCol >= 0) cursor.getString(albumCol) ?: "Recents" else "Recents"
                    result.add(MediaAsset(id, uri, isVideo, dur, album))
                }
            }
            result
        }
}

class NativeVideoExporter(private val context: Context) {
    private var activeTransformer: Transformer? = null

    @OptIn(UnstableApi::class)
    fun exportProject(
        project: ProjectState,
        targetHeight: Int,
        onProgress: (Int) -> Unit,
        onComplete: (Uri) -> Unit,
        onError: (String) -> Unit
    ) {
        if (project.clips.isEmpty()) {
            onError("No clips to export")
            return
        }

        val tempFile = File(context.cacheDir, "MN_SHOT_${System.currentTimeMillis()}.mp4")
        val editedClips = project.clips.map { clip ->
            val clipping = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(clip.trimStartMs)
                .setEndPositionMs(clip.trimEndMs)
                .build()

            val mediaItem = MediaItem.Builder()
                .setUri(clip.uri)
                .setClippingConfiguration(clipping)
                .build()

            val videoEffects = mutableListOf<Effect>()
            videoEffects.add(Presentation.createForHeight(targetHeight))

            val scaleX = (if (clip.flipH) -1f else 1f) * clip.zoomScale
            val scaleY = clip.zoomScale
            if (clip.rotationDeg != 0f || scaleX != 1f || scaleY != 1f) {
                videoEffects.add(
                    ScaleAndRotateTransformation.Builder()
                        .setRotationDegrees(clip.rotationDeg)
                        .setScale(scaleX, scaleY)
                        .build()
                )
            }

            val effectiveContrast = (clip.contrast * clip.filter.contrast) - 1f
            if (effectiveContrast != 0f) {
                videoEffects.add(Contrast(effectiveContrast.coerceIn(-1f, 1f)))
            }

            val audioProcessors = mutableListOf<AudioProcessor>()
            if (clip.speed != 1.0f) {
                audioProcessors.add(SonicAudioProcessor().apply { setSpeed(clip.speed) })
            }

            val builder = EditedMediaItem.Builder(mediaItem)
                .setEffects(Effects(audioProcessors, videoEffects))
                .setRemoveAudio(clip.volume <= 0.01f)

            if (!clip.isVideo) {
                builder.setDurationUs(clip.effectiveDurationMs * 1000L)
                builder.setFrameRate(30)
            }
            builder.build()
        }

        val sequences = mutableListOf<EditedMediaItemSequence>()
        sequences.add(EditedMediaItemSequence.Builder(editedClips).build())

        // Optional Background Music Track
        project.audioTrack?.let { music ->
            val musicItem = EditedMediaItem.Builder(MediaItem.fromUri(music.uri))
                .setRemoveVideo(true)
                .build()
            sequences.add(EditedMediaItemSequence.Builder(listOf(musicItem)).build())
        }

        val composition = Composition.Builder(sequences).build()

        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    val savedUri = saveToPublicGallery(tempFile)
                    tempFile.delete()
                    activeTransformer = null
                    if (savedUri != null) onComplete(savedUri)
                    else onError("Failed to save MP4 to Movies/MN SHOT")
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    tempFile.delete()
                    activeTransformer = null
                    onError(exportException.message ?: "Hardware export failed")
                }
            })
            .build()

        activeTransformer = transformer
        transformer.start(composition, tempFile.absolutePath)
        onProgress(20)
    }

    fun cancel() {
        activeTransformer?.cancel()
        activeTransformer = null
    }

    private fun saveToPublicGallery(source: File): Uri? {
        val filename = "MN_SHOT_${System.currentTimeMillis()}.mp4"
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/MN SHOT")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return null
            context.contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(source).use { input -> input.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
            uri
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            if (!dir.exists()) dir.mkdirs()
            val dest = File(dir, filename)
            source.copyTo(dest, overwrite = true)
            Uri.fromFile(dest)
        }
    }
}
