# MN SHOT v8.0 (100% Native Kotlin + Jetpack Compose + Media3)

Complete native Android rewrite of MN SHOT without WebView, HTML, or JavaScript bridges.

## Native Architecture
- **UI Framework:** 100% Jetpack Compose Material 3 (`MainActivity.kt`, `InShotScreens.kt`)
- **Video Playback:** Media3 ExoPlayer (`media3-exoplayer`) hardware preview
- **Video Rendering & MP4 Export:** Media3 Transformer (`media3-transformer` + `media3-effect`) exporting H.264/AAC MP4 directly to `Movies/MN SHOT`
- **Gallery & Thumbnails:** Native `MediaStore` ContentResolver + Coil VideoFrameDecoder
