# MN SHOT v6.0

MN SHOT is an Android (WebView) video editor with an InShot-style workflow:

- **Home**: gradient start screen, Create New (Video / Photo / Collage), My Drafts, NEW button dialog.
- **Editor**: live preview, multi-clip timeline with thumbnails, pinch-to-zoom, trim handles, playhead scrubbing, undo/redo.
- **Clip tools**: split, duplicate, speed (0.25x–4x), volume, rotate, flip, reorder, delete, Animation (In / Out / Combo / Loop), Crop (ratio, zoom, position), Opacity, Mask (circle, rounded, heart, star, diamond, bars), Background, Replace.
- **Tools**: Canvas (ratios, colour / blur background, fit / fill), Audio (add music with waveform, extract from video), Sticker (emoji), Text (fonts incl. Urdu, colour, outline, shadow, background, drag / scale / rotate), Effect (mirror, pulse, shake, flash, slow zoom, fade in/out), Filter (13 presets + intensity), Adjust (brightness, contrast, saturation, warmth, fade, vignette).
- **Drafts**: saved on-device (IndexedDB) and reopened from Home.
- **Export**: 480p / 720p / 1080p, 24 / 30 / 60 fps. Android converts to MP4 via Media3 Transformer; a browser build saves WebM.

Photo and Collage are marked "Soon".

v6: violet/cyan theme (edit the colors in the `:root` block at the top of `mnshot.css`), crown + What's New on Home, share row after MP4 export (WhatsApp, TikTok, YouTube, Instagram, Facebook, Other), picker now uses the system document picker.

## Files
- `app/src/main/assets/index.html`, `mnshot.css`, `mnshot.js` – the whole UI and editing engine (no dependencies).
- `app/src/main/java/com/mnshot/studio/MainActivity.java` – WebView shell, file picker, native MP4 bridge, back-button handling.
- `branding/` – logo SVG and 1024px PNG. Launcher icons are in `app/src/main/res/mipmap-*`.

## Build
Push to GitHub and run the *Build MN SHOT APK* workflow, or locally: `gradle assembleDebug` (JDK 17, Android SDK).


v6.1: InShot-style gallery picker (Recents / albums, VIDEO / PHOTO / ALL tabs, multi-select tray), Photo projects, Freeze frame, Capture frame, Speed curve presets, built-in sound effects. Features that are not possible offline or on-device yet are marked SOON (Reverse, Voice, Stabilizer, AI Cut, Enhance, PIP, Collage).

v6.3: Photo picker shows photos only; faster editing (lighter preview, smoother playback), sharp splash and logo.
v6.2: PIP (video or photo overlay with move/resize, opacity, corners, border), photo Collage (layouts, ratio, spacing, corners, background), Voice effects (Echo, Cave, Telephone, Radio, Robot, Deep), Enhance, Auto cut (scene detection). Still marked SOON: Reverse, Stabilizer.
