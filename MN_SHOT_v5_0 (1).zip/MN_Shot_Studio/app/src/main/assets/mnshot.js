/* MN SHOT — video editor (single-file, no dependencies) */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const uid=()=>Math.random().toString(36).slice(2,9);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,k)=>a+(b-a)*k;
const fmt=(s,d=1)=>{s=Math.max(0,s||0);const m=Math.floor(s/60),r=s-m*60;return m+':'+(r<10?'0':'')+r.toFixed(d)};
const fmtS=s=>{s=Math.round(s||0);return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const IS_ANDROID=!!window.MNCutNativeMp4;

/* ---------- icons ---------- */
const P={
 back:'<path d="M15 5l-7 7 7 7"/><path d="M8 12h12" opacity="0"/>',
 arrow:'<path d="M19 12H5M11 6l-6 6 6 6"/>',
 undo:'<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
 redo:'<path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>',
 play:'<path d="M7 4.5v15l13-7.5z" fill="currentColor"/>',
 pause:'<rect x="6" y="4.5" width="4" height="15" rx="1" fill="currentColor"/><rect x="14" y="4.5" width="4" height="15" rx="1" fill="currentColor"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
 close:'<path d="M6 6l12 12M18 6L6 18"/>',
 gear:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
 video:'<rect x="3" y="6" width="13" height="12" rx="2.5"/><path d="M16 10.5l5-3v9l-5-3z"/>',
 image:'<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="M4 17l5-4.5 4 3.5 3-2.5 4.5 4"/>',
 collage:'<rect x="3.5" y="3.5" width="7.5" height="17" rx="1.8"/><rect x="13" y="3.5" width="7.5" height="7.5" rx="1.8"/><rect x="13" y="13" width="7.5" height="7.5" rx="1.8"/>',
 canvas:'<path d="M6 2v14a2 2 0 0 0 2 2h14M2 6h14a2 2 0 0 1 2 2v14"/>',
 music:'<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
 sticker:'<circle cx="12" cy="12" r="9"/><path d="M8 14.5s1.5 2.5 4 2.5 4-2.5 4-2.5"/><circle cx="9" cy="10" r=".9" fill="currentColor"/><circle cx="15" cy="10" r=".9" fill="currentColor"/>',
 text:'<path d="M5 6V4.5h14V6M12 4.5V20M9 20h6"/>',
 effect:'<path d="M12 3l2.4 5.6L20 9.3l-4.2 3.9 1.2 5.8L12 15.9 7 19l1.2-5.8L4 9.3l5.6-.7z"/>',
 filter:'<circle cx="9" cy="10" r="5.5"/><circle cx="15.5" cy="10" r="5.5"/><circle cx="12.2" cy="15" r="5.5"/>',
 adjust:'<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
 speed:'<path d="M4.5 18a8.5 8.5 0 1 1 15 0"/><path d="M12 14l4-5"/><circle cx="12" cy="14.5" r="1.2" fill="currentColor"/>',
 volume:'<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
 mute:'<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
 split:'<path d="M12 3v18" stroke-dasharray="2 3"/><circle cx="6" cy="6.5" r="2.5"/><circle cx="6" cy="17.5" r="2.5"/><path d="M8 8l12 8M8 16l12-8"/>',
 trash:'<path d="M4 7h16M10 3.5h4M6.5 7l.8 12a2 2 0 0 0 2 1.9h5.4a2 2 0 0 0 2-1.9l.8-12M10 11v6M14 11v6"/>',
 dup:'<rect x="8" y="8" width="12" height="12" rx="2.5"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
 rotate:'<path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v5h-5"/>',
 flip:'<path d="M12 3v18" stroke-dasharray="2.5 3"/><path d="M9 7L3.5 17H9zM15 7l5.5 10H15z"/>',
 edit:'<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
 left:'<path d="M14 6l-6 6 6 6"/>',
 right:'<path d="M10 6l6 6-6 6"/>',
 extract:'<path d="M3 8h6l4-4v16l-4-4H3z"/><path d="M17 8l4 4-4 4"/>',
 more:'<circle cx="12" cy="5.5" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="18.5" r="1.4" fill="currentColor"/>',
 bright:'<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8"/>',
 contrast:'<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17a8.5 8.5 0 0 0 0-17z" fill="currentColor"/>',
 sat:'<path d="M12 3.5s6 6.2 6 10.5a6 6 0 0 1-12 0c0-4.3 6-10.5 6-10.5z"/>',
 warm:'<path d="M12 3a3 3 0 0 0-3 3v7.2a5 5 0 1 0 6 0V6a3 3 0 0 0-3-3z"/><path d="M12 9v7"/>',
 fade:'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 12h16M4 8h16M4 16h16" opacity=".4"/>',
 vig:'<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/>',
 crown:'<path d="M3.5 8l4.5 4 4-7 4 7 4.5-4-1.8 10H5.3z"/><path d="M5.5 20.5h13"/>',
 opacity:'<path d="M12 3.5s6 6.2 6 10.5a6 6 0 0 1-12 0c0-4.3 6-10.5 6-10.5z"/><path d="M12 3.5V20" opacity=".5"/><path d="M12 8.5l4.7 4M12 12.5l5.6 2.5" opacity=".5"/>',
 anim:'<circle cx="7" cy="12" r="3"/><circle cx="17.5" cy="12" r="3" opacity=".45"/><path d="M11 12h2.2M20.5 12h0" /><path d="M10 5.5c1.3-1.2 3.6-1.8 5.5-.8M10 18.5c1.3 1.2 3.6 1.8 5.5.8" opacity=".6"/>',
 crop:'<path d="M6 2v14a2 2 0 0 0 2 2h14M2 6h14a2 2 0 0 1 2 2v14"/>',
 mask:'<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5a8.5 8.5 0 0 0 0 17z" fill="currentColor"/>',
 replace:'<path d="M4 8h13l-3.5-3.5M20 16H7l3.5 3.5"/>',
 chev:'<path d="M6 9l6 6 6-6"/>',
 freeze:'<path d="M12 3v18M4.2 7.5l15.6 9M4.2 16.5l15.6-9"/>',
 camera:'<path d="M4 8h3l1.5-2.5h7L17 8h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
 clock:'<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/>',
 reverse:'<path d="M20 12H8M12 6l-6 6 6 6M4 5v14"/>',
 voice:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
 stab:'<rect x="6" y="6" width="12" height="12" rx="3"/><path d="M2 8V5M22 8V5M2 16v3M22 16v3"/>',
 ai:'<path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z"/><path d="M19 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>',
 enh:'<path d="M4 20L16 8"/><path d="M13 4l1 2 2 1-2 1-1 2-1-2-2-1 2-1zM18 14l.7 1.3L20 16l-1.3.7L18 18l-.7-1.3L16 16l1.3-.7z"/>',
 pip:'<rect x="3" y="5" width="18" height="14" rx="2.5"/><rect x="12" y="11" width="7" height="6" rx="1.5" fill="currentColor"/>',
 bgfill:'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 14l5-4 4 3 3-2 4 3" opacity=".6"/>',
};
const ic=(n,c='')=>`<svg class="i ${c}" viewBox="0 0 24 24">${P[n]||''}</svg>`;
const setIc=(el,n)=>{el.innerHTML=ic(n)};

/* ---------- constants ---------- */
const RATIOS=[['orig','Original',0],['9:16','9:16',9/16],['16:9','16:9',16/9],['1:1','1:1',1],['4:5','4:5',4/5],['3:4','3:4',3/4],['4:3','4:3',4/3],['21:9','21:9',21/9]];
const BGS=['#000000','#ffffff','#1e1e28','#ff4d6d','#ff9a3d','#ffd24a','#34d17a','#3dc7ff','#7a6cff','#c75bff','blur'];
const FILTERS={
 none:{n:'Original'},
 mint:{n:'Mint',bri:1.04,con:1.02,sat:1.15,hue:-18},
 amber:{n:'Amber',bri:1.04,con:1.05,sat:1.2,sep:.35,hue:-8},
 dreamy:{n:'Dreamy',bri:1.12,con:.88,sat:1.1,hue:12},
 aura:{n:'Aura',bri:1,con:1.12,sat:1.4,hue:-28},
 fresh:{n:'Fresh',bri:1.08,con:1.04,sat:1.3},
 film:{n:'Film',bri:.95,con:1.16,sat:.82,sep:.22},
 duo:{n:'Duo',bri:1,con:1.1,sat:.35,hue:200},
 neon:{n:'Neon',bri:1,con:1.28,sat:1.9,hue:32},
 cinema:{n:'Cinema',bri:.92,con:1.26,sat:.9,hue:-6},
 bw:{n:'B&W',con:1.12,sat:0},
 vintage:{n:'Vintage',bri:1.05,con:.9,sat:.9,sep:.6},
 warm:{n:'Warm',bri:1.03,sat:1.1,sep:.28,hue:-6},
 cool:{n:'Cool',bri:1.02,sat:1.05,hue:14},
};
const EFFECTS=[['none','None'],['mirror','Mirror'],['pulse','Pulse'],['shake','Shake'],['flash','Flash'],['zoom','Slow zoom']];
const FONTS=[['Sans','system-ui,"Roboto",Arial,sans-serif'],['Serif','Georgia,"Times New Roman",serif'],['Mono','"Courier New",monospace'],['Impact','Impact,"Arial Black",sans-serif'],['Script','"Brush Script MT","Segoe Script",cursive'],['Round','"Trebuchet MS","Verdana",sans-serif'],['Urdu','"Noto Nastaliq Urdu","Jameel Noori Nastaleeq","Noto Naskh Arabic",serif']];
const COLORS=['#ffffff','#000000','#ff4d6d','#ff9a3d','#ffd24a','#34d17a','#3dc7ff','#7a6cff','#c75bff','#ff8ad8','#b8b8c4','#7a4a2a'];
const EMOJI='😀😂🥰😎🤩😍😭😡🥳🤯🙌👍👏🔥💯✨⭐💥🎉❤️💙💜🧡💛💚🖤💔💫🌈☀️🌙⚡️❄️🌸🌹🍀🎵🎬📸🎥🎧🎤👑💎🏆🚀✈️🚗🍕🍔🍦☕️🎂🎁💡📌✅❌⚠️➡️⬅️⬆️⬇️👀💪🙏🤝✌️🤞👋'.match(/\p{Extended_Pictographic}(?:️|‍\p{Extended_Pictographic})*/gu);

/* ---------- state ---------- */
const sources=new Map();           // id -> {id,kind,name,blob,url,dur,w,h,thumbs:[],step,peaks}
const newState=()=>({v:2,name:'',muteOrig:false,clips:[],audios:[],overlays:[],
  canvas:{ratio:'orig',bg:'#000000',fit:'contain'},filter:{id:'none',amt:100},
  adj:{bri:0,con:0,sat:0,warm:0,fade:0,vig:0},fx:{id:'none',fadeIn:0,fadeOut:0},voice:'none'});
let S=newState(), total=0, t=0, draftId=null, dirty=false;
let undoSt=[], redoSt=[], editBase=null;
const V=$('#vid'), cv=$('#cv'), cx=cv.getContext('2d',{alpha:false});

function layout(){let a=0;S.clips.forEach(c=>{c.start=a;c.len=Math.max(.05,(c.outP-c.inP)/c.speed);a+=c.len});total=a;
  S.audios.forEach(x=>{x.len=Math.min(x.len,Math.max(.1,x.srcLen-x.inP))});}
const clipAt=time=>{const n=S.clips.length;for(let i=0;i<n;i++){const c=S.clips[i];if(time<c.start+c.len-1e-4)return i}return n-1};
const src=id=>sources.get(id);

/* history */
const snap=()=>JSON.stringify(S);
function beginEdit(){editBase=snap()}
function endEdit(){if(editBase!==null&&editBase!==snap()){undoSt.push(editBase);if(undoSt.length>60)undoSt.shift();redoSt=[];dirty=true}editBase=null;updUndo()}
function cancelEdit(){if(editBase!==null){S=JSON.parse(editBase);editBase=null;afterStateChange()}}
function act(fn){beginEdit();fn();layout();endEdit();afterStateChange()}
function undo(){if(!undoSt.length)return;redoSt.push(snap());S=JSON.parse(undoSt.pop());dirty=true;afterStateChange(true)}
function redo(){if(!redoSt.length)return;undoSt.push(snap());S=JSON.parse(redoSt.pop());dirty=true;afterStateChange(true)}
function updUndo(){$('#btnUndo').disabled=!undoSt.length;$('#btnRedo').disabled=!redoSt.length}

/* ---------- canvas helpers ---------- */
function ratioVal(){const r=RATIOS.find(x=>x[0]===S.canvas.ratio);if(r&&r[2])return r[2];
  const c=S.clips[0];if(c){const s=src(c.src);const sw=c.rot%180?s.h:s.w,sh=c.rot%180?s.w:s.h;if(sw&&sh)return sw/sh}return 9/16}
function filterCSS(fid=S.filter.id,amt=S.filter.amt,a=S.adj){
  const f=FILTERS[fid]||{},k=amt/100;
  const bri=lerp(1,f.bri||1,k)*(1+a.bri/100), con=lerp(1,f.con||1,k)*(1+a.con/100), sat=lerp(1,f.sat??1,k)*(1+a.sat/100);
  let hue=lerp(0,f.hue||0,k), sep=lerp(0,f.sep||0,k);
  if(a.warm>0)sep+=a.warm/100*.35; else if(a.warm<0)hue+=a.warm/100*-25;
  const parts=[];
  if(Math.abs(bri-1)>.005)parts.push(`brightness(${bri.toFixed(3)})`);
  if(Math.abs(con-1)>.005)parts.push(`contrast(${con.toFixed(3)})`);
  if(Math.abs(sat-1)>.005)parts.push(`saturate(${Math.max(0,sat).toFixed(3)})`);
  if(Math.abs(hue)>.3)parts.push(`hue-rotate(${hue.toFixed(1)}deg)`);
  if(sep>.005)parts.push(`sepia(${Math.min(1,sep).toFixed(3)})`);
  return parts.join(' ')||'none';
}
function fontCSS(o,px){return `${o.italic?'italic ':''}${o.bold?'700':'400'} ${px}px ${(FONTS.find(f=>f[0]===o.font)||FONTS[0])[1]}`}
function textMetrics(ctx,o,H){
  const px=o.size/100*H;
  if(o.type==='pip'){const ps=src(o.src),ar=ps&&ps.w&&ps.h?ps.w/ps.h:16/9,pw=H*o.size/100*2;return{px:o.size,w:pw,h:pw/ar,lines:[],lh:0}}
  if(o.type==='sticker')return{px,w:px*1.15,h:px*1.15,lines:[o.text],lh:px};
  ctx.save();ctx.font=fontCSS(o,px);
  const lines=(o.text||' ').split('\n'),lh=px*1.22;
  const w=Math.max(px*.5,...lines.map(l=>ctx.measureText(l||' ').width)),h=lh*lines.length;
  ctx.restore();return{px,w,h,lines,lh};
}
const pipPath=(ctx,m,r)=>{ctx.beginPath();if(ctx.roundRect)ctx.roundRect(-m.w/2,-m.h/2,m.w,m.h,r);else ctx.rect(-m.w/2,-m.h/2,m.w,m.h)};
function drawPip(ctx,W,H,o){
  const s=src(o.src);if(!s)return;
  let el=null,vw=0,vh=0;
  if(s.kind==='image'){el=s.img;vw=el.naturalWidth;vh=el.naturalHeight}
  else if(pipSrc===o.src&&PW.readyState>=2){el=PW;vw=PW.videoWidth;vh=PW.videoHeight}
  const m=textMetrics(ctx,o,H),r=Math.min(m.w,m.h)*(o.round==null?.06:o.round);
  ctx.save();ctx.translate(o.x*W,o.y*H);ctx.rotate(o.rot||0);
  ctx.save();pipPath(ctx,m,r);ctx.clip();ctx.globalAlpha=(o.op==null?100:o.op)/100;
  if(el&&vw){const k=Math.max(m.w/vw,m.h/vh);ctx.drawImage(el,-vw*k/2,-vh*k/2,vw*k,vh*k)}else{ctx.fillStyle='#22222a';ctx.fillRect(-m.w/2,-m.h/2,m.w,m.h)}
  ctx.restore();
  if(o.border!==false){pipPath(ctx,m,r);ctx.lineWidth=Math.max(2,m.w*.014);ctx.strokeStyle='#fff';ctx.shadowColor='#0007';ctx.shadowBlur=m.w*.03;ctx.stroke()}
  ctx.restore();
}
function drawOverlay(ctx,W,H,o){
  if(o.type==='pip'){drawPip(ctx,W,H,o);return}
  const m=textMetrics(ctx,o,H);ctx.save();ctx.translate(o.x*W,o.y*H);ctx.rotate(o.rot||0);
  ctx.textAlign='center';ctx.textBaseline='middle';
  if(o.type==='sticker'){ctx.font=`${m.px}px "Apple Color Emoji","Noto Color Emoji","Segoe UI Emoji",sans-serif`;ctx.fillText(o.text,0,m.px*.04)}
  else{
    ctx.font=fontCSS(o,m.px);
    if(o.bg){const p=m.px*.35;ctx.fillStyle=o.bgc||'#000000';ctx.globalAlpha=.78;
      const r=m.px*.28,x=-m.w/2-p,y=-m.h/2-p*.5,w=m.w+p*2,h=m.h+p;ctx.beginPath();
      if(ctx.roundRect)ctx.roundRect(x,y,w,h,r);else ctx.rect(x,y,w,h);ctx.fill();ctx.globalAlpha=1}
    if(o.shadow){ctx.shadowColor='#000c';ctx.shadowBlur=m.px*.18;ctx.shadowOffsetY=m.px*.06}
    m.lines.forEach((l,i)=>{const y=-m.h/2+m.lh*(i+.5);
      if(o.stroke){ctx.lineJoin='round';ctx.lineWidth=m.px*.14;ctx.strokeStyle=o.strokeC||'#000';ctx.strokeText(l,0,y)}
      ctx.fillStyle=o.color;ctx.fillText(l,0,y)});
  }
  ctx.restore();
}
const ovVisible=(o,time)=>time>=o.start-1e-3&&time<o.start+o.dur;

function cropRect(c,vw,vh){
  const k=c.crop;if(!k||(!k.ar&&(!k.z||k.z<=1)))return{sx:0,sy:0,sw:vw,sh:vh};
  let sw=vw,sh=vh;
  if(k.ar){if(vw/vh>k.ar)sw=vh*k.ar;else sh=vw/k.ar}
  const z=Math.max(1,k.z||1);sw/=z;sh/=z;
  const px=clamp(k.px==null?.5:k.px,0,1),py=clamp(k.py==null?.5:k.py,0,1);
  return{sx:(vw-sw)*px,sy:(vh-sh)*py,sw,sh};
}
const ANIM_IN=[['none','None'],['fade','Fade'],['zoom','Zoom'],['pop','Pop'],['slideL','Slide L'],['slideR','Slide R'],['slideU','Slide up'],['slideD','Slide down'],['spin','Spin']];
const ANIM_COMBO=[['none','None'],['zoomIn','Zoom in'],['zoomOut','Zoom out'],['panL','Pan left'],['panR','Pan right'],['rock','Rock']];
const ANIM_LOOP=[['none','None'],['pulse','Pulse'],['swing','Swing'],['shake','Shake'],['spinL','Spin'],['float','Float']];
function animEase(id,p){ // p: 0 = hidden/start, 1 = settled
  const e=1-Math.pow(1-p,3),o={a:1,s:1,x:0,y:0,r:0};
  switch(id){
    case 'fade':o.a=e;break;
    case 'zoom':o.s=.45+.55*e;o.a=e;break;
    case 'pop':o.s=p<1?(.3+.7*e)+Math.sin(p*Math.PI)*.12:1;o.a=Math.min(1,p*3);break;
    case 'slideL':o.x=-(1-e);break;
    case 'slideR':o.x=(1-e);break;
    case 'slideU':o.y=-(1-e);break;
    case 'slideD':o.y=(1-e);break;
    case 'spin':o.r=(1-e)*Math.PI;o.s=.4+.6*e;o.a=e;break;
  }
  return o;
}
function clipAnim(c,lt,time){
  const o={a:1,s:1,x:0,y:0,r:0},d=Math.min(c.adur||.6,c.len/2);
  const mix=m=>{o.a*=m.a;o.s*=m.s;o.x+=m.x;o.y+=m.y;o.r+=m.r};
  if(c.ain&&c.ain!=='none'&&lt<d)mix(animEase(c.ain,clamp(lt/d,0,1)));
  if(c.aout&&c.aout!=='none'&&lt>c.len-d)mix(animEase(c.aout,clamp((c.len-lt)/d,0,1)));
  const k=clamp(lt/Math.max(c.len,.01),0,1);
  switch(c.acom){
    case 'zoomIn':o.s*=1+.22*k;break;
    case 'zoomOut':o.s*=1.22-.22*k;break;
    case 'panL':o.s*=1.12;o.x+=.05-.1*k;break;
    case 'panR':o.s*=1.12;o.x+=-.05+.1*k;break;
    case 'rock':o.s*=1.08;o.r+=Math.sin(k*Math.PI*4)*.05;break;
  }
  switch(c.aloop){
    case 'pulse':o.s*=1+.06*Math.sin(time*5);break;
    case 'swing':o.r+=Math.sin(time*3.2)*.09;break;
    case 'shake':o.x+=Math.sin(time*38)*.012;o.y+=Math.cos(time*43)*.009;break;
    case 'spinL':o.r+=time*1.4;break;
    case 'float':o.y+=Math.sin(time*2.4)*.02;break;
  }
  return o;
}
function maskPath(ctx,id,w,h){
  const s=Math.min(w,h)*.5;
  switch(id){
    case 'circle':ctx.ellipse(0,0,w*.5,h*.5,0,0,Math.PI*2);break;
    case 'rect':{const rw=w*.84,rh=h*.84,r=Math.min(rw,rh)*.12,x=-rw/2,y=-rh/2;
      ctx.moveTo(x+r,y);ctx.arcTo(x+rw,y,x+rw,y+rh,r);ctx.arcTo(x+rw,y+rh,x,y+rh,r);ctx.arcTo(x,y+rh,x,y,r);ctx.arcTo(x,y,x+rw,y,r);ctx.closePath();break}
    case 'heart':ctx.moveTo(0,s*.95);ctx.bezierCurveTo(-s*1.55,s*.1,-s*1.1,-s*1.0,0,-s*.42);ctx.bezierCurveTo(s*1.1,-s*1.0,s*1.55,s*.1,0,s*.95);ctx.closePath();break;
    case 'star':for(let i=0;i<10;i++){const r=i%2?s*.46:s*1.02,a=-Math.PI/2+i*Math.PI/5;ctx[i?'lineTo':'moveTo'](Math.cos(a)*r,Math.sin(a)*r)}ctx.closePath();break;
    case 'diamond':ctx.moveTo(0,-h*.5);ctx.lineTo(w*.5,0);ctx.lineTo(0,h*.5);ctx.lineTo(-w*.5,0);ctx.closePath();break;
    case 'hbars':for(let i=0;i<5;i++){const y=-h/2+i*h/5;ctx.rect(-w/2,y,w,h/10)}break;
  }
}
function draw(ctx,W,H,time){
  ctx.save();ctx.setTransform(1,0,0,1,0,0);
  const bg=S.canvas.bg;ctx.fillStyle=bg==='blur'?'#000':bg;ctx.fillRect(0,0,W,H);
  const i=S.clips.length?clipAt(time):-1,c=S.clips[i];
  const cs=c&&src(c.src),isI=!!cs&&cs.kind==='image',el=isI?cs.img:V;
  const vw=isI?cs.img.naturalWidth:V.videoWidth,vh=isI?cs.img.naturalHeight:V.videoHeight,ready=c&&vw&&(isI||(loadedSrc===c.src&&V.readyState>=2));
  const fcss=filterCSS(),fx=S.fx.id;
  if(ready){
    const rot=c.rot||0,cr=cropRect(c,vw,vh),rw=rot%180?cr.sh:cr.sw,rh=rot%180?cr.sw:cr.sh;
    const fit=S.canvas.fit==='cover'?Math.max(W/rw,H/rh):Math.min(W/rw,H/rh);
    const lt=time-c.start,an=clipAnim(c,lt,time);
    if(bg==='blur'&&Math.abs(fit-Math.max(W/rw,H/rh))>.01){
      ctx.save();ctx.translate(W/2,H/2);ctx.rotate(rot*Math.PI/180);
      const s2=Math.max(W/rw,H/rh)*1.12;ctx.scale(s2,s2);
      if(!window._bgc){window._bgc=document.createElement('canvas');window._bgc.width=32;window._bgc.height=32;window._bgx=window._bgc.getContext('2d')}
      window._bgx.drawImage(el,0,0,32,32);ctx.imageSmoothingEnabled=true;ctx.drawImage(window._bgc,-vw/2,-vh/2,vw,vh);
      ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(-vw/2,-vh/2,vw,vh);ctx.restore()}
    ctx.save();
    let zoom=1,dx=0,dy=0;
    if(fx==='pulse')zoom=1+.06*Math.abs(Math.sin(time*Math.PI*1.6));
    if(fx==='zoom')zoom=1+.18*(time/Math.max(total,1));
    if(fx==='shake'){dx=Math.sin(time*47)*W*.008;dy=Math.cos(time*53)*H*.006}
    ctx.translate(W/2+dx+an.x*W,H/2+dy+an.y*H);ctx.scale(zoom*an.s,zoom*an.s);ctx.rotate(an.r);ctx.rotate(rot*Math.PI/180);ctx.scale(fit,fit);
    if(c.flip!==(fx==='mirror'))ctx.scale(-1,1);
    ctx.filter=((fcss&&fcss!=='none'?fcss+' ':'')+(c.enh?'contrast(1.08) saturate(1.18) brightness(1.03)':'')).trim()||'none';ctx.globalAlpha=clamp((c.op==null?100:c.op)/100*an.a,0,1);
    if(c.mask&&c.mask!=='none'){ctx.beginPath();maskPath(ctx,c.mask,cr.sw,cr.sh);ctx.clip()}
    ctx.drawImage(el,cr.sx,cr.sy,cr.sw,cr.sh,-cr.sw/2,-cr.sh/2,cr.sw,cr.sh);ctx.restore();
    if(S.adj.fade>0){ctx.fillStyle='#fff';ctx.globalAlpha=S.adj.fade/100*.35;ctx.fillRect(0,0,W,H);ctx.globalAlpha=1}
    if(S.adj.vig>0){const g=ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*.25,W/2,H/2,Math.hypot(W,H)*.55);
      g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,`rgba(0,0,0,${S.adj.vig/100*.9})`);ctx.fillStyle=g;ctx.fillRect(0,0,W,H)}
    if(fx==='flash'){const ph=(time*2)%1;if(ph<.12){ctx.fillStyle='#fff';ctx.globalAlpha=(1-ph/.12)*.55;ctx.fillRect(0,0,W,H);ctx.globalAlpha=1}}
  }
  S.overlays.forEach(o=>{if(ovVisible(o,time))drawOverlay(ctx,W,H,o)});
  let a=0;const fi=S.fx.fadeIn,fo=S.fx.fadeOut;
  if(fi>0&&time<fi)a=Math.max(a,1-time/fi);
  if(fo>0&&time>total-fo)a=Math.max(a,1-(total-time)/fo);
  if(a>0){ctx.fillStyle='#000';ctx.globalAlpha=clamp(a,0,1);ctx.fillRect(0,0,W,H);ctx.globalAlpha=1}
  ctx.restore();
}
let drawQ=0,exp=null;
function requestDraw(){if(drawQ)return;drawQ=requestAnimationFrame(()=>{drawQ=0;drawNow()})}
function drawNow(){draw(cx,cv.width,cv.height,t);if(exp)draw(exp.ctx,exp.W,exp.H,t);updSelBox()}

function sizeStage(){
  const st=$('#stage'),box=$('#stageBox');if(!st.clientWidth)return;
  const r=ratioVal(),aw=st.clientWidth-24,ah=st.clientHeight-10;
  let w=aw,h=w/r;if(h>ah){h=ah;w=h*r}
  box.style.width=Math.floor(w)+'px';box.style.height=Math.floor(h)+'px';
  let dpr=Math.min(window.devicePixelRatio||1,1.5);if(w*dpr>720)dpr=720/w;
  const nw=Math.round(w*dpr),nh=Math.round(h*dpr);
  if(cv.width!==nw||cv.height!==nh){cv.width=nw;cv.height=nh}
  requestDraw();
}
new ResizeObserver(()=>sizeStage()).observe($('#stage'));

/* ---------- audio graph ---------- */
let actx=null,master=null,speaker=null,vidGain=null;const musicEls=new Map();
async function ensureAudio(){
  if(!actx){
    try{
      actx=new (window.AudioContext||window.webkitAudioContext)();
      master=actx.createGain();speaker=actx.createGain();master.connect(speaker);speaker.connect(actx.destination);
      try{const n=actx.createMediaElementSource(V);vidGain=actx.createGain();n.connect(vidGain);vidGain.connect(master)}catch(e){vidGain=null}
      applyVoice();
    }catch(e){actx=null}
  }
  if(actx&&actx.state==='suspended'){try{await actx.resume()}catch(e){}}
}
const VOICES=[['none','None'],['echo','Echo'],['cave','Cave'],['telephone','Telephone'],['radio','Radio'],['robot','Robot'],['deep','Deep']];
let vNodes=[],curVoice='none';
function applyVoice(){
  if(!actx||!vidGain)return;
  const id=S.voice||'none';
  try{vidGain.disconnect()}catch(e){}
  vNodes.forEach(n=>{try{n.disconnect()}catch(e){}try{if(n.stop)n.stop()}catch(e){}});vNodes=[];
  const A=actx;
  const bq=(type,f,q,g)=>{const n=A.createBiquadFilter();n.type=type;n.frequency.value=f;if(q!=null)n.Q.value=q;if(g!=null)n.gain.value=g;vNodes.push(n);return n};
  const gn=v=>{const n=A.createGain();n.gain.value=v;vNodes.push(n);return n};
  const chain=(...ns)=>{ns.reduce((a,b)=>{a.connect(b);return b})};
  switch(id){
    case 'echo':case 'cave':{
      const e=id==='echo',d=A.createDelay(1);d.delayTime.value=e?.28:.09;vNodes.push(d);
      const fb=gn(e?.42:.6),wet=gn(e?.55:.7),lp=bq('lowpass',e?6000:1800,.7);
      vidGain.connect(master);vidGain.connect(d);d.connect(lp);lp.connect(fb);fb.connect(d);lp.connect(wet);wet.connect(master);break}
    case 'telephone':chain(vidGain,bq('highpass',500,.7),bq('lowpass',3200,.7),gn(1.6),master);break;
    case 'radio':{const ws=A.createWaveShaper(),cv2=new Float32Array(256);for(let i=0;i<256;i++)cv2[i]=Math.tanh((i/128-1)*3);ws.curve=cv2;vNodes.push(ws);
      chain(vidGain,bq('highpass',700,.7),ws,bq('lowpass',4800,.7),gn(.8),master);break}
    case 'robot':{const rg=gn(0),o=A.createOscillator();o.type='sine';o.frequency.value=55;o.connect(rg.gain);o.start();vNodes.push(o);chain(vidGain,rg,gn(1.8),master);break}
    case 'deep':chain(vidGain,bq('lowshelf',220,null,12),bq('peaking',1800,1,-6),bq('lowpass',3800,.7),gn(1.2),master);break;
    default:vidGain.connect(master);
  }
  curVoice=id;
}
function sheetVoice(){
  openSheet('Voice effect',body=>{
    ensureAudio().then(()=>{});
    body.append(chips(VOICES,S.voice||'none',v=>{S.voice=v;ensureAudio().then(()=>{applyVoice();if(!playing)play()})},([k,l])=>`${ic(k==='none'?'close':'voice')}<span>${l}</span>`));
    body.append(mk('lbl','<span>Applies to the original sound of your video</span>'));
  });
}
function applyClipAudio(c){
  const v=S.muteOrig?0:(c?c.vol:1);
  if(vidGain)vidGain.gain.value=v;else V.volume=clamp(v,0,1);
  if(c)V.playbackRate=c.speed;
}
function musicEl(a){
  let m=musicEls.get(a.id);if(m)return m;
  const el=new Audio();el.preload='auto';el.src=src(a.src).url;m={el,g:null};
  if(actx){try{const n=actx.createMediaElementSource(el);m.g=actx.createGain();n.connect(m.g);m.g.connect(master)}catch(e){m.g=null}}
  musicEls.set(a.id,m);return m;
}
function syncMusic(){
  S.audios.forEach(a=>{
    const m=musicEl(a),into=t-a.start,active=playing&&into>=0&&into<a.len;
    const vol=clamp(a.vol,0,2);if(m.g)m.g.gain.value=vol;else m.el.volume=clamp(vol,0,1);
    if(active){const target=a.inP+into;
      if(m.el.paused){try{m.el.currentTime=target}catch(e){}m.el.play().catch(()=>{})}
      else if(Math.abs(m.el.currentTime-target)>.4){try{m.el.currentTime=target}catch(e){}}
    }else if(!m.el.paused)m.el.pause();
  });
}
function pauseMusic(){musicEls.forEach(m=>m.el.pause())}

/* ---------- PIP video ---------- */
const PW=document.createElement('video');PW.muted=true;PW.playsInline=true;PW.preload='auto';
PW.style.cssText='position:fixed;left:-9999px;top:0;width:2px;height:2px;opacity:0;pointer-events:none';document.body.appendChild(PW);
let pipSrc=null;
['loadeddata','seeked'].forEach(ev=>PW.addEventListener(ev,()=>{if(!playing)requestDraw()}));
function pipOverlay(time){return S.overlays.find(o=>o.type==='pip'&&ovVisible(o,time)&&src(o.src)&&src(o.src).kind!=='image')}
function syncPip(time,force){
  const o=pipOverlay(time);
  if(!o){if(!PW.paused)PW.pause();return}
  const s=src(o.src),want=clamp((o.inP||0)+(time-o.start),0,Math.max(0,s.dur-.05));
  if(PW._src!==o.src){
    PW._src=o.src;pipSrc=null;PW.src=s.url;
    PW.onloadeddata=()=>{pipSrc=o.src;try{PW.currentTime=want}catch(e){}if(playing)PW.play().catch(()=>{});requestDraw()};
    return;
  }
  if(pipSrc!==o.src)return;
  if(playing){if(PW.paused)PW.play().catch(()=>{});if(Math.abs(PW.currentTime-want)>.3)PW.currentTime=want}
  else{if(!PW.paused)PW.pause();if(force||Math.abs(PW.currentTime-want)>.03)PW.currentTime=want}
}
function resetPip(){PW.pause();PW.removeAttribute('src');PW.load();PW._src=null;pipSrc=null}
/* ---------- playback ---------- */
let playing=false,idx=0,loadedSrc=null,seekTok=0,switching=false,raf=0;
function once(el,ev,ms=4000){return new Promise(res=>{let d=false;const f=()=>{if(d)return;d=true;el.removeEventListener(ev,f);clearTimeout(to);res()};const to=setTimeout(f,ms);el.addEventListener(ev,f)})}
async function loadSrc(id){
  if(loadedSrc===id&&V.readyState>=1)return;
  loadedSrc=id;V.src=src(id).url;await once(V,'loadedmetadata',6000);
  if(V.readyState<2)await once(V,'loadeddata',4000);
}
['loadeddata','seeked','canplay'].forEach(ev=>V.addEventListener(ev,()=>{if(!playing)requestDraw()}));
async function seek(time){
  const tok=++seekTok;t=clamp(time,0,total);
  if(!S.clips.length){syncPip(t,true);requestDraw();uiTime();return}
  idx=clipAt(t);const c=S.clips[idx];
  if(isImg(c)){V.pause();imgBase=t;imgT0=performance.now();syncPip(t,true);requestDraw();uiTime();return}
  await loadSrc(c.src);if(tok!==seekTok)return;
  const lt=c.inP+clamp(t-c.start,0,c.len)*c.speed;
  if(Math.abs(V.currentTime-lt)>.02){V.currentTime=lt;await once(V,'seeked',1500);if(tok!==seekTok)return}
  applyClipAudio(c);syncPip(t,true);requestDraw();uiTime();
}
async function play(){
  if(playing||!S.clips.length)return;
  await ensureAudio();
  if(t>=total-.05)await seek(0);
  playing=true;setPlayIcon();
  const c=S.clips[idx];applyClipAudio(c);
  if(isImg(c)){V.pause();imgBase=t;imgT0=performance.now()}else{try{await V.play()}catch(e){}}
  raf=requestAnimationFrame(tick);
}
function pause(){playing=false;V.pause();PW.pause();pauseMusic();setPlayIcon();cancelAnimationFrame(raf)}
async function goNext(){
  idx++;const c=S.clips[idx];
  if(isImg(c)){V.pause();imgBase=c.start;imgT0=performance.now();t=c.start;return}
  if(loadedSrc!==c.src||Math.abs(V.currentTime-c.inP)>.2||V.ended){
    await loadSrc(c.src);V.currentTime=c.inP;await once(V,'seeked',1500);
  }
  applyClipAudio(c);
  if(playing&&V.paused)try{await V.play()}catch(e){}
}
async function tick(){
  if(!playing)return;
  if(!switching){
    const c=S.clips[idx];
    if(isImg(c)){
      t=clamp(imgBase+(performance.now()-imgT0)/1000,c.start,c.start+c.len);
      if(t>=c.start+c.len-.02){
        if(idx<S.clips.length-1){switching=true;try{await goNext()}finally{switching=false}}
        else{t=total;drawNow();uiTime();pause();if(exp)finishExport();return}
      }
    }else{
      const lt=V.currentTime;
      t=clamp(c.start+(lt-c.inP)/c.speed,c.start,c.start+c.len);
      if(lt>=c.outP-.04||(V.ended&&lt>=c.outP-.3)){
        if(idx<S.clips.length-1){switching=true;try{await goNext()}finally{switching=false}}
        else{t=total;drawNow();uiTime();pause();if(exp)finishExport();return}
      }
    }
  }
  const nowT=performance.now();
  syncMusic();syncPip(t);
  if(exp||nowT-(tick._d||0)>=30){tick._d=nowT;drawNow()}
  if(exp||nowT-(tick._u||0)>=100){tick._u=nowT;uiTime();followPlayhead()}
  if(exp)exportTick();
  raf=requestAnimationFrame(tick);
}
function setPlayIcon(){setIc($('#btnPlay'),playing?'pause':'play');$('#btnPlay svg').style.width='28px';$('#btnPlay svg').style.height='28px'}
function uiTime(){$('#timeLbl').textContent=fmt(t)+' / '+fmt(total)}

/* ---------- sources & import ---------- */
let lastProbeErr='';
function probe(kind,url){
  return new Promise(res=>{
    const el=document.createElement(kind==='audio'?'audio':'video');el.preload='metadata';el.muted=true;el.playsInline=true;
    el.style.cssText='position:fixed;left:-9999px;top:0;width:2px;height:2px;opacity:0;pointer-events:none';
    document.body.appendChild(el);
    let fin=false;
    const done=(ok,why)=>{
      if(fin)return;fin=true;clearTimeout(to);
      const r=ok?{dur:el.duration,w:el.videoWidth||0,h:el.videoHeight||0}:null;
      lastProbeErr=ok?'':why;
      try{el.removeAttribute('src');el.load()}catch(e){}
      try{el.remove()}catch(e){}
      res(r)};
    const to=setTimeout(()=>done(false,'timeout, readyState '+el.readyState+', network '+el.networkState),20000);
    const check=()=>{if(isFinite(el.duration)&&el.duration>0)done(true)};
    ['loadedmetadata','loadeddata','durationchange','canplay'].forEach(ev=>el.addEventListener(ev,check));
    el.addEventListener('error',()=>{const c=el.error?el.error.code:0;done(false,'error code '+c+(c===4?' (format/codec not supported)':c===3?' (decode failed)':c===2?' (read failed)':''))});
    el.src=url;
    try{el.load()}catch(e){}
  });
}
const isImageFile=f=>/^image\//.test(f.type||'')||/\.(jpe?g|png|webp|gif|bmp|heic|heif|avif)$/i.test(f.name||'');
const isImg=c=>{const s=c&&src(c.src);return !!s&&s.kind==='image'};
let imgT0=0,imgBase=0;
function loadImg(url){return new Promise(res=>{const im=new Image();let done=false;const f=ok=>{if(done)return;done=true;res(ok?im:null)};
  im.onload=()=>f(im.naturalWidth>0);im.onerror=()=>f(false);setTimeout(()=>f(false),25000);im.src=url})}
async function makeSource(file,kind){
  if(kind==='image'){
    const u=URL.createObjectURL(file),im=await loadImg(u);
    if(!im){URL.revokeObjectURL(u);lastProbeErr='photo could not be decoded (format not supported?)';return null}
    const s={id:uid(),kind:'image',name:file.name||'Photo',blob:file,url:u,dur:600,w:im.naturalWidth,h:im.naturalHeight,thumbs:[],step:1,peaks:null,img:im};
    sources.set(s.id,s);return s;
  }
  const url=URL.createObjectURL(file),info=await probe(kind,url);
  if(!info){URL.revokeObjectURL(url);return null}
  const s={id:uid(),kind,name:file.name||'Clip',blob:file,url,dur:info.dur,w:info.w,h:info.h,thumbs:[],step:1,peaks:null};
  sources.set(s.id,s);return s;
}
const PHOTO_DUR=3;
function clipFromSource(s){return{id:uid(),src:s.id,inP:0,outP:s.kind==='image'?PHOTO_DUR:s.dur,speed:1,vol:1,rot:0,flip:false,start:0,len:s.dur,op:100,ain:'none',aout:'none',acom:'none',aloop:'none',adur:.6,crop:{ar:0,z:1,px:.5,py:.5},mask:'none'}}
async function importVideos(files,append){
  const list=[...files];if(!list.length)return 0;let n=0;toast('Importing '+list.length+' file(s)…',60000);
  const made=[];
  for(const f of list){const s=await makeSource(f,isImageFile(f)?'image':'video');if(s)made.push(s)}
  hideToast();
  if(!made.length){toast('This file could not be opened on this device.'+(lastProbeErr?' ['+lastProbeErr+']':''),8000);return 0}
  if(append)beginEdit();
  made.forEach(s=>{S.clips.push(clipFromSource(s));n++;genThumbs(s)});
  layout();if(append)endEdit();
  if(made.length<list.length)toast(`${list.length-made.length} file(s) could not be opened.`+(lastProbeErr?' ['+lastProbeErr+']':''),6000);
  return n;
}
/* thumbnails for timeline strips: one pass per source, reused by every clip cut from it */
const TV=document.createElement('video');TV.muted=true;TV.preload='auto';TV.playsInline=true;
let thumbBusy=Promise.resolve();
function genThumbs(s){
  if(s.kind==='image'){
    try{const c=document.createElement('canvas'),ar=s.w/s.h||1;c.height=72;c.width=Math.max(24,Math.round(72*ar));
      c.getContext('2d').drawImage(s.img,0,0,c.width,c.height);s.thumbs[0]=c.toDataURL('image/jpeg',.6);s.step=1e6;paintTiles(s.id)}catch(e){s.thumbs[0]=''}
    return}
  thumbBusy=thumbBusy.then(async()=>{
    if(s.thumbs.length||!sources.has(s.id))return;
    s.step=clamp(s.dur/30,1,6);const n=Math.ceil(s.dur/s.step)+1;
    TV.src=s.url;await once(TV,'loadedmetadata',6000);
    const ar=(s.w&&s.h)?s.w/s.h:16/9,tw=96,th=Math.round(tw/ar)||54;
    const c=document.createElement('canvas');c.width=tw;c.height=th;const g=c.getContext('2d');
    for(let i=0;i<n;i++){
      if(!sources.has(s.id))return;
      while(playing||exp)await new Promise(r=>setTimeout(r,400));
      TV.currentTime=Math.min(s.dur-.05,i*s.step);await once(TV,'seeked',1500);
      try{g.drawImage(TV,0,0,tw,th);s.thumbs[i]=c.toDataURL('image/jpeg',.55)}catch(e){break}
      if(i%3===2||i===n-1)paintTiles(s.id);
    }
    paintTiles(s.id);
  }).catch(()=>{});
}
async function peaksFor(s){
  if(s.peaks||s.peaksTried)return;s.peaksTried=true;
  try{
    if(s.blob.size>40e6)throw 0;
    const ac=new (window.OfflineAudioContext||window.webkitOfflineAudioContext)(1,44100,44100);
    const buf=await ac.decodeAudioData(await s.blob.arrayBuffer());
    const ch=buf.getChannelData(0),N=600,step=Math.floor(ch.length/N)||1,pk=[];
    for(let i=0;i<N;i++){let m=0;for(let j=i*step;j<(i+1)*step&&j<ch.length;j+=Math.max(1,step>>5))m=Math.max(m,Math.abs(ch[j]));pk.push(m)}
    s.peaks=pk;renderTimeline();
  }catch(e){}
}

/* ---------- toast / modal ---------- */
let toastT=0;
function toast(msg,ms=2200){const el=$('#toast');el.textContent=msg;el.hidden=false;clearTimeout(toastT);toastT=setTimeout(()=>{el.hidden=true},ms)}
function hideToast(){clearTimeout(toastT);$('#toast').hidden=true}
function modal(html,{mid=true,onClose}={}){
  const m=$('#modal');m.className='modal'+(mid?' mid':'');m.innerHTML=`<div class="dlg">${html}</div>`;m.hidden=false;
  m._close=onClose||null;
  m.onclick=e=>{if(e.target===m)closeModal()};return m;
}
function closeModal(){const m=$('#modal');if(m.hidden)return;m.hidden=true;m.innerHTML='';const f=m._close;m._close=null;f&&f()}
function dialog(title,msg,buttons){
  const m=modal(`<h3>${title}</h3><p>${msg}</p><div class="btns">${buttons.map((b,i)=>`<button class="${b.cls||''}" data-i="${i}">${b.label}</button>`).join('')}</div>`);
  $$('.btns button',m).forEach(b=>b.onclick=()=>{closeModal();buttons[+b.dataset.i].fn&&buttons[+b.dataset.i].fn()});
}

/* ---------- selection ---------- */
let sel=null;
const selClip=()=>sel&&sel.type==='clip'?S.clips.find(c=>c.id===sel.id):null;
const selAud=()=>sel&&sel.type==='aud'?S.audios.find(c=>c.id===sel.id):null;
const selOv=()=>sel&&sel.type==='ov'?S.overlays.find(c=>c.id===sel.id):null;
function select(s){sel=s;renderTimeline();renderToolbar();updSelBox()}

/* ---------- timeline ---------- */
let pps=50,padL=108,progLeft=-1;
const sc=$('#tlScroll'),inner=$('#tlInner');
const mk=(cls,html='',st={})=>{const d=document.createElement('div');d.className=cls;d.innerHTML=html;Object.assign(d.style,st);return d};
function rowsGreedy(items){const ends=[];return items.map(it=>{let r=ends.findIndex(e=>e<=it.start+1e-3);if(r<0){r=ends.length;ends.push(0)}ends[r]=it.start+it.len;return r})}
function renderTimeline(){
  const W=sc.clientWidth||320;padL=Math.max(96,Math.round(W*.3));
  inner.style.width=(padL+total*pps+(W-padL)+8)+'px';
  $('#playhead').style.left=(padL-1)+'px';
  // ruler
  const ruler=$('#ruler');ruler.innerHTML='';
  const steps=[.5,1,2,5,10,15,30,60,120,300];const step=steps.find(s=>s*pps>=62)||300;
  for(let s=0;s<=total+step;s+=step/2){
    const major=Math.abs(s/step-Math.round(s/step))<1e-6;
    ruler.append(mk('tk'+(major?'':' minor'),major?fmtS(s):'',{left:(padL+s*pps)+'px'}));
  }
  // overlays
  const lo=$('#laneOv');lo.innerHTML='';
  const ovItems=S.overlays.map(o=>({o,start:o.start,len:o.dur}));
  const rows=rowsGreedy(ovItems),nr=rows.length?Math.max(...rows)+1:0;
  lo.style.height=nr?(nr*24)+'px':'0px';lo.style.marginBottom=nr?'6px':'0';
  ovItems.forEach(({o},i)=>{
    const p=mk('pill-ov'+(o.type==='sticker'?' sticker':'')+(sel&&sel.id===o.id?' sel':''),
      `<span>${o.type==='sticker'?o.text:esc(o.text.replace(/\n/g,' '))}</span><i class="hdl l"></i><i class="hdl r"></i>`,
      {left:(padL+o.start*pps)+'px',width:Math.max(14,o.dur*pps)+'px',top:(rows[i]*24)+'px'});
    p.onclick=()=>{select({type:'ov',id:o.id});if(!ovVisible(o,t))seek(o.start+.01);};
    wireDrag(p,o,'ov');lo.append(p);
  });
  // video lane
  const lv=$('#laneVid');lv.innerHTML='';
  S.clips.forEach((c,i)=>{
    const w=c.len*pps,d=mk('clip'+(sel&&sel.id===c.id?' sel':''),'',{left:(padL+c.start*pps)+'px',width:w+'px'});
    const strip=mk('strip');const n=Math.max(1,Math.ceil(w/48));
    for(let k=0;k<n;k++){const ti=mk('tile2');ti.dataset.s=c.src;ti.dataset.t=(c.inP+((k+.5)*48/pps)*c.speed).toFixed(2);strip.append(ti)}
    d.append(strip);
    d.append(mk('badge',fmt(c.len)+(c.speed!==1?' · '+c.speed+'x':'')));
    if(S.muteOrig||c.vol===0)d.append(mk('vol0','🔇'));
    d.insertAdjacentHTML('beforeend','<i class="hdl l"></i><i class="hdl r"></i>');
    d.onclick=()=>select({type:'clip',id:c.id});
    wireDrag(d,c,'clip');lv.append(d);
  });
  S.clips.forEach(c=>paintTiles(c.src));
  if(!S.clips.length)lv.append(mk('empty-tl','Tap + to add a video',{left:'0',right:'0'}));
  // audio lane
  const la=$('#laneAud');la.innerHTML='';
  const auItems=S.audios.map(a=>({a,start:a.start,len:a.len}));const ar=rowsGreedy(auItems),na=ar.length?Math.max(...ar)+1:0;
  la.style.height=na?(na*34)+'px':'0px';la.style.marginBottom=na?'6px':'0';
  auItems.forEach(({a},i)=>{
    const d=mk('aud'+(sel&&sel.id===a.id?' sel':''),`<canvas></canvas><span>♫ ${esc(a.name)}</span><i class="hdl l"></i><i class="hdl r"></i>`,
      {left:(padL+a.start*pps)+'px',width:Math.max(16,a.len*pps)+'px',top:(ar[i]*34)+'px'});
    d.onclick=()=>select({type:'aud',id:a.id});wireDrag(d,a,'aud');la.append(d);
    drawWave(d.querySelector('canvas'),a);
  });
  scrollToT();
}
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function drawWave(c,a){
  const s=src(a.src),w=Math.max(16,Math.round(a.len*pps));c.width=w;c.height=30;const g=c.getContext('2d');g.fillStyle='#fff';
  const peaks=s&&s.peaks;if(!peaks){if(s&&!s.peaksTried&&s.kind==='audio')peaksFor(s);
    for(let x=0;x<w;x+=3){const h=4+Math.abs(Math.sin(x*.37+a.id.charCodeAt(0)))*10;g.fillRect(x,15-h/2,2,h)}return}
  for(let x=0;x<w;x+=3){const tt=a.inP+(x/pps),i=Math.floor(tt/s.dur*peaks.length),h=2+peaks[clamp(i,0,peaks.length-1)]*26;g.fillRect(x,15-h/2,2,h)}
}
function paintTiles(sid){
  const s=src(sid);if(!s||!s.thumbs.length)return;
  $$(`.tile2[data-s="${sid}"]`).forEach(el=>{
    let i=Math.round(+el.dataset.t/s.step);while(i>=0&&!s.thumbs[i])i--;
    if(i>=0&&s.thumbs[i]&&el._i!==i){el._i=i;el.style.backgroundImage=`url(${s.thumbs[i]})`}
  });
}
function setScroll(x){progLeft=Math.max(0,x);sc.scrollLeft=progLeft}
function scrollToT(){setScroll(t*pps)}
function followPlayhead(){scrollToT()}
let scrollPending=false;
sc.addEventListener('scroll',()=>{
  if(Math.abs(sc.scrollLeft-progLeft)<2.5)return;
  if(playing)pause();
  const nt=clamp(sc.scrollLeft/pps,0,total);t=nt;uiTime();
  if(!scrollPending){scrollPending=true;requestAnimationFrame(()=>{scrollPending=false;seek(t)})}
});
sc.addEventListener('touchstart',()=>{if(playing)pause()},{passive:true});
/* pinch zoom */
let pinch=null;
sc.addEventListener('touchmove',e=>{
  if(e.touches.length!==2)return;e.preventDefault();
  const d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);
  if(!pinch)pinch={d,p:pps};
  const np=clamp(pinch.p*d/pinch.d,10,220);if(Math.abs(np-pps)>.5){pps=np;renderTimeline()}
},{passive:false});
sc.addEventListener('touchend',()=>{pinch=null});
/* drag handles / bodies */
function wireDrag(el,item,kind){
  const grab=(e,mode)=>{
    e.stopPropagation();e.preventDefault();
    if(mode==='body'&&!el.classList.contains('sel'))return;
    if(playing)pause();
    const x0=e.clientX,snapItem=JSON.parse(JSON.stringify(item));beginEdit();
    const mv=ev=>{
      const dt=(ev.clientX-x0)/pps;
      if(kind==='clip'){
        const s=src(item.src);
        if(mode==='l'){item.inP=clamp(snapItem.inP+dt*snapItem.speed,0,snapItem.outP-.15*item.speed)}
        else if(mode==='r'){item.outP=clamp(snapItem.outP+dt*snapItem.speed,snapItem.inP+.15*item.speed,s.dur)}
      }else if(kind==='ov'){
        if(mode==='body')item.start=clamp(snapItem.start+dt,0,Math.max(0,total-.2));
        else if(mode==='l'){const ns=clamp(snapItem.start+dt,0,snapItem.start+snapItem.dur-.3);item.dur=snapItem.dur-(ns-snapItem.start);item.start=ns}
        else item.dur=Math.max(.3,snapItem.dur+dt);
      }else{
        if(mode==='body')item.start=clamp(snapItem.start+dt,0,Math.max(0,total-.2));
        else if(mode==='l'){const d=clamp(dt,-snapItem.inP,snapItem.len-.3);item.start=Math.max(0,snapItem.start+d);item.inP=snapItem.inP+d;item.len=snapItem.len-d}
        else item.len=clamp(snapItem.len+dt,.3,item.srcLen-item.inP);
      }
      layout();renderTimeline();
    };
    const up=()=>{window.removeEventListener('pointermove',mv);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',up);
      layout();endEdit();afterStateChange()};
    window.addEventListener('pointermove',mv);window.addEventListener('pointerup',up);window.addEventListener('pointercancel',up);
  };
  el.addEventListener('pointerdown',e=>{
    const h=e.target.closest('.hdl');
    if(h&&el.classList.contains('sel'))grab(e,h.classList.contains('l')?'l':'r');
    else if(kind!=='clip'&&el.classList.contains('sel'))grab(e,'body');
  });
}

/* ---------- toolbar ---------- */
const tb=$('#toolbar');
function tbBtn(k,icon,label,cls=''){return `<button class="tb ${cls}" data-k="${k}">${ic(icon)}<span>${label}</span></button>`}
function renderToolbar(){
  let h='';
  const back=`<button class="tb back" data-k="deselect">${ic('arrow')}<span>&nbsp;</span></button><span class="tsep"></span>`;
  if(sel&&sel.type==='clip'){
    const i=S.clips.findIndex(c=>c.id===sel.id),c=S.clips[i];
    const canSplit=c&&t>c.start+.15&&t<c.start+c.len-.15;
    const fc=k=>{return c&&c[k]&&c[k]!=='none'?'hot':''},im=isImg(c);
    h=back+tbBtn('c-split','split','Split',canSplit?'':'off')+tbBtn('c-del','trash','Delete','del')
      +(im?tbBtn('c-dur','clock','Duration'):tbBtn('c-vol','volume','Volume')+tbBtn('c-speed','speed','Speed'+(c&&c.speed!==1?' '+c.speed+'x':'')))
      +tbBtn('c-anim','anim','Animation',(fc('ain')||fc('aout')||fc('acom')||fc('aloop')))+tbBtn('c-crop','crop','Crop',c&&c.crop&&(c.crop.ar||c.crop.z>1)?'hot':'')+tbBtn('c-opacity','opacity','Opacity',c&&c.op!=null&&c.op<100?'hot':'')+tbBtn('c-mask','mask','Mask',fc('mask'))
      +tbBtn('c-bg','bgfill','Background')+tbBtn('c-rot','rotate','Rotate')+tbBtn('c-flip','flip','Flip')+tbBtn('c-dup','dup','Duplicate')+tbBtn('c-replace','replace','Replace')
      +(im?'':tbBtn('c-freeze','freeze','Freeze'))+tbBtn('c-capture','camera','Capture')
      +tbBtn('c-left','left','Move left',i>0?'':'off')+tbBtn('c-right','right','Move right',i<S.clips.length-1?'':'off')
      +(im?'':tbBtn('c-rev','reverse','Reverse','soon')+tbBtn('c-voice','voice','Voice',S.voice&&S.voice!=='none'?'hot':'')+tbBtn('c-stab','stab','Stabilizer','soon'))
      +tbBtn('c-autocut','ai','Auto cut')+tbBtn('c-enh','enh','Enhance',c&&c.enh?'hot':'');
  }else if(sel&&sel.type==='ov'){
    const o=selOv(),canSplit=o&&t>o.start+.2&&t<o.start+o.dur-.2;
    h=back+(o&&o.type==='text'?tbBtn('o-edit','edit','Edit'):'')+(o&&o.type==='pip'?tbBtn('o-op','opacity','Opacity')+tbBtn('o-round','mask','Corners')+tbBtn('o-border','crop','Border',o.border===false?'':'hot'):'')+tbBtn('o-split','split','Split',canSplit?'':'off')+tbBtn('o-dup','dup','Duplicate')+tbBtn('o-del','trash','Delete','del');
  }else if(sel&&sel.type==='aud'){
    const a=selAud(),canSplit=a&&t>a.start+.2&&t<a.start+a.len-.2;
    h=back+tbBtn('a-vol','volume','Volume')+tbBtn('a-split','split','Split',canSplit?'':'off')+tbBtn('a-del','trash','Delete','del');
  }else{
    h=tbBtn('m-canvas','canvas','Canvas')+tbBtn('m-audio','music','Audio')+tbBtn('m-sticker','sticker','Sticker')+tbBtn('m-text','text','Text')
     +tbBtn('m-effect','effect','Effect',S.fx.id!=='none'||S.fx.fadeIn||S.fx.fadeOut?'hot':'')+tbBtn('m-filter','filter','Filter',S.filter.id!=='none'?'hot':'')+tbBtn('m-adjust','adjust','Adjust',Object.values(S.adj).some(Boolean)?'hot':'')+tbBtn('m-pip','pip','PIP');
  }
  const mode=sel?sel.type:'main';tb.innerHTML=h;if(mode!==renderToolbar.m){tb.scrollLeft=0;renderToolbar.m=mode}
}
tb.addEventListener('click',e=>{
  const b=e.target.closest('.tb');if(!b)return;const k=b.dataset.k,c=selClip(),o=selOv(),a=selAud();
  if(b.classList.contains('soon')){toast(b.querySelector('span').textContent+' is coming soon');return}
  switch(k){
   case 'deselect':select(null);break;
   case 'm-canvas':sheetCanvas();break;case 'm-audio':sheetAudio();break;case 'm-sticker':sheetSticker();break;case 'm-text':addText();break;
   case 'm-effect':sheetEffect();break;case 'm-filter':sheetFilter('filter');break;case 'm-adjust':sheetFilter('adjust');break;
   case 'c-vol':sheetVolume(c,'Clip volume');break;
   case 'c-speed':sheetSpeed(c);break;
   case 'c-anim':sheetAnim(c);break;
   case 'c-dur':sheetDuration(c);break;
   case 'c-enh':act(()=>{c.enh=!c.enh});toast(c.enh?'Enhance on':'Enhance off',1800);break;
   case 'c-voice':sheetVoice();break;
   case 'c-autocut':autoCut(c);break;
   case 'c-freeze':freezeFrame(c);break;
   case 'c-capture':captureFrame();break;
   case 'c-crop':sheetCrop(c);break;
   case 'c-opacity':sheetOpacity(c);break;
   case 'c-mask':sheetMask(c);break;
   case 'c-bg':sheetCanvas();break;
   case 'c-replace':replaceTarget=c.id;openPicker('replace');break;
   case 'c-split':act(()=>{const n=JSON.parse(JSON.stringify(c)),cut=c.inP+(t-c.start)*c.speed;n.id=uid();n.inP=cut;c.outP=cut;S.clips.splice(S.clips.indexOf(c)+1,0,n)});toast('Clip split');break;
   case 'c-dup':act(()=>{const n=JSON.parse(JSON.stringify(c));n.id=uid();S.clips.splice(S.clips.indexOf(c)+1,0,n)});break;
   case 'c-rot':act(()=>{c.rot=(c.rot+90)%360});sizeStage();break;
   case 'c-flip':act(()=>{c.flip=!c.flip});break;
   case 'c-left':case 'c-right':act(()=>{const i=S.clips.indexOf(c),j=i+(k==='c-left'?-1:1);[S.clips[i],S.clips[j]]=[S.clips[j],S.clips[i]]});break;
   case 'c-del':
     if(S.clips.length===1)dialog('Delete last clip?','Your project will be empty.',[{label:'Cancel'},{label:'Delete',cls:'danger',fn:()=>{act(()=>{S.clips=[]});select(null)}}]);
     else{act(()=>{S.clips.splice(S.clips.indexOf(c),1)});select(null)}break;
   case 'o-edit':sheetText(o);break;
   case 'o-op':openSheet('PIP opacity',body=>{body.append(slider('Opacity',10,100,1,o.op==null?100:o.op,v=>{o.op=v;requestDraw()},v=>v+'%'))});break;
   case 'o-round':act(()=>{const r=o.round==null?.06:o.round;o.round=r<.03?.06:r<.2?.5:0});break;
   case 'o-border':act(()=>{o.border=o.border===false?true:false});break;
   case 'm-pip':if(!S.clips.length){toast('Add a video first.');break}openPicker('pip');break;
   case 'o-split':act(()=>{const n=JSON.parse(JSON.stringify(o));n.id=uid();n.start=t;n.dur=o.start+o.dur-t;if(o.type==='pip')n.inP=(o.inP||0)+(t-o.start);o.dur=t-o.start;S.overlays.push(n)});break;
   case 'o-dup':act(()=>{const n=JSON.parse(JSON.stringify(o));n.id=uid();n.x=clamp(n.x+.06,0,1);n.y=clamp(n.y+.06,0,1);S.overlays.push(n);sel={type:'ov',id:n.id}});break;
   case 'o-del':act(()=>{S.overlays.splice(S.overlays.indexOf(o),1)});select(null);break;
   case 'a-vol':sheetVolume(a,'Music volume');break;
   case 'a-split':act(()=>{const n=JSON.parse(JSON.stringify(a)),d=t-a.start;n.id=uid();n.start=t;n.inP=a.inP+d;n.len=a.len-d;a.len=d;S.audios.push(n)});break;
   case 'a-del':act(()=>{S.audios.splice(S.audios.indexOf(a),1)});select(null);break;
  }
});

/* ---------- sheets ---------- */
let sheetOpen=false,sheetCancel=true;
function openSheet(title,build,{edit=true}={}){
  if(playing)pause();
  if(edit)beginEdit();sheetOpen=true;
  $('#sheetTitle').innerHTML=title;$('#sheetOk').innerHTML=ic('check');
  const body=$('#sheetBody');body.innerHTML='';build(body);
  tb.hidden=true;$('#sheet').hidden=false;
}
function closeSheet(apply=true){
  if(!sheetOpen)return;sheetOpen=false;
  if(apply){layout();endEdit()}else cancelEdit();
  $('#sheet').hidden=true;tb.hidden=false;afterStateChange();
}
$('#sheetOk').onclick=()=>closeSheet(true);
function slider(label,min,max,step,val,onInput,fmtFn=v=>v){
  const w=mk('');w.innerHTML=`<div class="lbl"><span>${label}</span><b>${fmtFn(val)}</b></div><input type="range" min="${min}" max="${max}" step="${step}" value="${val}">`;
  const r=w.querySelector('input'),b=w.querySelector('b');
  const upd=()=>{r.style.setProperty('--p',((r.value-min)/(max-min)*100)+'%');b.textContent=fmtFn(+r.value)};upd();
  r.oninput=()=>{upd();onInput(+r.value)};return w;
}
function chips(items,cur,onPick,render){
  const row=mk('hrow');items.forEach(it=>{const b=mk('chip'+(cur===it[0]?' on':''),render(it));b.onclick=()=>{onPick(it[0]);$$('.chip',row).forEach(x=>x.classList.remove('on'));b.classList.add('on')};row.append(b)});return row;
}
/* canvas */
function sheetCanvas(){
  openSheet('Canvas',body=>{
    const rr=chips(RATIOS.map(r=>[r[0],r]),S.canvas.ratio,v=>{S.canvas.ratio=v;sizeStage()},([k,r])=>{
      const rv=r[2]||ratioVal(),w=rv>=1?26:Math.round(26*rv),h=rv>=1?Math.round(26/rv):26;
      return `<div class="rb" style="width:${w}px;height:${h}px"></div><span>${r[1]}</span>`});
    body.append(rr);
    const sw=mk('hrow');BGS.forEach(c=>{const b=mk('sw'+(c==='blur'?' blur':'')+(S.canvas.bg===c?' on':''),c==='blur'?'BLUR':'',c==='blur'?{}:{background:c});
      b.onclick=()=>{S.canvas.bg=c;$$('.sw',sw).forEach(x=>x.classList.remove('on'));b.classList.add('on');requestDraw()};sw.append(b)});
    body.append(mk('lbl','<span>Background</span>'),sw);
    const g=mk('gsel');[['contain','Fit'],['cover','Fill']].forEach(([k,l])=>{const b=mk('tg'+(S.canvas.fit===k?' on':''),l);b.onclick=()=>{S.canvas.fit=k;$$('.tg',g).forEach(x=>x.classList.remove('on'));b.classList.add('on');requestDraw()};g.append(b)});
    body.append(mk('lbl','<span>Video fit</span>'),g);
  });
}
/* filter + adjust */
function sheetFilter(tab){
  let cur=tab,adjKey='bri';
  const draw=body=>{
    body.innerHTML='';
    const tabs=$('#sheetTitle');tabs.innerHTML=`<span class="tab ${cur==='filter'?'on':''}" data-t="filter">Filter</span><span class="tab ${cur==='adjust'?'on':''}" data-t="adjust">Adjust</span>`;
    $$('.tab',tabs).forEach(x=>x.onclick=()=>{cur=x.dataset.t;draw(body)});
    if(cur==='filter'){
      const row=mk('hrow');
      Object.entries(FILTERS).forEach(([id,f])=>{
        const w=mk('ftile'+(S.filter.id===id?' on':''));const c=document.createElement('canvas');c.width=c.height=136;w.append(c,f.n);
        const g=c.getContext('2d');g.fillStyle='#222';g.fillRect(0,0,136,136);
        if(V.videoWidth&&V.readyState>=2){const s=Math.max(136/V.videoWidth,136/V.videoHeight);g.filter=filterCSS(id,100,{bri:0,con:0,sat:0,warm:0,fade:0,vig:0});g.drawImage(V,(136-V.videoWidth*s)/2,(136-V.videoHeight*s)/2,V.videoWidth*s,V.videoHeight*s)}
        w.onclick=()=>{S.filter.id=id;if(id!=='none'&&S.filter.amt===0)S.filter.amt=100;$$('.ftile',row).forEach(x=>x.classList.remove('on'));w.classList.add('on');requestDraw();amt.style.display=id==='none'?'none':''};row.append(w)});
      const amt=slider('Intensity',0,100,1,S.filter.amt,v=>{S.filter.amt=v;requestDraw()},v=>v+'%');amt.style.display=S.filter.id==='none'?'none':'';
      body.append(row,amt);
    }else{
      const items=[['bri','bright','Brightness'],['con','contrast','Contrast'],['sat','sat','Saturation'],['warm','warm','Warmth'],['fade','fade','Fade'],['vig','vig','Vignette']];
      const ics=mk('adj-icons');
      items.forEach(([k,i,l])=>{const b=mk('aic'+(adjKey===k?' on':''),ic(i)+l+(S.adj[k]?'<i></i>':''));b.onclick=()=>{adjKey=k;draw(body)};ics.append(b)});
      const one=items.find(x=>x[0]===adjKey),lo=(adjKey==='fade'||adjKey==='vig')?0:-100;
      const sl=slider(one[2],lo,100,1,S.adj[adjKey],v=>{S.adj[adjKey]=v;requestDraw()});
      const rs=mk('tg','Reset');rs.style.cssText='margin-top:6px;display:inline-block;line-height:36px';rs.onclick=()=>{Object.keys(S.adj).forEach(k=>S.adj[k]=0);requestDraw();draw(body)};
      body.append(ics,sl,rs);
    }
  };
  openSheet('',body=>draw(body));
}
/* effects */
function sheetEffect(){
  openSheet('Effect',body=>{
    body.append(chips(EFFECTS,S.fx.id,v=>{S.fx.id=v;requestDraw()},([k,l])=>`${ic(k==='none'?'close':'effect')}<span>${l}</span>`));
    body.append(slider('Fade in',0,3,.1,S.fx.fadeIn,v=>{S.fx.fadeIn=v;requestDraw()},v=>v.toFixed(1)+'s'));
    body.append(slider('Fade out',0,3,.1,S.fx.fadeOut,v=>{S.fx.fadeOut=v;requestDraw()},v=>v.toFixed(1)+'s'));
  });
}
/* clip tools: opacity / mask / crop / animation */
let replaceTarget=null;
function sheetOpacity(c){
  openSheet('Opacity',body=>{
    body.append(slider('Opacity',0,100,1,c.op==null?100:c.op,v=>{c.op=v;requestDraw()},v=>v+'%'));
  });
}
const MASKS=[['none','None'],['circle','Circle'],['rect','Rounded'],['heart','Heart'],['star','Star'],['diamond','Diamond'],['hbars','Bars']];
function sheetMask(c){
  openSheet('Mask',body=>{
    body.append(chips(MASKS,c.mask||'none',v=>{c.mask=v;requestDraw()},([k,l])=>`${ic(k==='none'?'close':'mask')}<span>${l}</span>`));
  });
}
const CROPS=[[0,'Free'],[1,'1:1'],[4/5,'4:5'],[9/16,'9:16'],[16/9,'16:9'],[4/3,'4:3'],[3/4,'3:4']];
function sheetCrop(c){
  if(!c.crop)c.crop={ar:0,z:1,px:.5,py:.5};
  openSheet('Crop',body=>{
    const k=c.crop;
    body.append(chips(CROPS.map(x=>[String(x[0]),x]),String(k.ar||0),v=>{k.ar=+v;requestDraw()},([id,x])=>{
      const rv=x[0]||1,w=rv>=1?26:Math.round(26*rv),h=rv>=1?Math.round(26/rv):26;
      return `<div class="rb" style="width:${w}px;height:${h}px"></div><span>${x[1]}</span>`}));
    body.append(slider('Zoom',1,4,.05,k.z||1,v=>{k.z=v;requestDraw()},v=>v.toFixed(2)+'x'));
    body.append(slider('Position X',0,100,1,Math.round((k.px==null?.5:k.px)*100),v=>{k.px=v/100;requestDraw()},v=>v+'%'));
    body.append(slider('Position Y',0,100,1,Math.round((k.py==null?.5:k.py)*100),v=>{k.py=v/100;requestDraw()},v=>v+'%'));
  });
}
function sheetAnim(c){
  const TABS=[['in','IN',ANIM_IN,'ain'],['out','OUT',ANIM_IN,'aout'],['combo','COMBO',ANIM_COMBO,'acom'],['loop','LOOP',ANIM_LOOP,'aloop']];
  let cur='in';
  const preview=tab=>{
    const dur=Math.min(c.adur||.6,c.len/2);
    let from=c.start;if(tab==='out')from=Math.max(c.start,c.start+c.len-dur-.6);
    seek(from).then(()=>play());
  };
  const build=body=>{
    body.innerHTML='';
    const tabs=$('#sheetTitle');tabs.innerHTML=TABS.map(([id,l])=>`<span class="tab ${cur===id?'on':''}" data-t="${id}">${l}</span>`).join('');
    $$('.tab',tabs).forEach(x=>x.onclick=()=>{cur=x.dataset.t;build(body)});
    const [,,list,key]=TABS.find(x=>x[0]===cur);
    body.append(chips(list,c[key]||'none',v=>{c[key]=v;layout();requestDraw();if(v!=='none')preview(cur)},([k,l])=>`${ic(k==='none'?'close':'anim')}<span>${l}</span>`));
    if(cur==='in'||cur==='out')body.append(slider('Duration',.2,2,.1,c.adur||.6,v=>{c.adur=v;requestDraw()},v=>v.toFixed(1)+'s'));
  };
  openSheet('',build);
}
/* speed / volume */
const CURVES=[['Montage',[1,.35,1,2.5,1]],['Hero',[1,.3,1]],['Bullet',[2,.2,2]],['Jump cut',[1,3,1,3]],['Ease in',[.4,.7,1,1.5,2]],['Ease out',[2,1.5,1,.7,.4]],['Flash',[3,.5,3]]];
function applyCurve(c,speeds){
  if(c.len<1.2){toast('This clip is too short for a speed curve.');return}
  const n=speeds.length,span=(c.outP-c.inP)/n,i=S.clips.indexOf(c),parts=[];
  speeds.forEach((sp,k)=>{const p=JSON.parse(JSON.stringify(c));p.id=uid();p.inP=c.inP+span*k;p.outP=c.inP+span*(k+1);p.speed=sp;if(k>0)p.ain='none';if(k<n-1)p.aout='none';parts.push(p)});
  S.clips.splice.apply(S.clips,[i,1].concat(parts));
  closeSheet(true);toast('Speed curve applied: '+n+' segments');
}
function sheetSpeed(c){
  let tab='std';
  const build=body=>{
    body.innerHTML='';
    const tabs=$('#sheetTitle');tabs.innerHTML=`<span class="tab ${tab==='std'?'on':''}" data-t="std">Standard</span><span class="tab ${tab==='curve'?'on':''}" data-t="curve">Curve</span>`;
    $$('.tab',tabs).forEach(x=>x.onclick=()=>{tab=x.dataset.t;build(body)});
    if(tab==='std'){
      const row=mk('hrow');[.25,.5,.75,1,1.5,2,3,4].forEach(v=>{const b=mk('tg'+(c.speed===v?' on':''),v+'x');b.onclick=()=>{c.speed=v;layout();$$('.tg',row).forEach(x=>x.classList.remove('on'));b.classList.add('on');sl.querySelector('input').value=v;sl.querySelector('input').oninput();applyClipAudio(c)};row.append(b)});
      const sl=slider('Playback speed',.25,4,.05,c.speed,v=>{c.speed=Math.round(v*100)/100;layout();uiTime();applyClipAudio(c)},v=>v.toFixed(2)+'x');
      body.append(row,sl);
    }else{
      const row=mk('hrow');
      CURVES.forEach(([nm,sp])=>{
        const w=116,h=46,mx=Math.max.apply(null,sp),pts=sp.map((v,k)=>`${(k+.5)/sp.length*w},${h-4-(v/mx)*(h-10)}`).join(' ');
        const b=mk('chip',`<svg viewBox="0 0 ${w} ${h}" width="58" height="26"><polyline fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round" points="${pts}"/></svg><span>${nm}</span>`);
        b.style.minWidth='76px';b.onclick=()=>applyCurve(c,sp);row.append(b)});
      body.append(row,mk('lbl','<span>A curve splits the clip into segments with different speeds</span>'));
    }
  };
  openSheet('',build);
}
function sheetDuration(c){
  openSheet('Duration',body=>{
    const cur=Math.round((c.outP-c.inP)*10)/10;
    body.append(slider('Show for',.5,30,.1,clamp(cur,.5,30),v=>{c.outP=c.inP+v;layout();uiTime()},v=>v.toFixed(1)+'s'));
  });
}
async function autoCut(c){
  if(isImg(c)){toast('Auto cut works on video clips.');return}
  if(c.outP-c.inP<2){toast('This clip is too short for auto cut.');return}
  pause();
  const s=src(c.src),el=document.createElement('video');el.muted=true;el.playsInline=true;el.preload='auto';el.src=s.url;
  try{
    await once(el,'loadeddata',10000);
    if(el.readyState<2){toast('Could not analyze this video.');return}
    const cn=document.createElement('canvas');cn.width=32;cn.height=18;
    const g=cn.getContext('2d',{willReadFrequently:true}),times=[];
    for(let x=c.inP;x<c.outP;x+=.25)times.push(x);
    let prev=null;const diffs=[];
    for(let i=0;i<times.length;i++){
      el.currentTime=times[i];await once(el,'seeked',2500);
      g.drawImage(el,0,0,32,18);const d=g.getImageData(0,0,32,18).data;
      if(prev){let sum=0;for(let k=0;k<d.length;k+=4)sum+=Math.abs(d[k]-prev[k])+Math.abs(d[k+1]-prev[k+1])+Math.abs(d[k+2]-prev[k+2]);diffs.push([times[i],sum/(d.length/4*3)])}
      prev=new Uint8ClampedArray(d);
      if(i%5===0)toast('Finding scenes… '+Math.round(i/times.length*100)+'%',60000);
    }
    hideToast();
    const vals=diffs.map(x=>x[1]).sort((a,b)=>a-b),med=vals.length?vals[Math.floor(vals.length/2)]:0;
    const mad=vals.length?vals.map(v=>Math.abs(v-med)).sort((a,b)=>a-b)[Math.floor(vals.length/2)]:0,th=Math.max(26,med+6*mad+10),cuts=[];
    diffs.forEach(([tm,v])=>{if(v>th&&(!cuts.length||tm-cuts[cuts.length-1]>=.8)&&tm-c.inP>=.8&&c.outP-tm>=.8)cuts.push(tm)});
    if(!cuts.length){toast('No scene changes found in this clip.');return}
    act(()=>{
      const i=S.clips.indexOf(c),pts=[c.inP].concat(cuts,[c.outP]),parts=[];
      for(let k=0;k<pts.length-1;k++){const p=JSON.parse(JSON.stringify(c));p.id=uid();p.inP=pts[k];p.outP=pts[k+1];if(k>0)p.ain='none';if(k<pts.length-2)p.aout='none';parts.push(p)}
      S.clips.splice.apply(S.clips,[i,1].concat(parts));
    });
    toast('Auto cut: '+(cuts.length+1)+' scenes');
  }catch(err){hideToast();toast('Auto cut error: '+((err&&err.message)||err),6000)}
  finally{el.removeAttribute('src');try{el.load()}catch(e){}}
}
async function freezeFrame(c){
  if(isImg(c)){toast('Freeze frame works on video clips.');return}
  pause();await seek(t);
  const vw=V.videoWidth,vh=V.videoHeight;if(!vw){toast('Frame is not ready yet. Try again.');return}
  const cn=document.createElement('canvas');cn.width=vw;cn.height=vh;
  try{cn.getContext('2d').drawImage(V,0,0,vw,vh)}catch(e){toast('Could not capture the frame.');return}
  const blob=await new Promise(r=>cn.toBlob(r,'image/jpeg',.92));
  if(!blob){toast('Could not capture the frame.');return}
  const s=await makeSource(new File([blob],'Freeze frame.jpg',{type:'image/jpeg'}),'image');
  if(!s){toast('Could not capture the frame.');return}
  const rel=t-c.start;
  act(()=>{
    const fz=clipFromSource(s);fz.outP=2;fz.rot=c.rot||0;fz.flip=!!c.flip;fz.crop=JSON.parse(JSON.stringify(c.crop||{ar:0,z:1,px:.5,py:.5}));fz.mask=c.mask||'none';fz.op=c.op==null?100:c.op;
    const i=S.clips.indexOf(c);
    if(rel>.15&&rel<c.len-.15){const n=JSON.parse(JSON.stringify(c));n.id=uid();const cut=c.inP+rel*c.speed;n.inP=cut;c.outP=cut;n.ain='none';c.aout='none';S.clips.splice(i+1,0,fz,n)}
    else if(rel<=.15)S.clips.splice(i,0,fz);else S.clips.splice(i+1,0,fz);
  });
  genThumbs(s);toast('Freeze frame added (2.0s)');
}
function captureFrame(){
  try{
    const d=exportDims(1080),cn=document.createElement('canvas');cn.width=d.W;cn.height=d.H;draw(cn.getContext('2d'),d.W,d.H,t);
    const data=cn.toDataURL('image/png'),MM2=window.MNCutMedia;
    if(MM2&&typeof MM2.saveImage==='function'){let ok=false;try{ok=MM2.saveImage(data.split(',')[1],'MN_SHOT_frame')}catch(e){}toast(ok?'Frame saved to Pictures/MN SHOT':'Could not save the frame.',3000)}
    else{const a=document.createElement('a');a.href=data;a.download='MN_SHOT_frame.png';document.body.append(a);a.click();a.remove();toast('Frame saved',2500)}
  }catch(err){toast('Could not capture the frame.')}
}
function sheetVolume(item,title){
  openSheet(title,body=>{
    body.append(slider('Volume',0,200,1,Math.round(item.vol*100),v=>{item.vol=v/100;if(item===selClip())applyClipAudio(item)},v=>v+'%'));
  });
}
/* text */
function addText(){
  beginEdit();
  const start=total-t<.6?Math.max(0,total-3):t;
  const o={id:uid(),type:'text',text:'Your text',font:'Sans',size:7,color:'#ffffff',bold:1,italic:0,stroke:1,strokeC:'#000000',shadow:0,bg:0,bgc:'#000000',x:.5,y:.5,rot:0,start,dur:clamp(total-start,.6,4)};
  S.overlays.push(o);sel={type:'ov',id:o.id};layout();renderTimeline();renderToolbar();requestDraw();
  const base=editBase;editBase=null;sheetText(o,base);
}
function sheetText(o,base){
  openSheet('Text',body=>{
    const ta=document.createElement('textarea');ta.className='textarea';ta.value=o.text;ta.placeholder='Type your text';
    ta.oninput=()=>{o.text=ta.value||' ';renderTimelineSoft();requestDraw()};body.append(ta);
    body.append(mk('lbl','<span>Font</span>'),chips(FONTS.map(f=>[f[0],f]),o.font,v=>{o.font=v;requestDraw()},([k])=>`<span style="font-family:${(FONTS.find(f=>f[0]===k))[1]};font-size:16px">${k==='Urdu'?'اردو':'Aa'}</span><span>${k}</span>`));
    const sw=mk('hrow');COLORS.forEach(c=>{const b=mk('sw'+(o.color===c?' on':''),'',{background:c});b.onclick=()=>{o.color=c;$$('.sw',sw).forEach(x=>x.classList.remove('on'));b.classList.add('on');requestDraw()};sw.append(b)});
    body.append(mk('lbl','<span>Color</span>'),sw);
    const g=mk('gsel');[['bold','Bold'],['italic','Italic'],['stroke','Outline'],['shadow','Shadow'],['bg','Background']].forEach(([k,l])=>{const b=mk('tg'+(o[k]?' on':''),l);b.onclick=()=>{o[k]=o[k]?0:1;b.classList.toggle('on');requestDraw()};g.append(b)});
    body.append(mk('lbl','<span>Style</span>'),g);
    body.append(slider('Size',2,24,.5,o.size,v=>{o.size=v;requestDraw()},v=>v));
    body.append(slider('Duration',.5,Math.max(1,Math.ceil(total)),.1,Math.min(o.dur,Math.max(1,Math.ceil(total))),v=>{o.dur=v;renderTimelineSoft()},v=>v.toFixed(1)+'s'));
    setTimeout(()=>{if(o.text==='Your text'){ta.focus();ta.select()}},120);
  });
  if(base!==undefined)editBase=base;
}
let softT=0;function renderTimelineSoft(){clearTimeout(softT);softT=setTimeout(renderTimeline,120)}
/* sticker */
function sheetSticker(){
  openSheet('Sticker',body=>{
    const g=mk('emo');EMOJI.forEach(e=>{const b=document.createElement('button');b.textContent=e;
      b.onclick=()=>{const start=total-t<.6?Math.max(0,total-3):t;
        S.overlays.push({id:uid(),type:'sticker',text:e,size:16,x:.5,y:.5,rot:0,start,dur:clamp(total-start,.6,4)});
        sel={type:'ov',id:S.overlays[S.overlays.length-1].id};closeSheet(true)};g.append(b)});body.append(g);
  });
}
/* audio */
function sheetAudio(){
  openSheet('Audio',body=>{
    const b1=mk('big-btn',`<span class="bi">${ic('music')}</span><div><b>Add music</b><small>Pick an audio file from your device</small></div>`);
    b1.onclick=()=>{$('#fileAudio').click()};
    const b2=mk('big-btn',`<span class="bi">${ic('extract')}</span><div><b>Extract audio from video</b><small>Use the sound of the clip under the playhead</small></div>`);
    b2.onclick=()=>{
      if(!S.clips.length)return;const c=S.clips[clipAt(t)],s=src(c.src);
      if(s.kind==='image'){toast('A photo has no sound to extract.');return}
      S.audios.push({id:uid(),src:s.id,name:'Extracted · '+s.name,start:c.start,inP:c.inP,len:c.len*c.speed,vol:1,srcLen:s.dur});
      layout();closeSheet(true);toast('Audio extracted');
    };
    const avg=S.clips.length?Math.round(S.clips.reduce((n,c)=>n+c.vol,0)/S.clips.length*100):100;
    const b3=mk('big-btn',`<span class="bi">${ic('effect')}</span><div><b>Sound effects</b><small>Pop, whoosh, ding, laser and more</small></div>`);
    b3.onclick=()=>{closeSheet(true);sheetSfx()};
    body.append(b1,b3,b2,slider('Original sound',0,200,1,S.muteOrig?0:avg,v=>{S.muteOrig=false;S.clips.forEach(c=>c.vol=v/100);applyClipAudio(S.clips[idx])},v=>v+'%'));
  });
}
function addAudioFromSource(s,name){
  if(!sheetOpen)beginEdit();
  let start=t,len=Math.min(s.dur,Math.max(total-t,0));if(len<.5){start=0;len=Math.min(s.dur,Math.max(total,s.dur))}
  const a={id:uid(),src:s.id,name:name||s.name.replace(/\.[^.]+$/,''),start,inP:0,len,vol:1,srcLen:s.dur};
  S.audios.push(a);sel={type:'aud',id:a.id};
  layout();if(sheetOpen){closeSheet(true)}else{endEdit();afterStateChange()}
  peaksFor(s);
}
$('#fileAudio').onchange=async e=>{
  const f=e.target.files[0];e.target.value='';if(!f)return;
  toast('Adding music…',30000);const s=await makeSource(f,'audio');hideToast();
  if(!s){toast('This audio file could not be opened.');return}
  addAudioFromSource(s);
};
/* generated sound effects (no downloads, rendered on the device) */
const SFX=[['pop','Pop'],['whoosh','Whoosh'],['ding','Ding'],['beep','Beep'],['laser','Laser'],['drum','Drum'],['rise','Rise'],['applause','Applause']];
async function renderSfx(name){
  const sr=44100,D={pop:.25,whoosh:1,ding:1.4,beep:.35,laser:.45,drum:.5,rise:1.2,applause:1.8}[name];
  const OAC=window.OfflineAudioContext||window.webkitOfflineAudioContext;
  const oc=new OAC(1,Math.ceil(sr*D),sr);
  const env=(g,a,d,pk)=>{g.gain.setValueAtTime(0,0);g.gain.linearRampToValueAtTime(pk,a);g.gain.exponentialRampToValueAtTime(.001,d)};
  const osc=(type,f0,f1,d,pk)=>{const o=oc.createOscillator(),g=oc.createGain();o.type=type;o.frequency.setValueAtTime(f0,0);o.frequency.exponentialRampToValueAtTime(f1,d);env(g,.004,d,pk);o.connect(g);g.connect(oc.destination);o.start(0);o.stop(d)};
  const noise=(d,f0,f1,q,peakAt,pk)=>{
    const b=oc.createBuffer(1,Math.ceil(sr*d),sr),a=b.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1;
    const s=oc.createBufferSource();s.buffer=b;const bp=oc.createBiquadFilter();bp.type='bandpass';bp.Q.value=q;
    bp.frequency.setValueAtTime(f0,0);bp.frequency.exponentialRampToValueAtTime(f1,d);
    const g=oc.createGain();g.gain.setValueAtTime(0,0);g.gain.linearRampToValueAtTime(pk,peakAt);g.gain.linearRampToValueAtTime(0,d);
    s.connect(bp);bp.connect(g);g.connect(oc.destination);s.start(0)};
  switch(name){
    case 'pop':osc('sine',900,140,.2,.9);break;
    case 'whoosh':noise(1,300,3200,.9,.45,.9);break;
    case 'ding':osc('sine',1318,1318,1.3,.7);osc('sine',1976,1976,1,.3);break;
    case 'beep':osc('square',880,880,.3,.3);break;
    case 'laser':osc('sawtooth',2400,160,.4,.35);break;
    case 'drum':osc('sine',170,42,.45,1);noise(.08,2200,500,.6,.01,.35);break;
    case 'rise':noise(1.2,200,4200,1.2,1.05,.9);break;
    case 'applause':{
      const b=oc.createBuffer(1,Math.ceil(sr*D),sr),a=b.getChannelData(0);
      for(let i=0;i<a.length;i++){const k=Math.floor(i/(sr*.02));const m=(Math.sin(k*12.9898)*43758.5453)%1;a[i]=(Math.random()*2-1)*(.25+.75*Math.abs(m))*Math.min(1,i/(sr*.15))*Math.min(1,(a.length-i)/(sr*.5))}
      const s=oc.createBufferSource();s.buffer=b;const bp=oc.createBiquadFilter();bp.type='bandpass';bp.frequency.value=1800;bp.Q.value=.4;s.connect(bp);bp.connect(oc.destination);s.start(0);break}
  }
  const buf=await oc.startRendering(),ch=buf.getChannelData(0),n=ch.length,ab=new ArrayBuffer(44+n*2),dv=new DataView(ab);
  const ws=(o,t2)=>{for(let i=0;i<t2.length;i++)dv.setUint8(o+i,t2.charCodeAt(i))};
  ws(0,'RIFF');dv.setUint32(4,36+n*2,true);ws(8,'WAVE');ws(12,'fmt ');dv.setUint32(16,16,true);dv.setUint16(20,1,true);dv.setUint16(22,1,true);
  dv.setUint32(24,sr,true);dv.setUint32(28,sr*2,true);dv.setUint16(32,2,true);dv.setUint16(34,16,true);ws(36,'data');dv.setUint32(40,n*2,true);
  for(let i=0;i<n;i++){const v=Math.max(-1,Math.min(1,ch[i]));dv.setInt16(44+i*2,v<0?v*0x8000:v*0x7fff,true)}
  return new Blob([ab],{type:'audio/wav'});
}
async function addSfx(name,label){
  try{
    toast('Adding '+label+'…',20000);
    const blob=await renderSfx(name),s=await makeSource(new File([blob],label+'.wav',{type:'audio/wav'}),'audio');hideToast();
    if(!s){toast('Sound effect could not be created on this device.');return}
    addAudioFromSource(s,label);
  }catch(err){hideToast();toast('Sound effect error: '+((err&&err.message)||err),5000)}
}
function sheetSfx(){
  openSheet('Sound effects',body=>{
    const row=mk('hrow');
    SFX.forEach(([id,l])=>{const b=mk('chip',`${ic('music')}<span>${l}</span>`);b.onclick=()=>addSfx(id,l);row.append(b)});
    body.append(row,mk('lbl','<span>Tap an effect to add it at the playhead</span>'));
  },{edit:false});
}

/* ---------- state refresh ---------- */
function afterStateChange(){
  layout();
  if(sel&&!(selClip()||selAud()||selOv()))sel=null;
  S.clips.forEach(c=>{const s=src(c.src);if(s&&!s.thumbs.length)genThumbs(s)});
  if(actx&&(S.voice||'none')!==curVoice)applyVoice();
  renderTimeline();renderToolbar();sizeStage();updUndo();updMute();
  $('#edTitle').textContent=S.name;t=clamp(t,0,total);
  if(!playing)seek(t);
}
function updMute(){const b=$('#btnMute');b.classList.toggle('on',!!S.muteOrig);setIc($('#muteIc'),S.muteOrig?'mute':'volume');$('#muteLbl').textContent=S.muteOrig?'Unmute':'Mute clip'}
$('#btnMute').onclick=()=>{act(()=>{S.muteOrig=!S.muteOrig});applyClipAudio(S.clips[idx])};
$('#btnUndo').onclick=undo;$('#btnRedo').onclick=redo;
$('#btnPlay').onclick=()=>playing?pause():play();
$('#btnAddClip').onclick=()=>openPicker('add');
async function addPip(f){
  try{
    toast('Adding PIP…',60000);
    const kind=isImageFile(f)?'image':'video',s=await makeSource(f,kind);hideToast();
    if(!s){toast('This file could not be opened on this device.'+(lastProbeErr?' ['+lastProbeErr+']':''),8000);return}
    const start=Math.min(t,Math.max(0,total-.6));
    const dur=Math.max(.6,Math.min(kind==='image'?3:s.dur,Math.max(.6,total-start)));
    const o={id:uid(),type:'pip',src:s.id,text:'PIP',size:20,x:.72,y:.28,rot:0,op:100,start,dur,inP:0};
    act(()=>{S.overlays.push(o);sel={type:'ov',id:o.id}});
    toast('PIP added. Drag to move, use the corner handle to resize.',3500);
  }catch(err){hideToast();toast('PIP error: '+((err&&err.message)||err),8000)}
}
async function doReplace(f){
  try{
    toast('Replacing clip…',60000);
    const s=await makeSource(f,isImageFile(f)?'image':'video');hideToast();
    if(!s){toast('This file could not be opened on this device.'+(lastProbeErr?' ['+lastProbeErr+']':''),8000);return}
    const c=S.clips.find(x=>x.id===replaceTarget);if(!c)return;
    act(()=>{c.src=s.id;c.inP=0;c.outP=s.kind==='image'?PHOTO_DUR:s.dur;c.speed=1;c.rot=0;c.flip=false;if(c.crop)c.crop={ar:0,z:1,px:.5,py:.5}});
    loadedSrc=null;genThumbs(s);toast('Clip replaced');
  }catch(err){toast('Replace error: '+((err&&err.message)||err),8000)}
}


/* ---------- on-canvas overlay editing ---------- */
function updSelBox(){
  const b=$('#selBox'),o=selOv();
  if(!o||!ovVisible(o,t)||$('#editor').hidden){b.hidden=true;return}
  const box=$('#stageBox'),bw=box.clientWidth,bh=box.clientHeight;if(!bw){b.hidden=true;return}
  const m=textMetrics(cx,o,cv.height),k=bw/cv.width,pad=m.px*.18;
  const w=(m.w+pad*2)*k,h=(m.h+pad*2)*k;
  Object.assign(b.style,{left:(o.x*bw-w/2)+'px',top:(o.y*bh-h/2)+'px',width:w+'px',height:h+'px',transform:`rotate(${o.rot||0}rad)`});
  $('.hd-edit',b).style.display=o.type==='text'?'':'none';b.hidden=false;
}
cv.addEventListener('pointerdown',e=>{
  const r=cv.getBoundingClientRect(),k=cv.width/r.width,px=(e.clientX-r.left)*k,py=(e.clientY-r.top)*k,W=cv.width,H=cv.height;
  let hit=null;
  for(let i=S.overlays.length-1;i>=0;i--){
    const o=S.overlays[i];if(!ovVisible(o,t))continue;
    const m=textMetrics(cx,o,H),dx=px-o.x*W,dy=py-o.y*H,c=Math.cos(-(o.rot||0)),s=Math.sin(-(o.rot||0));
    const lx=dx*c-dy*s,ly=dx*s+dy*c,pad=m.px*.3+10;
    if(Math.abs(lx)<=m.w/2+pad&&Math.abs(ly)<=m.h/2+pad){hit=o;break}
  }
  if(!hit){if(sel&&sel.type==='ov')select(null);return}
  if(playing)pause();
  select({type:'ov',id:hit.id});beginEdit();
  const x0=e.clientX,y0=e.clientY,ox=hit.x,oy=hit.y;
  const mv=ev=>{hit.x=clamp(ox+(ev.clientX-x0)/r.width,0,1);hit.y=clamp(oy+(ev.clientY-y0)/r.height,0,1);requestDraw()};
  const up=()=>{window.removeEventListener('pointermove',mv);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',up);endEdit()};
  window.addEventListener('pointermove',mv);window.addEventListener('pointerup',up);window.addEventListener('pointercancel',up);
});
(()=>{
  const sb=$('#selBox');
  $('.hd-del',sb).innerHTML=ic('close');$('.hd-edit',sb).innerHTML=ic('edit');$('.hd-scale',sb).innerHTML=ic('rotate');
  $('.hd-del',sb).onclick=()=>{const o=selOv();if(!o)return;act(()=>{S.overlays.splice(S.overlays.indexOf(o),1)});select(null)};
  $('.hd-edit',sb).onclick=()=>{const o=selOv();if(o&&o.type==='text')sheetText(o)};
  $('.hd-scale',sb).addEventListener('pointerdown',e=>{
    const o=selOv();if(!o)return;e.preventDefault();e.stopPropagation();beginEdit();
    const r=$('#stageBox').getBoundingClientRect(),cxp=r.left+o.x*r.width,cyp=r.top+o.y*r.height;
    const d0=Math.hypot(e.clientX-cxp,e.clientY-cyp)||1,a0=Math.atan2(e.clientY-cyp,e.clientX-cxp),s0=o.size,r0=o.rot||0;
    const mv=ev=>{const d=Math.hypot(ev.clientX-cxp,ev.clientY-cyp),a=Math.atan2(ev.clientY-cyp,ev.clientX-cxp);
      o.size=clamp(s0*d/d0,2,o.type==='pip'?45:60);o.rot=r0+(a-a0);requestDraw()};
    const up=()=>{window.removeEventListener('pointermove',mv);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',up);endEdit()};
    window.addEventListener('pointermove',mv);window.addEventListener('pointerup',up);window.addEventListener('pointercancel',up);
  });
})();

/* ---------- drafts (IndexedDB) ---------- */
const DB={
  _db:null,
  open(){return this._db?Promise.resolve(this._db):new Promise((res,rej)=>{
    const r=indexedDB.open('mnshot',1);
    r.onupgradeneeded=()=>{r.result.createObjectStore('drafts',{keyPath:'id'});r.result.createObjectStore('meta',{keyPath:'id'})};
    r.onsuccess=()=>{this._db=r.result;res(r.result)};r.onerror=()=>rej(r.error)})},
  async run(stores,mode,fn){const db=await this.open();return new Promise((res,rej)=>{
    const tx=db.transaction(stores,mode);let out;try{out=fn(...stores.map(s=>tx.objectStore(s)))}catch(e){rej(e);return}
    tx.oncomplete=()=>res(out&&out.result);tx.onerror=tx.onabort=()=>rej(tx.error)})},
  put(full,meta){return this.run(['drafts','meta'],'readwrite',(d,m)=>{d.put(full);m.put(meta)})},
  metas(){return this.run(['meta'],'readonly',m=>m.getAll()).then(a=>(a||[]).sort((x,y)=>y.updated-x.updated))},
  get(id){return this.run(['drafts'],'readonly',d=>d.get(id))},
  del(id){return this.run(['drafts','meta'],'readwrite',(d,m)=>{d.delete(id);m.delete(id)})},
  clear(){return this.run(['drafts','meta'],'readwrite',(d,m)=>{d.clear();m.clear()})},
};
async function saveDraft(){
  if(!S.clips.length)return false;
  try{
    const ids=new Set([...S.clips.map(c=>c.src),...S.audios.map(a=>a.src),...S.overlays.filter(o=>o.type==='pip').map(o=>o.src)]);
    const srcs=[...ids].map(id=>{const s=src(id);return{id:s.id,kind:s.kind,name:s.name,blob:s.blob,dur:s.dur,w:s.w,h:s.h}});
    if(!draftId)draftId=uid();
    const first=src(S.clips[0].src),thumb=first.thumbs[0]||'';
    await DB.put({id:draftId,state:JSON.parse(JSON.stringify(S)),sources:srcs},{id:draftId,name:S.name,updated:Date.now(),duration:total,thumb});
    dirty=false;return true;
  }catch(e){toast('Could not save draft: '+(e&&e.message||'storage unavailable'),3500);return false}
}
async function openDraft(id){
  try{
    const d=await DB.get(id);if(!d){toast('Draft not found');return}
    resetProject();
    d.sources.forEach(s=>{const o={...s,url:URL.createObjectURL(s.blob),thumbs:[],step:1,peaks:null};
      if(s.kind==='image'){o.img=new Image();o.img.onload=()=>{requestDraw()};o.img.src=o.url}
      sources.set(s.id,o)});
    S=d.state;draftId=id;enterEditor();
  }catch(e){toast('Could not open draft')}
}
const dateLbl=ts=>{const d=new Date(ts),p=n=>String(n).padStart(2,'0');return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`};
async function refreshHome(){
  const box=$('#draftTiles');let list=[];
  try{list=await DB.metas()}catch(e){}
  box.innerHTML='';
  if(!list.length){box.append(mk('tile empty','Your drafts will appear here.<br>Start a video project and save it anytime.'));return}
  list.forEach(m=>{
    const t1=mk('tile',`${m.thumb?`<img src="${m.thumb}" alt="">`:''}<div class="tmeta"><b>${fmtS(m.duration)}</b>${dateLbl(m.updated).slice(5)}</div><button class="more" aria-label="Delete draft">${ic('trash')}</button>`);
    t1.onclick=()=>openDraft(m.id);
    $('.more',t1).onclick=ev=>{ev.stopPropagation();confirmDelete(m.id)};
    box.append(t1);
  });
}
function confirmDelete(id){dialog('Delete draft?','This draft and its saved media will be removed from this device.',[{label:'Cancel'},{label:'Delete',cls:'danger',fn:async()=>{await DB.del(id).catch(()=>{});refreshHome()}}])}
async function draftsModal(all){
  let list=[];try{list=await DB.metas()}catch(e){}
  const shown=all?list:list.slice(0,3);
  const m=modal(`<button class="new-btn" id="mNew">NEW <span>${ic('plus')}</span></button><div id="mList"></div>${!all&&list.length>3?'<button class="allbtn" id="mAll">ALL DRAFTS ›</button>':''}`);
  const lst=$('#mList',m);
  shown.forEach(d=>{
    const r=mk('draft-row',`${d.thumb?`<img src="${d.thumb}" alt="">`:'<div class="ph"></div>'}<div><small>${dateLbl(d.updated)}</small><b>${fmtS(d.duration)}</b></div><span class="x" data-x>${ic('trash')}</span>`);
    r.onclick=ev=>{if(ev.target.closest('[data-x]')){closeModal();confirmDelete(d.id)}else{closeModal();openDraft(d.id)}};lst.append(r)});
  $('#mNew',m).onclick=()=>{closeModal();openPicker('video')};
  const al=$('#mAll',m);if(al)al.onclick=()=>{closeModal();draftsModal(true)};
}

/* ---------- editor lifecycle ---------- */
function resetProject(){
  pause();musicEls.forEach(m=>{m.el.pause();m.el.removeAttribute('src')});musicEls.clear();
  sources.forEach(s=>URL.revokeObjectURL(s.url));sources.clear();
  V.removeAttribute('src');V.load();loadedSrc=null;resetPip();
  S=newState();undoSt=[];redoSt=[];editBase=null;sel=null;t=0;total=0;draftId=null;dirty=false;
}
function enterEditor(){
  $('#home').hidden=true;$('#editor').hidden=false;$('#exportScreen').hidden=true;
  if(!S.name)S.name='MN SHOT '+dateLbl(Date.now()).slice(0,10);
  undoSt=[];redoSt=[];t=0;pps=50;sheetOpen=false;$('#sheet').hidden=true;tb.hidden=false;
  setPlayIcon();layout();afterStateChange();sizeStage();renderTimeline();
}
function exitEditor(){resetProject();$('#editor').hidden=true;$('#exportScreen').hidden=true;$('#home').hidden=false;refreshHome()}
function requestBack(){
  if(!S.clips.length&&!S.audios.length){exitEditor();return}
  if(!dirty&&draftId){exitEditor();return}
  dialog('Save to drafts?','Keep this project so you can continue editing it later.',[
    {label:'Discard',cls:'danger',fn:exitEditor},{label:'Cancel'},{label:'Save',cls:'pri',fn:async()=>{const ok=await saveDraft();if(ok)exitEditor()}}]);
}
$('#edBack').onclick=requestBack;

window.__mnDiag=m=>toast(m,6000);

/* ---------- export ---------- */
const BPS={480:2.2e6,720:4.5e6,1080:8e6};
let exOpt={res:720,fps:30};
function exportDims(res){const r=ratioVal();let W,H;if(r>=1){H=res;W=Math.round(res*r)}else{W=res;H=Math.round(res/r)}return{W:W&~1,H:H&~1}}
function openExport(){
  if(!S.clips.length){toast('Add a video first');return}
  pause();$('#exportScreen').hidden=false;
  const ec=$('#exCv'),d=exportDims(720);ec.width=Math.round(d.W/2);ec.height=Math.round(d.H/2);
  const g=ec.getContext('2d');draw(g,ec.width,ec.height,t);
  $('#fmtLbl').textContent=IS_ANDROID?'MP4':'WebM';
  $('#exNote').textContent=IS_ANDROID?'Your video is rendered in real time, then converted to MP4 and saved to Downloads. Keep the app open.':'Your video is rendered in real time in the browser and saved as a WebM file. Keep this tab open.';
  const seg=(id,vals,key,lab)=>{const s=$(id);s.innerHTML='';vals.forEach(v=>{const b=document.createElement('button');b.textContent=lab(v);if(exOpt[key]===v)b.className='on';b.onclick=()=>{exOpt[key]=v;$$('button',s).forEach(x=>x.classList.remove('on'));b.classList.add('on');estSize()};s.append(b)})};
  seg('#segRes',[480,720,1080],'res',v=>v+'p');seg('#segFps',[24,30,60],'fps',v=>v);estSize();
}
function estSize(){const b=(BPS[exOpt.res]*(exOpt.fps===60?1.4:exOpt.fps===24?.85:1)+128e3)*total/8/1048576;$('#exSize').textContent='~'+(b<10?b.toFixed(1):Math.round(b))+' MB'}
$('#btnExport').onclick=openExport;
$('#exBack').onclick=()=>{$('#exportScreen').hidden=true};
function showProgress(pct,title,msg){
  $('#progressScreen').hidden=false;$('#prBar').style.width=pct+'%';if(title)$('#prTitle').textContent=title;if(msg)$('#prMsg').textContent=msg}
$('#btnDoExport').onclick=startExport;
async function startExport(){
  if(exp)return;pause();selectNone();
  const {W,H}=exportDims(exOpt.res),ec=document.createElement('canvas');ec.width=W;ec.height=H;
  if(!window.MediaRecorder||!ec.captureStream){toast('Export is not supported on this device.');return}
  await ensureAudio();
  const mime=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'].find(m=>MediaRecorder.isTypeSupported(m))||'';
  const stream=ec.captureStream(exOpt.fps);let dest=null;
  if(actx){dest=actx.createMediaStreamDestination();master.connect(dest);speaker.gain.value=0;dest.stream.getAudioTracks().forEach(tr=>stream.addTrack(tr))}
  let rec;try{rec=new MediaRecorder(stream,{mimeType:mime||undefined,videoBitsPerSecond:BPS[exOpt.res]*(exOpt.fps===60?1.4:1),audioBitsPerSecond:128000})}
  catch(e){toast('Recorder could not start: '+e.message);return}
  exp={ctx:ec.getContext('2d'),W,H,rec,dest,chunks:[],cancel:false,finishing:false};
  rec.ondataavailable=e=>{if(e.data&&e.data.size)exp&&exp.chunks.push(e.data)};
  exp.stopped=new Promise(r=>rec.onstop=r);
  showProgress(0,'Exporting video 0%','Rendering in real time. Please keep MN SHOT open.');
  $('#prCancel').hidden=false;$('#prDone').hidden=true;$('#shareRow').hidden=true;
  await seek(0);await wait(120);drawNow();rec.start(400);await play();
}
function selectNone(){sel=null;renderTimeline();renderToolbar();updSelBox()}
function exportTick(){const p=total?clamp(t/total,0,1)*100:0;showProgress(p*.97,`Exporting video ${Math.round(p)}%`)}
async function finishExport(){
  const e=exp;if(!e||e.finishing)return;e.finishing=true;
  await wait(250);try{e.rec.stop()}catch(_){}await e.stopped;
  if(e.dest){try{master.disconnect(e.dest)}catch(_){}}if(speaker)speaker.gain.value=1;
  exp=null;
  if(e.cancel){$('#progressScreen').hidden=true;toast('Export cancelled');return}
  const blob=new Blob(e.chunks,{type:e.rec.mimeType||'video/webm'});
  if(!blob.size){exportFail('The export produced an empty file.');return}
  deliver(blob);
}
function exportFail(msg){showProgress(0,'Export failed',msg);$('#prCancel').hidden=true;$('#prDone').hidden=false;$('#prDone').textContent='Back to editor'}
function exportDone(msg){showProgress(100,'Export complete ✓',msg);$('#prCancel').hidden=true;$('#prDone').hidden=false;$('#prDone').textContent='Done';$('#shareRow').hidden=!IS_ANDROID}
let nativeBusy=false;
async function deliver(blob){
  const name='MN_SHOT_'+dateLbl(Date.now()).replace(/[-: ]/g,'').replace(/^(\d{8})(\d+)$/,'$1_$2');
  if(IS_ANDROID){
    try{
      const br=window.MNCutNativeMp4;showProgress(97,'Converting to MP4…','Sending the rendered video to Android…');
      if(!br.beginMp4Export())throw new Error('Android could not prepare MP4 conversion.');
      const CH=192*1024;
      for(let o=0;o<blob.size;o+=CH){
        const bytes=new Uint8Array(await blob.slice(o,o+CH).arrayBuffer());let bin='';
        for(let i=0;i<bytes.length;i+=8192)bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+8192));
        if(!br.appendMp4Chunk(btoa(bin)))throw new Error('MP4 data transfer failed.');
        showProgress(97+(o/blob.size)*2,null,`Sending to Android: ${Math.round((o+bytes.length)/blob.size*100)}%`);
      }
      nativeBusy=true;$('#prCancel').hidden=false;br.finishMp4Export();showProgress(99,'Converting to MP4…','Android is converting your video. Keep MN SHOT open.');
    }catch(err){try{window.MNCutNativeMp4.abortMp4Export()}catch(_){}nativeBusy=false;exportFail(err.message)}
  }else{
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name+'.webm';document.body.append(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),60000);exportDone('Saved as '+name+'.webm ('+(blob.size/1048576).toFixed(1)+' MB).');
  }
}
window.onNativeMp4Progress=msg=>{nativeBusy=true;showProgress(99,'Converting to MP4…',String(msg))};
window.onNativeMp4Result=(ok,msg)=>{nativeBusy=false;if(ok)exportDone(String(msg));else exportFail(String(msg))};
$('#prCancel').onclick=()=>{
  if(exp){exp.cancel=true;if(playing)pause();finishExport()}
  else if(nativeBusy){try{window.MNCutNativeMp4.cancelNativeMp4Export()}catch(_){}}
};
$$('#shareRow .sh').forEach(b=>b.onclick=()=>{
  try{if(!window.MNCutNativeMp4.shareLastVideo(b.dataset.pkg||''))toast('Nothing to share yet.')}catch(_){toast('Sharing is not available.')}
});
$('#prDone').onclick=()=>{$('#shareRow').hidden=true;$('#progressScreen').hidden=true;$('#exportScreen').hidden=true;if(!playing)seek(0)};

/* ---------- media picker (InShot-style gallery) ---------- */
const MM=window.MNCutMedia||null,PK_PAGE=90;
const pk={mode:'video',kind:'video',album:'',albumLbl:'Recents',off:0,done:false,loading:false,sel:[],thumbs:new Map(),permWait:null,io:null,queue:[],qt:0};
const pkKey=(id,type)=>id+':'+type;
const pkSingle=m=>(m||pk.mode)==='replace'||(m||pk.mode)==='pip';
const pkSupported=()=>!!(MM&&typeof MM.listMedia==='function');
function legacyPick(mode){
  pk.mode=mode;const inp=$('#filePick');
  inp.accept=(mode==='photo'||mode==='collage')?'image/*':(mode==='add'||mode==='pip')?'video/*,image/*':'video/*';
  inp.multiple=!pkSingle(mode);inp.click();
}
function openPicker(mode){
  if(!pkSupported()){legacyPick(mode);return}
  pk.mode=mode;pk.kind=(mode==='photo'||mode==='collage')?'image':'video';pk.album='';pk.albumLbl='Recents';pk.sel=[];
  $('#picker').hidden=false;pkSizeRows();$('#pkEmpty').hidden=true;pkRenderTabs();$('#pkTabs').style.display=(mode==='photo'||mode==='collage')?'none':'';pkRenderTray();pkTitle();$('#pkGrid').innerHTML='';
  pkEnsure().then(ok=>{if(ok)pkLoad(true);else pkDenied()});
}
function pkSizeRows(){const g=$('#pkGrid'),w=g.clientWidth||window.innerWidth;g.style.gridAutoRows=Math.floor((w-6)/4)+'px'}
window.addEventListener('resize',()=>{if(!$('#picker').hidden)pkSizeRows()});
function closePicker(){$('#picker').hidden=true;pk.sel=[];if(pk.io){pk.io.disconnect();pk.io=null}}
function pkEnsure(){
  return new Promise(res=>{
    let ok=false;try{ok=!!MM.hasPermission()}catch(e){}
    if(ok){res(true);return}
    pk.permWait=res;try{MM.requestPermission()}catch(e){pk.permWait=null;res(false)}
  });
}
window.onMediaPermission=g=>{const r=pk.permWait;pk.permWait=null;if(r)r(!!g)};
function pkDenied(){
  $('#pkGrid').innerHTML='';$('#pkEmpty').hidden=false;
  $('#pkEmptyMsg').textContent='MN SHOT needs access to your photos and videos to show your gallery. You can also browse files instead.';
  $('#pkAllow').hidden=false;
}
$('#pkAllow').onclick=()=>{
  pkEnsure().then(ok=>{
    if(ok){$('#pkEmpty').hidden=true;pkLoad(true)}
    else{try{MM.openSettings()}catch(e){}toast('Turn on Photos and videos access in Settings, then come back.',4500)}
  });
};
function pkFiles(){
  try{MM.setPicked('[]')}catch(e){}
  const inp=$('#filePick');inp.accept=(pk.mode==='collage'||pk.mode==='photo')?'image/*':'video/*,image/*';inp.multiple=!pkSingle();inp.click();
}
$('#pkFiles').onclick=pkFiles;$('#pkMore').onclick=pkFiles;
$('#pkBack').onclick=closePicker;
function pkTitle(){$('#pkTitle').innerHTML=`<span>${esc(pk.albumLbl.toUpperCase())}</span>${ic('chev')}`}
$('#pkTitle').onclick=()=>{
  let al=[];try{al=JSON.parse(MM.listAlbums(pk.kind)||'[]')}catch(e){}
  const rows=[{n:'',l:'Recents',c:''}].concat(al.map(a=>({n:a.n,l:a.n,c:a.c})));
  const m=modal(`<h3>Albums</h3><div class="alb-list">${rows.map((r,i)=>`<button class="alb" data-i="${i}"><b>${esc(r.l)}</b><small>${r.c}</small></button>`).join('')}</div>`,{mid:false});
  $$('.alb',m).forEach(b=>b.onclick=()=>{const r=rows[+b.dataset.i];pk.album=r.n;pk.albumLbl=r.l;closeModal();pkTitle();pkLoad(true)});
};
function pkRenderTabs(){$$('#pkTabs button').forEach(b=>b.classList.toggle('on',b.dataset.k===pk.kind))}
$$('#pkTabs button').forEach(b=>b.onclick=()=>{pk.kind=b.dataset.k;pkRenderTabs();pkLoad(true)});
function pkLoad(reset){
  const grid=$('#pkGrid');
  if(reset){grid.innerHTML='';pk.off=0;pk.done=false;pk.queue=[];if(pk.io){pk.io.disconnect();pk.io=null}$('#pkEmpty').hidden=true;grid.scrollTop=0}
  if(pk.loading||pk.done)return;
  pk.loading=true;let arr=[];
  try{arr=JSON.parse(MM.listMedia(pk.kind,pk.album,pk.off,PK_PAGE)||'[]')}catch(e){arr=[]}
  pk.loading=false;pk.off+=arr.length;if(arr.length<PK_PAGE)pk.done=true;
  const frag=document.createDocumentFragment();arr.forEach(it=>frag.append(pkTile(it)));grid.append(frag);
  if(!grid.children.length){
    $('#pkEmpty').hidden=false;$('#pkAllow').hidden=true;
    $('#pkEmptyMsg').textContent=pk.kind==='video'?'No videos found here. Try the PHOTO or ALL tab, or browse files.':pk.kind==='image'?'No photos found here. Try the VIDEO or ALL tab, or browse files.':'Nothing found here. Browse files instead.';
  }
}
$('#pkGrid').addEventListener('scroll',()=>{const g=$('#pkGrid');if(g.scrollTop+g.clientHeight>g.scrollHeight-800)pkLoad(false)});
function pkTile(it){
  const key=pkKey(it.id,it.type),i=pk.sel.findIndex(s=>s.key===key);
  const el=mk('pk-t'+(i>=0?' on':''),`<img alt=""><span class="dur">${it.type===3?fmtS((it.dur||0)/1000):''}</span><i class="bd">${i>=0?(pkSingle()?'✓':i+1):''}</i>`);
  el.dataset.id=it.id;el.dataset.type=it.type;
  const th=pk.thumbs.get(key);if(th)el.querySelector('img').src=th;else pkObserve(el);
  el.onclick=()=>pkToggle(it);return el;
}
function pkObserve(el){
  if(!('IntersectionObserver' in window)){pkQueue(el);return}
  if(!pk.io)pk.io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){pk.io.unobserve(e.target);pkQueue(e.target)}}),{root:$('#pkGrid'),rootMargin:'300px'});
  pk.io.observe(el);
}
function pkQueue(el){
  pk.queue.push({id:+el.dataset.id,type:+el.dataset.type});
  if(!pk.qt)pk.qt=setTimeout(()=>{pk.qt=0;const b=pk.queue.splice(0);try{MM.requestThumbs(JSON.stringify(b))}catch(e){}},40);
}
window.__mnThumb=(id,type,url)=>{
  if(!url)return;const key=pkKey(id,type);pk.thumbs.set(key,url);
  const el=$(`#pkGrid .pk-t[data-id="${id}"][data-type="${type}"]`);if(el)el.querySelector('img').src=url;
  if(pk.sel.some(s=>s.key===key))pkRenderTray();
};
function pkToggle(it){
  const key=pkKey(it.id,it.type),i=pk.sel.findIndex(s=>s.key===key);
  if(pkSingle())pk.sel=i>=0?[]:[{key,id:it.id,type:it.type}];
  else if(i>=0)pk.sel.splice(i,1);
  else{if(pk.mode==='collage'&&pk.sel.length>=6){toast('Up to 6 photos in a collage.');return}pk.sel.push({key,id:it.id,type:it.type})}
  pkRefreshBadges();pkRenderTray();
}
function pkRefreshBadges(){
  $$('#pkGrid .pk-t').forEach(el=>{
    const key=pkKey(el.dataset.id,el.dataset.type),i=pk.sel.findIndex(s=>s.key===key);
    el.classList.toggle('on',i>=0);el.querySelector('.bd').textContent=i>=0?(pkSingle()?'✓':i+1):'';
  });
}
function pkRenderTray(){
  const box=$('#pkSel');box.innerHTML='';
  pk.sel.forEach(s=>{
    const d=mk('si');const th=pk.thumbs.get(s.key);if(th)d.style.backgroundImage=`url(${th})`;
    const x=document.createElement('button');x.className='rm';x.innerHTML=ic('close');
    x.onclick=ev=>{ev.stopPropagation();pk.sel=pk.sel.filter(y=>y.key!==s.key);pkRefreshBadges();pkRenderTray()};
    d.append(x);box.append(d);
  });
  $('#pkHint').hidden=pk.sel.length>0;$('#pkOk').disabled=!pk.sel.length;
}
$('#pkOk').onclick=()=>{
  if(!pk.sel.length)return;
  if(pk.mode==='collage'&&pk.sel.length<2){toast('Pick 2 to 6 photos for a collage.');return}
  let ok=false;try{ok=!!MM.setPicked(JSON.stringify(pk.sel.map(s=>({id:s.id,type:s.type}))))}catch(e){}
  if(!ok){toast('Could not read the selected media. Try Browse files.',4000);return}
  const inp=$('#filePick');inp.accept='video/*,image/*';inp.multiple=!pkSingle();inp.click();
};
async function handlePicked(list){
  const mode=pk.mode;
  try{
    if(mode==='add'){const n=await importVideos(list,true);if(n){closePicker();afterStateChange()}}
    else if(mode==='replace'){closePicker();await doReplace(list[0])}
    else if(mode==='pip'){closePicker();await addPip(list[0])}
    else if(mode==='collage'){closePicker();await startCollage(list)}
    else{resetProject();const n=await importVideos(list,false);if(n){dirty=true;closePicker();enterEditor()}}
  }catch(err){toast('Import error: '+((err&&err.message)||err),8000)}
}
$('#filePick').onchange=async e=>{
  const list=[...(e.target.files||[])];e.target.value='';
  if(!list.length){toast('No file received from picker.',4000);return}
  await handlePicked(list);
};

/* ---------- collage (photos) ---------- */
const CL_LAYOUTS={
  2:[{rows:[2]},{rows:[1,1]}],
  3:[{rows:[3]},{rows:[1,1,1]},{rows:[1,2]},{rows:[2,1]},{rows:[1,2],t:1},{rows:[2,1],t:1}],
  4:[{rows:[2,2]},{rows:[1,3]},{rows:[3,1]},{rows:[1,1,1,1]},{rows:[1,3],t:1}],
  5:[{rows:[2,3]},{rows:[3,2]},{rows:[1,2,2]},{rows:[2,3],t:1}],
  6:[{rows:[3,3]},{rows:[2,2,2]},{rows:[2,4]},{rows:[1,2,3]}]
};
const CL_RATIOS=[['1:1',1,1],['4:5',4,5],['9:16',9,16],['16:9',16,9]];
const CL_COLORS=['#ffffff','#000000','#7c5cff','#22d3ee','#ff5da8','#ffd24a','#1a1a2e','#2ee6b6'];
const cl={srcs:[],layout:0,ratio:'1:1',gap:10,round:14,bg:'#ffffff'};
function clRects(L,W,H,g){
  const out=[],k=L.rows.length;
  L.rows.forEach((cnt,ri)=>{for(let ci=0;ci<cnt;ci++){
    let x0=ci/cnt,x1=(ci+1)/cnt,y0=ri/k,y1=(ri+1)/k;
    if(L.t){let a=x0;x0=y0;y0=a;a=x1;x1=y1;y1=a}
    out.push([x0*W+g,y0*H+g,(x1-x0)*W-2*g,(y1-y0)*H-2*g]);
  }});
  return out;
}
function clDraw(ctx,W,H,scale){
  const L=CL_LAYOUTS[cl.srcs.length][cl.layout],g=cl.gap*scale,r=cl.round*scale;
  ctx.fillStyle=cl.bg;ctx.fillRect(0,0,W,H);
  clRects(L,W,H,g).forEach((rc,i)=>{
    const s=cl.srcs[i],im=s&&s.img;if(!im)return;
    ctx.save();ctx.beginPath();
    if(ctx.roundRect)ctx.roundRect(rc[0],rc[1],rc[2],rc[3],r);else ctx.rect(rc[0],rc[1],rc[2],rc[3]);
    ctx.clip();
    const k=Math.max(rc[2]/im.naturalWidth,rc[3]/im.naturalHeight),w=im.naturalWidth*k,h=im.naturalHeight*k;
    ctx.drawImage(im,rc[0]+(rc[2]-w)/2,rc[1]+(rc[3]-h)/2,w,h);ctx.restore();
  });
}
function clDims(base){const r=CL_RATIOS.find(x=>x[0]===cl.ratio)||CL_RATIOS[0];return r[1]>=r[2]?{W:base,H:Math.round(base*r[2]/r[1])}:{W:Math.round(base*r[1]/r[2]),H:base}}
function clRender(){
  const st=$('#clStage'),cvs=$('#clCv'),d=clDims(720);cvs.width=d.W;cvs.height=d.H;
  const bw=st.clientWidth-28,bh=st.clientHeight-16,k=Math.min(bw/d.W,bh/d.H);
  cvs.style.width=Math.floor(d.W*k)+'px';cvs.style.height=Math.floor(d.H*k)+'px';
  clDraw(cvs.getContext('2d'),d.W,d.H,1);
}
function clBuildUI(){
  const n=cl.srcs.length,list=CL_LAYOUTS[n],lay=$('#clLayouts');lay.innerHTML='';
  list.forEach((L,i)=>{
    const rc=clRects(L,40,40,2.5);
    const b=mk('cl-lay'+(i===cl.layout?' on':''),`<svg viewBox="0 0 40 40">${rc.map(r=>`<rect x="${r[0]}" y="${r[1]}" width="${r[2]}" height="${r[3]}" rx="2" fill="currentColor" opacity=".85"/>`).join('')}</svg>`);
    b.onclick=()=>{cl.layout=i;$$('.cl-lay',lay).forEach(x=>x.classList.remove('on'));b.classList.add('on');clRender()};lay.append(b);
  });
  const rt=$('#clRatios');rt.innerHTML='';
  rt.append(chips(CL_RATIOS.map(x=>[x[0],x]),cl.ratio,v=>{cl.ratio=v;clRender()},([id,x])=>`<span>${x[0]}</span>`));
  const sl=$('#clSliders');sl.innerHTML='';
  sl.append(slider('Spacing',0,40,1,cl.gap,v=>{cl.gap=v;clRender()},v=>String(v)));
  sl.append(slider('Corners',0,60,1,cl.round,v=>{cl.round=v;clRender()},v=>String(v)));
  const co=$('#clColors');co.innerHTML='';
  CL_COLORS.forEach(c=>{const b=mk('cl-sw'+(c===cl.bg?' on':''));b.style.background=c;b.onclick=()=>{cl.bg=c;$$('.cl-sw',co).forEach(x=>x.classList.remove('on'));b.classList.add('on');clRender()};co.append(b)});
}
async function startCollage(list){
  try{
    toast('Loading photos…',60000);
    const srcs=[];
    for(const f of list.slice(0,6)){if(!isImageFile(f))continue;const s=await makeSource(f,'image');if(s)srcs.push(s)}
    hideToast();
    if(srcs.length<2){toast('Pick at least 2 photos that this device can open.'+(lastProbeErr?' ['+lastProbeErr+']':''),5000);return}
    cl.srcs=srcs;cl.layout=0;
    setIc($('#clBack'),'arrow');
    $('#collage').hidden=false;clBuildUI();requestAnimationFrame(clRender);
  }catch(err){hideToast();toast('Collage error: '+((err&&err.message)||err),6000)}
}
function closeCollage(){$('#collage').hidden=true;cl.srcs.forEach(s=>{sources.delete(s.id);try{URL.revokeObjectURL(s.url)}catch(e){}});cl.srcs=[]}
window.addEventListener('resize',()=>{if(!$('#collage').hidden)clRender()});
$('#clBack').onclick=closeCollage;
$('#clDone').onclick=async()=>{
  try{
    toast('Creating collage…',60000);
    const d=clDims(1080),cn=document.createElement('canvas');cn.width=d.W;cn.height=d.H;
    clDraw(cn.getContext('2d'),d.W,d.H,d.W/720);
    const blob=await new Promise(r=>cn.toBlob(r,'image/jpeg',.93));
    if(!blob){toast('Could not create the collage.');return}
    closeCollage();resetProject();
    const s=await makeSource(new File([blob],'Collage.jpg',{type:'image/jpeg'}),'image');hideToast();
    if(!s){toast('Could not create the collage.');return}
    S.clips.push(clipFromSource(s));S.name='Collage '+dateLbl(Date.now()).slice(0,10);dirty=true;enterEditor();
  }catch(err){hideToast();toast('Collage error: '+((err&&err.message)||err),6000)}
};

/* ---------- home ---------- */
$('#cVideo').onclick=()=>draftsModal(false);
$('#cPhoto').onclick=()=>openPicker('photo');
$('#cCollage').onclick=()=>openPicker('collage');
$('#btnAllDrafts').onclick=()=>draftsModal(true);
$('#btnPro').onclick=()=>{
  const m=modal(`<h3>All features unlocked</h3><p>MN SHOT is free: no watermark, no ads and every tool is available.</p><div class="btns"><button class="pri" id="proOk">Great</button></div>`,{mid:true});
  $('#proOk',m).onclick=closeModal;
};
$$('.wn-card').forEach(b=>b.onclick=()=>toast(b.dataset.wn,3600));
$('#btnNewAll').onclick=()=>toast('Animations, Opacity, Mask, Crop, Replace and Quick Share are new in v6',4200);
$('#btnSettings').onclick=()=>{
  const m=modal(`<h3>MN SHOT</h3><p>Video studio · version 6.3</p>
    <div class="set-row"><span>Export format</span><small>${IS_ANDROID?'MP4 (H.264)':'WebM (browser)'}</small></div>
    <div class="set-row"><span>Drafts</span><button class="tg" id="setClear">Delete all</button></div>
    <div class="btns" style="margin-top:14px"><button class="pri" id="setOk">Close</button></div>`,{mid:true});
  $('#setOk',m).onclick=closeModal;
  $('#setClear',m).onclick=()=>{closeModal();dialog('Delete all drafts?','All saved drafts will be removed from this device.',[{label:'Cancel'},{label:'Delete all',cls:'danger',fn:async()=>{await DB.clear().catch(()=>{});refreshHome()}}])};
};

/* ---------- Android back / init ---------- */
window.__mnBack=()=>{
  if(!$('#modal').hidden){closeModal();return true}
  if(!$('#collage').hidden){closeCollage();return true}
  if(!$('#picker').hidden){closePicker();return true}
  if(!$('#progressScreen').hidden){
    if(exp||nativeBusy){$('#prCancel').click();return true}
    $('#prDone').click();return true}
  if(!$('#exportScreen').hidden){$('#exportScreen').hidden=true;return true}
  if(!$('#editor').hidden){
    if(sheetOpen){closeSheet(false);return true}
    if(sel){select(null);return true}
    requestBack();return true}
  return false;
};
(()=>{
  setIc($('#btnSettings'),'gear');setIc($('#btnPro'),'crown');setIc($('#pkBack'),'arrow');setIc($('#pkMore'),'more');setIc($('#pkOk'),'check');
  $('#cVideo .cc').innerHTML=ic('video');$('#cPhoto .cc').innerHTML=ic('image');$('#cCollage .cc').innerHTML=ic('collage');
  $$('.cc svg').forEach(s=>{s.style.width='30px';s.style.height='30px'});
  setIc($('#edBack'),'arrow');setIc($('#exBack'),'arrow');setIc($('#btnUndo'),'undo');setIc($('#btnRedo'),'redo');setIc($('#btnAddClip'),'plus');
  setPlayIcon();updMute();
  new ResizeObserver(()=>{if(!$('#editor').hidden)renderTimeline()}).observe(sc);
  refreshHome();
  window.__mn={get S(){return S},seek,play,pause,get t(){return t},get total(){return total},get playing(){return playing},importVideos,enterEditor,resetProject,select,sources};
})();
})();
