package com.mnshot.nativeapp

import android.content.Context
import android.graphics.*
import android.media.MediaMetadataRetriever
import android.util.LruCache
import android.view.MotionEvent
import android.view.View
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** InShot-style timeline: playhead fixed in the centre, content scrolls under it. */
class TimelineView(ctx: Context) : View(ctx) {
    var clips: List<Clip> = emptyList()
    var texts: List<TextItem> = emptyList()
    var curMs = 0L
    var totalMs = 0L
    var selClip = -1
    var selText: TextItem? = null
    var onSeek: (Long) -> Unit = {}
    var onSelectClip: (Int) -> Unit = {}
    var onSelectText: (TextItem?) -> Unit = {}
    var onBeginEdit: () -> Unit = {}
    var onTextEdited: () -> Unit = {}
    var dragging = false

    private val d = resources.displayMetrics.density
    private val pxMs = 30f * d / 1000f
    private val rulerH = 22f * d
    private val rowH = 22f * d
    private val stripTop = 72f * d
    private val stripH = 52f * d
    private val thumbs = LruCache<String, Bitmap>(120)
    private val pending = ConcurrentHashMap.newKeySet<String>()
    private val exec = Executors.newSingleThreadExecutor()
    private val retr = HashMap<String, MediaMetadataRetriever>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private fun request(c: Clip, srcMs: Long, key: String) {
        if (!pending.add(key)) return
        exec.execute {
            try {
                val r = retr.getOrPut(c.uri.toString()) { MediaMetadataRetriever().apply { setDataSource(context, c.uri) } }
                val dh = 96
                val dw = (dh * (if (c.h > 0) c.w.toFloat() / c.h else 0.56f)).toInt().coerceIn(40, 300)
                val b = r.getScaledFrameAtTime(srcMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, dw, dh)
                if (b != null) post { thumbs.put(key, b); invalidate() }
            } catch (e: Exception) { }
            finally { pending.remove(key) }
        }
    }

    private fun clipStartMs(i: Int): Long { var a = 0L; for (k in 0 until i) a += clips[k].effMs; return a }
    private fun rowTop(idx: Int) = rulerH + (idx % 2) * rowH + 2f * d

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val t0 = curMs - cx / pxMs; val t1 = curMs + (width - cx) / pxMs
        // ruler
        p.style = Paint.Style.FILL; p.textSize = 10f * d
        var t = (ceil(max(0.0, t0.toDouble()) / 1000.0) * 1000).toLong()
        while (t <= t1 && t <= totalMs) {
            val x = cx + (t - curMs) * pxMs
            if (t % 5000L == 0L) { p.color = 0xFF8C8C96.toInt(); val s = t / 1000; c.drawText("%d:%02d".format(s / 60, s % 60), x - 10f * d, 12f * d, p) }
            else { p.color = 0xFF55555E.toInt(); c.drawCircle(x, 9f * d, 1.2f * d, p) }
            t += 1000
        }
        // clips
        var acc = 0L
        for ((i, cl) in clips.withIndex()) {
            val x0 = cx + (acc - curMs) * pxMs; val x1 = x0 + cl.effMs * pxMs
            if (x1 >= 0 && x0 <= width) {
                c.save()
                path.reset(); path.addRoundRect(RectF(x0, stripTop, x1, stripTop + stripH), 6f * d, 6f * d, Path.Direction.CW); c.clipPath(path)
                p.color = 0xFF2A2A33.toInt(); c.drawRect(x0, stripTop, x1, stripTop + stripH, p)
                val tw = 2000f * pxMs
                var k = max(0, floor((-x0) / tw).toInt())
                while (x0 + k * tw < width && k * 2000L < cl.effMs) {
                    val tx = x0 + k * tw
                    val srcMs = min(cl.end - 1, cl.start + ((k * 2000L + 1000L) * cl.speed).toLong())
                    val key = "${cl.uri}@${srcMs / 1000}"
                    val b = thumbs.get(key)
                    if (b != null) {
                        val dstR = min(tx + tw, x1)
                        val frac = (dstR - tx) / tw
                        c.drawBitmap(b, Rect(0, 0, (b.width * frac).toInt().coerceAtLeast(1), b.height), RectF(tx, stripTop, dstR, stripTop + stripH), p)
                    } else request(cl, srcMs, key)
                    k++
                }
                c.restore()
                if (i == selClip) { p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * d; p.color = Color.WHITE
                    c.drawRoundRect(RectF(x0, stripTop, x1, stripTop + stripH), 6f * d, 6f * d, p); p.style = Paint.Style.FILL }
            }
            acc += cl.effMs
        }
        // texts
        p.textSize = 11f * d
        for ((idx, tx) in texts.withIndex()) {
            val x0 = cx + (tx.start - curMs) * pxMs; val x1 = cx + (tx.end - curMs) * pxMs
            if (x1 < 0 || x0 > width) continue
            val y = rowTop(idx)
            val rect = RectF(x0, y, x1, y + rowH - 4f * d)
            p.shader = LinearGradient(x0, 0f, max(x1, x0 + 1f), 0f, 0xFF4F8BFF.toInt(), 0xFF8B6BFF.toInt(), Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, 5f * d, 5f * d, p); p.shader = null
            p.color = Color.WHITE
            c.save(); c.clipRect(rect); c.drawText(tx.text.replace('\n', ' '), x0 + 8f * d, y + 13f * d, p); c.restore()
            if (tx === selText) {
                p.color = Color.WHITE
                c.drawRoundRect(RectF(x0, y, x0 + 7f * d, y + rowH - 4f * d), 3f * d, 3f * d, p)
                c.drawRoundRect(RectF(x1 - 7f * d, y, x1, y + rowH - 4f * d), 3f * d, 3f * d, p)
            }
        }
        // playhead
        p.color = Color.WHITE; c.drawRect(cx - 1f * d, 0f, cx + 1f * d, height.toFloat(), p)
        c.drawCircle(cx, 4f * d, 4f * d, p)
    }

    private var mode = 0 // 0 scrub, 1 trimL, 2 trimR, 3 move
    private var downX = 0f; private var lastX = 0f; private var moved = false; private var began = false
    private var target: TextItem? = null

    private fun textAt(x: Float, y: Float): TextItem? {
        val cx = width / 2f
        for (i in texts.indices.reversed()) {
            val tx = texts[i]; val top = rowTop(i)
            val x0 = cx + (tx.start - curMs) * pxMs; val x1 = cx + (tx.end - curMs) * pxMs
            if (y in top..(top + rowH) && x >= x0 - 8f * d && x <= x1 + 8f * d) return tx
        }
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; lastX = e.x; moved = false; began = false; mode = 0; target = null
                val tx = textAt(e.x, e.y)
                if (tx != null && tx === selText) {
                    val cx = width / 2f
                    val x0 = cx + (tx.start - curMs) * pxMs; val x1 = cx + (tx.end - curMs) * pxMs
                    target = tx
                    mode = if (abs(e.x - x0) < 18f * d) 1 else if (abs(e.x - x1) < 18f * d) 2 else 3
                }
                dragging = true; parent?.requestDisallowInterceptTouchEvent(true); return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX; lastX = e.x
                if (abs(e.x - downX) > 6f * d) moved = true
                if (!moved) return true
                val dMs = (dx / pxMs).toLong()
                val tx = target
                if (mode == 0 || tx == null) {
                    curMs = (curMs - dMs).coerceIn(0L, max(0L, totalMs)); onSeek(curMs)
                } else {
                    if (!began) { began = true; onBeginEdit() }
                    when (mode) {
                        1 -> tx.start = (tx.start + dMs).coerceIn(0L, tx.end - 300)
                        2 -> tx.end = (tx.end + dMs).coerceIn(tx.start + 300, max(tx.start + 300, totalMs))
                        3 -> { val len = tx.end - tx.start; val ns = (tx.start + dMs).coerceIn(0L, max(0L, totalMs - len)); tx.start = ns; tx.end = ns + len }
                    }
                    onTextEdited()
                }
                invalidate(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                if (!moved && e.actionMasked == MotionEvent.ACTION_UP) {
                    val tx = textAt(e.x, e.y)
                    if (tx != null) onSelectText(tx)
                    else {
                        val cx = width / 2f; var acc = 0L; var hit = -1
                        for ((i, cl) in clips.withIndex()) {
                            val x0 = cx + (acc - curMs) * pxMs; val x1 = x0 + cl.effMs * pxMs
                            if (e.x in x0..x1 && e.y >= stripTop && e.y <= stripTop + stripH) hit = i
                            acc += cl.effMs
                        }
                        if (hit >= 0) onSelectClip(hit) else { onSelectText(null); onSelectClip(-1) }
                    }
                }
                invalidate(); return true
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow(); exec.shutdownNow()
        retr.values.forEach { try { it.release() } catch (e: Exception) { } }
    }
}
