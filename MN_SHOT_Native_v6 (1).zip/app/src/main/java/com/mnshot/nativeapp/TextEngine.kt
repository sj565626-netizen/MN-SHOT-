@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.mnshot.nativeapp

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.SpannableString
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import android.view.MotionEvent
import android.view.View
import androidx.media3.effect.BitmapOverlay
import java.io.File
import kotlin.math.*

data class TextItem(
    var text: String = "Your text", var sizeFrac: Float = 0.07f, var color: Int = Color.WHITE,
    var x: Float = 0.5f, var y: Float = 0.5f, var rot: Float = 0f,
    var bold: Boolean = true, var italic: Boolean = false, var font: String = "sans-serif",
    var outline: Boolean = true, var outlineColor: Int = Color.BLACK, var outlineW: Float = 0.12f,
    var shadow: Boolean = false, var shadowColor: Int = Color.BLACK,
    var box: Boolean = false, var boxColor: Int = 0xCC000000.toInt(),
    var start: Long = 0, var end: Long = 3000,
    var aIn: String = "none", var aOut: String = "none", var aLoop: String = "none", var aDur: Long = 600)

class Anim(var a: Float = 1f, var s: Float = 1f, var sx: Float = 1f, var sy: Float = 1f,
           var dx: Float = 0f, var dy: Float = 0f, var r: Float = 0f, var rv: Float = 1f)

val TXT_IN = listOf("none", "fade", "zoom", "zoomBig", "pop", "bounce", "rubber", "slideL", "slideR", "slideU", "slideD",
    "drop", "rise", "spin", "swirl", "flipX", "flipY", "stretchX", "shakeIn", "blink", "type")
val TXT_LOOP = listOf("none", "pulse", "swing", "shake", "float", "blink", "wobble", "heartbeat", "jello", "orbit", "flicker", "strobe")
val FONT_FAMILIES = listOf("sans-serif", "sans-serif-light", "sans-serif-thin", "sans-serif-medium", "sans-serif-black",
    "sans-serif-condensed", "sans-serif-condensed-light", "serif", "monospace", "serif-monospace", "cursive", "casual", "sans-serif-smallcaps")

private const val PI_F = 3.1415927f

fun easeAnim(id: String, p: Float): Anim {
    val e = 1f - (1f - p).pow(3)
    val bn = if (p < 1f) e + sin(p * PI_F * 2.5f) * 0.08f * (1f - p) * 3f else 1f
    val o = Anim()
    when (id) {
        "fade" -> o.a = e
        "zoom" -> { o.s = 0.45f + 0.55f * e; o.a = e }
        "zoomBig" -> { o.s = 2.2f - 1.2f * e; o.a = e }
        "pop" -> { o.s = if (p < 1f) (0.3f + 0.7f * e) + sin(p * PI_F) * 0.12f else 1f; o.a = min(1f, p * 3f) }
        "bounce" -> { o.s = max(0.01f, bn); o.a = min(1f, p * 4f) }
        "rubber" -> { o.sx = 1f + (1f - e) * 0.9f * cos(p * PI_F * 3f); o.sy = 1f / max(0.2f, o.sx); o.a = min(1f, p * 4f) }
        "slideL" -> o.dx = -(1f - e) * 0.5f
        "slideR" -> o.dx = (1f - e) * 0.5f
        "slideU" -> o.dy = -(1f - e) * 0.5f
        "slideD" -> o.dy = (1f - e) * 0.5f
        "drop" -> { o.dy = -(1f - bn) * 0.5f; o.a = min(1f, p * 4f) }
        "rise" -> { o.dy = (1f - e) * 0.3f; o.a = e }
        "spin" -> { o.r = (1f - e) * 180f; o.s = 0.4f + 0.6f * e; o.a = e }
        "swirl" -> { o.r = (1f - e) * 540f; o.s = 0.1f + 0.9f * e; o.a = e }
        "flipX" -> { o.sx = max(0.02f, e); o.a = min(1f, p * 3f) }
        "flipY" -> { o.sy = max(0.02f, e); o.a = min(1f, p * 3f) }
        "stretchX" -> { o.sx = 0.1f + 0.9f * e; o.a = e }
        "shakeIn" -> { o.dx = sin(p * 40f) * 0.02f * (1f - p); o.a = min(1f, p * 4f) }
        "blink" -> o.a = if (p < 1f) (if (sin(p * PI_F * 8f) > 0f) 1f else 0.1f) * min(1f, p * 2f) else 1f
        "type" -> o.rv = p
    }
    return o
}

fun loopAnim(id: String, t: Float, o: Anim) {
    when (id) {
        "pulse" -> o.s *= 1f + 0.06f * sin(t * 5f)
        "swing" -> o.r += sin(t * 3.2f) * 5.2f
        "shake" -> { o.dx += sin(t * 38f) * 0.006f; o.dy += cos(t * 43f) * 0.004f }
        "float" -> o.dy += sin(t * 2.4f) * 0.01f
        "blink" -> o.a *= if (sin(t * 6f) > 0f) 1f else 0.15f
        "wobble" -> { o.r += sin(t * 7f) * 2.6f; o.dx += sin(t * 3.5f) * 0.003f }
        "heartbeat" -> o.s *= 1f + 0.09f * max(0f, sin(t * 6f)).pow(6)
        "jello" -> { val k = sin(t * 9f) * 0.06f; o.sx *= 1f + k; o.sy *= 1f - k }
        "orbit" -> { o.dx += cos(t * 2f) * 0.01f; o.dy += sin(t * 2f) * 0.01f }
        "flicker" -> o.a *= 0.6f + 0.4f * abs(sin(t * 7f) * cos(t * 3f))
        "strobe" -> o.a *= if (sin(t * 16f) > 0f) 1f else 0.3f
    }
}

fun animFor(t: TextItem, ms: Long): Anim {
    val o = Anim()
    if (ms < t.start || ms > t.end) { o.a = 0f; return o }
    val d = min(t.aDur, (t.end - t.start) / 2).toFloat().coerceAtLeast(1f)
    val lt = ms - t.start; val rem = t.end - ms
    fun mix(m: Anim) { o.a *= m.a; o.s *= m.s; o.sx *= m.sx; o.sy *= m.sy; o.dx += m.dx; o.dy += m.dy; o.r += m.r; o.rv = min(o.rv, m.rv) }
    if (t.aIn != "none" && lt < d) mix(easeAnim(t.aIn, (lt / d).coerceIn(0f, 1f)))
    if (t.aOut != "none" && rem < d) mix(easeAnim(t.aOut, (rem / d).coerceIn(0f, 1f)))
    loopAnim(t.aLoop, ms / 1000f, o)
    return o
}

object TextRenderer {
    var fontDir: File? = null
    private val tfCache = HashMap<String, Typeface>()
    private val lyCache = LinkedHashMap<String, StaticLayout>()
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun clearCache() { tfCache.clear(); lyCache.clear() }

    private fun typeface(t: TextItem): Typeface {
        val style = (if (t.bold) Typeface.BOLD else 0) or (if (t.italic) Typeface.ITALIC else 0)
        return tfCache.getOrPut(t.font + "|" + style) {
            if (t.font.startsWith("file:")) {
                try { Typeface.create(Typeface.createFromFile(File(fontDir, t.font.substring(5))), style) }
                catch (e: Exception) { Typeface.create("sans-serif", style) }
            } else Typeface.create(t.font, style)
        }
    }

    private fun layout(t: TextItem, px: Float, reveal: Int, stroke: Boolean): StaticLayout {
        val key = "${t.text}|${t.font}|${t.bold}|${t.italic}|${px.roundToInt()}|$reveal|$stroke|${t.color}|${t.outlineColor}|${t.outlineW}|${t.shadow}|${t.shadowColor}|${t.outline}"
        lyCache[key]?.let { return it }
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG); p.typeface = typeface(t); p.textSize = px
        if (stroke) { p.style = Paint.Style.STROKE; p.strokeWidth = px * t.outlineW; p.strokeJoin = Paint.Join.ROUND; p.color = t.outlineColor }
        else { p.style = Paint.Style.FILL; p.color = t.color }
        if (t.shadow && (stroke || !t.outline)) p.setShadowLayer(px * 0.15f, px * 0.06f, px * 0.06f, t.shadowColor)
        val txt = t.text.ifEmpty { " " }
        val sp = SpannableString(txt)
        if (reveal < sp.length) sp.setSpan(ForegroundColorSpan(Color.TRANSPARENT), reveal.coerceAtLeast(0), sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val w = ceil(txt.split('\n').maxOf { Layout.getDesiredWidth(it, p) }).toInt() + ceil(px * t.outlineW).toInt() + 2
        val l = StaticLayout.Builder.obtain(sp, 0, sp.length, p, w).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        lyCache[key] = l
        if (lyCache.size > 80) lyCache.remove(lyCache.keys.first())
        return l
    }

    fun size(t: TextItem, H: Int): Pair<Float, Float> {
        val l = layout(t, t.sizeFrac * H, t.text.length, false)
        return Pair(l.width.toFloat(), l.height.toFloat())
    }

    fun draw(c: Canvas, W: Int, H: Int, items: List<TextItem>, ms: Long) {
        for (t in items) {
            val an = animFor(t, ms)
            if (an.a <= 0.003f) continue
            val px = t.sizeFrac * H
            val reveal = if (an.rv < 1f) floor(t.text.length * an.rv).toInt() else t.text.length
            val fill = layout(t, px, reveal, false)
            val st = if (t.outline) layout(t, px, reveal, true) else null
            val w = fill.width.toFloat(); val h = fill.height.toFloat(); val pad = px * 0.35f
            c.save()
            c.translate(t.x * W + an.dx * W, t.y * H + an.dy * H)
            c.rotate(t.rot + an.r)
            c.scale(an.s * an.sx, an.s * an.sy)
            val a = (an.a.coerceIn(0f, 1f) * 255).toInt()
            if (a < 250) c.saveLayerAlpha(-w / 2 - pad * 2, -h / 2 - pad * 2, w / 2 + pad * 2, h / 2 + pad * 2, a)
            if (t.box) { boxPaint.color = t.boxColor; c.drawRoundRect(-w / 2 - pad, -h / 2 - pad * 0.4f, w / 2 + pad, h / 2 + pad * 0.4f, pad, pad, boxPaint) }
            c.translate(-w / 2, -h / 2)
            st?.draw(c); fill.draw(c)
            c.restore()
        }
    }

    fun stateKey(items: List<TextItem>, ms: Long): String = items.joinToString(";") {
        val a = animFor(it, ms)
        if (a.a <= 0.003f) "h" else "%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.2f,%.2f".format(a.a, a.s, a.sx, a.sy, a.dx, a.dy, a.r, a.rv)
    }
}

/** Full-frame transparent bitmap overlay: same drawing code as the preview, so export matches exactly. */
class TextOverlayBmp(private val items: List<TextItem>, private val W: Int, private val H: Int) : BitmapOverlay() {
    private var last: Bitmap? = null
    private var lastKey = ""
    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000
        val key = TextRenderer.stateKey(items, ms)
        last?.let { if (key == lastKey) return it }
        val b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        TextRenderer.draw(Canvas(b), W, H, items, ms)
        last = b; lastKey = key
        return b
    }
}

/** Transparent layer on top of the player: draws texts, drag + pinch/rotate, and InShot-style corner handles. */
class OverlayView(ctx: Context) : View(ctx) {
    var items: List<TextItem> = emptyList()
    var time: () -> Long = { 0L }
    var selected: TextItem? = null
    var onSelect: (TextItem?) -> Unit = {}
    var onDelete: (TextItem) -> Unit = {}
    var onEditReq: (TextItem) -> Unit = {}
    var onBegin: () -> Unit = {}
    private val dn = resources.displayMetrics.density
    private val hr = 11f * dn
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 1.5f * dn
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.8f * dn; strokeCap = Paint.Cap.ROUND }
    private var mode = 0 // 1 drag, 2 pinch, 3 rotate handle
    private var dx0 = 0f; private var dy0 = 0f; private var ix0 = 0f; private var iy0 = 0f
    private var d0 = 1f; private var a0 = 0f; private var s0 = 0f; private var r0 = 0f
    private var began = false; private var moved = false; private var downHandle = 0

    private fun box(t: TextItem): FloatArray {
        val (w, h) = TextRenderer.size(t, height); val pad = t.sizeFrac * height * 0.35f
        return floatArrayOf(w / 2 + pad, h / 2 + pad)
    }

    override fun onDraw(c: Canvas) {
        val ms = time()
        TextRenderer.draw(c, width, height, items, ms)
        selected?.let { t ->
            if (ms in t.start..t.end) {
                val b = box(t); val hw = b[0]; val hh = b[1]
                c.save(); c.translate(t.x * width, t.y * height); c.rotate(t.rot)
                c.drawRect(-hw, -hh, hw, hh, dash)
                fillP.color = 0xFF7A6CFF.toInt(); c.drawCircle(-hw, -hh, hr, fillP)
                glyph.color = Color.WHITE
                c.drawLine(-hw - 4f * dn, -hh - 4f * dn, -hw + 4f * dn, -hh + 4f * dn, glyph); c.drawLine(-hw + 4f * dn, -hh - 4f * dn, -hw - 4f * dn, -hh + 4f * dn, glyph)
                fillP.color = Color.WHITE; c.drawCircle(hw, -hh, hr, fillP); c.drawCircle(hw, hh, hr, fillP)
                glyph.color = 0xFF222222.toInt()
                c.drawLine(hw - 4f * dn, -hh + 4f * dn, hw + 4f * dn, -hh - 4f * dn, glyph)
                c.drawArc(RectF(hw - 4.5f * dn, hh - 4.5f * dn, hw + 4.5f * dn, hh + 4.5f * dn), 30f, 270f, false, glyph)
                c.restore()
            }
        }
    }

    private fun toScreen(t: TextItem, lx: Float, ly: Float): FloatArray {
        val r = Math.toRadians(t.rot.toDouble()); val co = cos(r).toFloat(); val si = sin(r).toFloat()
        return floatArrayOf(t.x * width + lx * co - ly * si, t.y * height + lx * si + ly * co)
    }

    private fun handleAt(t: TextItem, px: Float, py: Float): Int {
        val b = box(t)
        val pts = listOf(toScreen(t, -b[0], -b[1]), toScreen(t, b[0], -b[1]), toScreen(t, b[0], b[1]))
        for ((i, q) in pts.withIndex()) if (hypot(px - q[0], py - q[1]) <= hr * 1.6f) return i + 1
        return 0
    }

    private fun hit(px: Float, py: Float): TextItem? {
        val ms = time()
        for (i in items.indices.reversed()) {
            val t = items[i]
            if (ms < t.start || ms > t.end) continue
            val b = box(t); val pad = 20f
            val dx = px - t.x * width; val dy = py - t.y * height
            val r = Math.toRadians(-t.rot.toDouble())
            val lx = (dx * cos(r) - dy * sin(r)).toFloat(); val ly = (dx * sin(r) + dy * cos(r)).toFloat()
            if (abs(lx) <= b[0] + pad && abs(ly) <= b[1] + pad) return t
        }
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                moved = false; began = false; downHandle = 0
                val sel = selected
                if (sel != null && time() in sel.start..sel.end) {
                    val h = handleAt(sel, e.x, e.y)
                    if (h != 0) {
                        downHandle = h
                        if (h == 3) { mode = 3; onBegin(); began = true
                            val cx = sel.x * width; val cy = sel.y * height
                            d0 = hypot(e.x - cx, e.y - cy).coerceAtLeast(1f); a0 = atan2(e.y - cy, e.x - cx); s0 = sel.sizeFrac; r0 = sel.rot }
                        else mode = 0
                        return true
                    }
                }
                val t = hit(e.x, e.y)
                if (t == null) { mode = 0; if (selected != null) { selected = null; onSelect(null); invalidate() }; return false }
                selected = t; onSelect(t); mode = 1
                dx0 = e.x; dy0 = e.y; ix0 = t.x; iy0 = t.y; invalidate(); return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                val t = selected ?: return true
                if (e.pointerCount == 2) {
                    if (!began) { began = true; onBegin() }
                    mode = 2
                    d0 = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)).coerceAtLeast(1f)
                    a0 = atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0)); s0 = t.sizeFrac; r0 = t.rot
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val t = selected ?: return true
                if (mode == 2 && e.pointerCount >= 2) {
                    val d = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
                    val a = atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0))
                    t.sizeFrac = (s0 * d / d0).coerceIn(0.02f, 0.7f)
                    t.rot = r0 + Math.toDegrees((a - a0).toDouble()).toFloat(); invalidate()
                } else if (mode == 3) {
                    val cx = t.x * width; val cy = t.y * height
                    val d = hypot(e.x - cx, e.y - cy); val a = atan2(e.y - cy, e.x - cx)
                    t.sizeFrac = (s0 * d / d0).coerceIn(0.02f, 0.7f)
                    t.rot = r0 + Math.toDegrees((a - a0).toDouble()).toFloat(); invalidate()
                } else if (mode == 1) {
                    if (abs(e.x - dx0) + abs(e.y - dy0) > 4f) moved = true
                    if (moved && !began) { began = true; onBegin() }
                    if (moved) { t.x = (ix0 + (e.x - dx0) / width).coerceIn(0f, 1f); t.y = (iy0 + (e.y - dy0) / height).coerceIn(0f, 1f); invalidate() }
                }
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val t = selected
                if (mode == 2 && t != null) { mode = 1; val i = if (e.actionIndex == 0) 1 else 0; dx0 = e.getX(i); dy0 = e.getY(i); ix0 = t.x; iy0 = t.y }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val t = selected
                if (e.actionMasked == MotionEvent.ACTION_UP && t != null && downHandle in 1..2) { if (downHandle == 1) onDelete(t) else onEditReq(t) }
                mode = 0; downHandle = 0; return true
            }
        }
        return true
    }
}
