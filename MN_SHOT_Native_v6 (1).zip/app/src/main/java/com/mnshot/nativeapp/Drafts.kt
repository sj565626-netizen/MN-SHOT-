package com.mnshot.nativeapp

import android.content.Context
import org.json.JSONObject
import java.io.File

object Drafts {
    fun dir(c: Context): File = File(c.filesDir, "drafts").apply { mkdirs() }
    fun thumb(c: Context, id: String) = File(dir(c), "$id.jpg")
    fun list(c: Context): List<JSONObject> =
        (dir(c).listFiles { f -> f.extension == "json" } ?: emptyArray())
            .mapNotNull { try { JSONObject(it.readText()) } catch (e: Exception) { null } }
            .sortedByDescending { it.optLong("saved") }
    fun save(c: Context, j: JSONObject) { File(dir(c), j.getString("id") + ".json").writeText(j.toString()) }
    fun load(c: Context, id: String): JSONObject? = try { JSONObject(File(dir(c), "$id.json").readText()) } catch (e: Exception) { null }
    fun delete(c: Context, id: String) { File(dir(c), "$id.json").delete(); thumb(c, id).delete() }
}
