@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.mnshot.nativeapp

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.google.android.material.slider.RangeSlider
import com.google.common.collect.ImmutableList
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val C_BG = 0xFF0E0E12.toInt()
private val C_PANEL = 0xFF1C1C22.toInt()
private val C_CHIP = 0xFF2A2A33.toInt()
private val C_ACC = 0xFF7A6CFF.toInt()
private val C_MUTED = 0xFF8C8C96.toInt()

data class Clip(val uri: Uri, val dur: Long, var start: Long, var end: Long, val w: Int, val h: Int, var speed: Float = 1f,
                var bri: Float = 0f, var con: Float = 0f, var sat: Float = 0f, var warm: Float = 0f, var gray: Boolean = false, var mute: Boolean = false) {
    val effMs: Long get() = ((end - start) / speed).toLong()
}

private class Snap(val clips: List<Clip>, val texts: List<TextItem>)
private class Tool(val icon: Int, val label: String, val enabled: Boolean = true, val danger: Boolean = false, val onClick: () -> Unit)

class MainActivity : AppCompatActivity() {
    private val clips = mutableListOf<Clip>()
    private var sel = -1
    private var clipSel = false
    private val texts = mutableListOf<TextItem>()
    private var selText: TextItem? = null
    private var ratio = "orig"
    private var fill = false
    private var bgColor = Color.BLACK
    private var musicUri: Uri? = null
    private var musicDur = 0L
    private var musicVol = 0.8f
    private var draftId = System.currentTimeMillis().toString()
    private val projTitle = "MN SHOT " + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private val undoS = ArrayList<Snap>()
    private val redoS = ArrayList<Snap>()
    private var sheetOpen = false
    private var expRes = 720
    private var expFps = 30

    private lateinit var player: ExoPlayer
    private lateinit var musicPlayer: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var previewBox: FrameLayout
    private lateinit var frame: FrameLayout
    private lateinit var overlay: OverlayView
    private lateinit var timeline: TimelineView
    private lateinit var playBtn: ImageView
    private lateinit var undoBtn: ImageView
    private lateinit var redoBtn: ImageView
    private lateinit var timeLabel: TextView
    private lateinit var muteIcon: ImageView
    private lateinit var bottomHost: LinearLayout
    private lateinit var exportScreen: FrameLayout
    private lateinit var expPreview: ImageView
    private lateinit var expPreviewBox: FrameLayout
    private lateinit var expHolder: FrameLayout
    private lateinit var estLabel: TextView
    private var lastPlaying = false
    private val ui = Handler(Looper.getMainLooper())
    private val pollH = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (list.isNotEmpty()) {
            if (clips.isNotEmpty()) pushUndo()
            list.forEach { u -> try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }; addClip(u) }
            if (sel < 0 && clips.isNotEmpty()) sel = 0
            refresh(true)
        } else if (clips.isEmpty()) finish()
    }
    private val musicPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }; setMusic(uri) } }
    private val fontPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) importFont(uri) }

    private val ticker = object : Runnable { override fun run() {
        if (::overlay.isInitialized) {
            overlay.invalidate()
            val tot = clips.sumOf { it.effMs }; val g = globalPos().coerceIn(0, maxOf(tot, 0))
            timeline.totalMs = tot
            if (!timeline.dragging) timeline.curMs = g
            timeline.invalidate()
            timeLabel.text = "%s / %s".format(fmt(g), fmt(tot))
            if (player.isPlaying != lastPlaying) { lastPlaying = player.isPlaying; playBtn.setImageResource(if (lastPlaying) R.drawable.ic_pause else R.drawable.ic_play) }
        }
        ui.postDelayed(this, 33) } }

    private fun fmt(ms: Long): String { val t = ms / 100; return "%d:%02d.%d".format(t / 600, (t / 10) % 60, t % 10) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun ico(res: Int, size: Int = 44, tint: Int = Color.WHITE, onClick: (() -> Unit)? = null): ImageView = ImageView(this).apply {
        setImageResource(res); setColorFilter(tint); val pd = dp((size - 24) / 2); setPadding(pd, pd, pd, pd)
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)); onClick?.let { cb -> setOnClickListener { cb() } } }

    private fun chip(label: String, selected: Boolean = false, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 12f; setTextColor(Color.WHITE); setPadding(dp(14), dp(9), dp(14), dp(9)); gravity = Gravity.CENTER
        background = GradientDrawable().apply { setColor(if (selected) C_ACC else C_CHIP); cornerRadius = dpf(18f) }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        setOnClickListener { onClick() } }

    // ------------------------------------------------------------------ UI
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C_BG; window.navigationBarColor = C_BG
        TextRenderer.fontDir = File(filesDir, "fonts").apply { mkdirs() }
        player = ExoPlayer.Builder(this).build(); musicPlayer = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { applyPerClip() }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (musicUri == null) return
                if (isPlaying) { musicPlayer.seekTo(globalPos()); musicPlayer.play() } else musicPlayer.pause()
            }
        })
        buildUi()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() {
            when {
                exportScreen.visibility == View.VISIBLE -> exportScreen.visibility = View.GONE
                sheetOpen -> closeSheet()
                selText != null || clipSel -> deselectAll()
                else -> confirmExit() } } })
        val d = intent.getStringExtra("draft")
        if (d != null) loadDraft(d) else if (intent.getBooleanExtra("pick", false)) picker.launch(arrayOf("video/*"))
        ui.post(ticker)
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(C_BG) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(6), dp(12), dp(6)) }
        top.addView(ico(R.drawable.ic_back) { onBackPressedDispatcher.onBackPressed() })
        top.addView(TextView(this).apply { text = projTitle; setTextColor(C_MUTED); textSize = 12f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply { text = "Export"; setTextColor(Color.WHITE); textSize = 13f; setTypeface(null, Typeface.BOLD); setPadding(dp(18), dp(8), dp(18), dp(8))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF7A6CFF.toInt(), 0xFF38B6FF.toInt())).apply { cornerRadius = dpf(18f) }
            setOnClickListener { openExport() } })
        col.addView(top)

        frame = FrameLayout(this); previewBox = FrameLayout(this)
        playerView = PlayerView(this).apply { this.player = this@MainActivity.player; useController = false; setBackgroundColor(bgColor) }
        previewBox.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        overlay = OverlayView(this).apply {
            items = texts; time = { globalPos() }
            onSelect = { t -> if (t == null) deselectAll() else selectText(t, false) }
            onDelete = { t -> pushUndo(); texts.remove(t); deselectAll() }
            onEditReq = { t -> textSheet(t) }
            onBegin = { pushUndo() } }
        previewBox.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        frame.addView(previewBox, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        frame.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob -> if (r - l != orr - ol || b - t != ob - ot) fitPreview() }
        col.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        val ctl = FrameLayout(this).apply { setPadding(dp(8), 0, dp(12), 0) }
        val left = LinearLayout(this)
        undoBtn = ico(R.drawable.ic_undo) { undo() }; redoBtn = ico(R.drawable.ic_redo) { redo() }
        left.addView(undoBtn); left.addView(redoBtn)
        ctl.addView(left, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL))
        playBtn = ico(R.drawable.ic_play) { if (player.isPlaying) player.pause() else { if (player.playbackState == Player.STATE_ENDED) player.seekTo(0, 0); player.play() } }
        ctl.addView(playBtn, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
        timeLabel = TextView(this).apply { text = "0:00.0 / 0:00.0"; setTextColor(C_MUTED); textSize = 11f }
        ctl.addView(timeLabel, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        col.addView(ctl, LinearLayout.LayoutParams(-1, dp(48)))
        updateUndoUi()

        val tlWrap = FrameLayout(this)
        timeline = TimelineView(this).apply {
            clips = this@MainActivity.clips; texts = this@MainActivity.texts
            onSeek = { ms -> seekGlobal(ms) }
            onSelectClip = { i -> if (i < 0) deselectAll() else selectClip(i) }
            onSelectText = { t -> if (t == null) deselectAll() else selectText(t, true) }
            onBeginEdit = { pushUndo() }
            onTextEdited = { overlay.invalidate() } }
        tlWrap.addView(timeline, FrameLayout.LayoutParams(-1, -1))
        val plus = FrameLayout(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF4F6BFF.toInt()) }; elevation = dpf(4f)
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_plus) }, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            setOnClickListener { picker.launch(arrayOf("video/*")) } }
        tlWrap.addView(plus, FrameLayout.LayoutParams(dp(38), dp(38), Gravity.START or Gravity.TOP).apply { leftMargin = dp(10); topMargin = dp(79) })
        muteIcon = ImageView(this).apply { setImageResource(R.drawable.ic_volume); setColorFilter(C_MUTED) }
        val mute = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(2), dp(8), dp(2))
            addView(muteIcon, LinearLayout.LayoutParams(dp(14), dp(14)))
            addView(TextView(this@MainActivity).apply { text = " Mute clip"; textSize = 9f; setTextColor(C_MUTED) })
            setOnClickListener { toggleMute() } }
        tlWrap.addView(mute, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.TOP).apply { topMargin = dp(124) })
        col.addView(tlWrap, LinearLayout.LayoutParams(-1, dp(148)))

        bottomHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C_BG) }
        col.addView(bottomHost, LinearLayout.LayoutParams(-1, -2))
        exportScreen = buildExportScreen()
        root.addView(col, FrameLayout.LayoutParams(-1, -1)); root.addView(exportScreen, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        showToolbar()
    }

    // ------------------------------------------------------------------ project / player
    private fun addClip(uri: Uri) {
        try {
            val r = MediaMetadataRetriever(); r.setDataSource(this, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toInt() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toInt() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
            r.release()
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            if (dur > 0) clips.add(Clip(uri, dur, 0, dur, w, h))
        } catch (e: Exception) { toast("Could not open this video") }
    }

    private fun mediaItem(c: Clip) = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(
        MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.start).setEndPositionMs(c.end).build()).build()

    private fun refresh(reload: Boolean) {
        if (reload) {
            val keep = if (player.mediaItemCount > 0) globalPos() else -1L
            if (clips.isEmpty()) player.clearMediaItems()
            else { player.setMediaItems(clips.map { mediaItem(it) }, maxOf(sel, 0), 0); player.prepare(); if (keep >= 0) seekGlobal(keep) }
        }
        applyPerClip(); fitPreview(); timeline.invalidate()
    }

    private fun applyPerClip() {
        val c = clips.getOrNull(player.currentMediaItemIndex)
        player.setPlaybackSpeed(c?.speed ?: 1f); player.volume = if (c?.mute == true) 0f else 1f
        player.setVideoEffects(if (c == null) emptyList() else fxList(c))
        val tc = clips.getOrNull(if (clipSel) sel else player.currentMediaItemIndex)
        muteIcon.setImageResource(if (tc?.mute == true) R.drawable.ic_mute else R.drawable.ic_volume)
    }

    private fun fxList(c: Clip): List<Effect> {
        val l = mutableListOf<Effect>()
        if (c.gray) l.add(RgbFilter.createGrayscaleFilter())
        if (c.bri != 0f) l.add(Brightness(c.bri))
        if (c.con != 0f) l.add(Contrast(c.con))
        if (c.sat != 0f) l.add(HslAdjustment.Builder().adjustSaturation(c.sat * 100f).build())
        if (c.warm != 0f) l.add(RgbAdjustment.Builder().setRedScale(1f + c.warm * 0.25f).setBlueScale(1f - c.warm * 0.25f).build())
        return l
    }

    private fun globalPos(): Long {
        val i = player.currentMediaItemIndex
        val before = clips.take(i).sumOf { it.effMs }
        val sp = clips.getOrNull(i)?.speed ?: 1f
        return before + (player.currentPosition / sp).toLong()
    }

    private fun seekGlobal(ms: Long) {
        var acc = 0L
        for ((i, c) in clips.withIndex()) {
            if (ms < acc + c.effMs || i == clips.lastIndex) { player.seekTo(i, ((ms - acc).coerceAtLeast(0) * c.speed).toLong()); break }
            acc += c.effMs
        }
    }

    private fun aspectOf(r: String): Float = when (r) {
        "9:16" -> 9f / 16f; "16:9" -> 16f / 9f; "1:1" -> 1f; "4:5" -> 0.8f; "3:4" -> 0.75f
        else -> clips.firstOrNull()?.let { if (it.h > 0) it.w.toFloat() / it.h else 9f / 16f } ?: (9f / 16f) }
    private fun aspect() = aspectOf(ratio)

    private fun canvasDims(short: Int): Pair<Int, Int> {
        val a = aspect()
        val w = if (a < 1f) short else (short * a).toInt(); val h = if (a < 1f) (short / a).toInt() else short
        return Pair(w / 2 * 2, h / 2 * 2)
    }

    private fun fitPreview() { frame.post {
        val aw = frame.width; val ah = frame.height; if (aw == 0 || ah == 0) return@post
        val asp = aspect()
        var w = aw; var h = (w / asp).toInt(); if (h > ah) { h = ah; w = (h * asp).toInt() }
        val lp = previewBox.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h) { lp.width = w; lp.height = h; lp.gravity = Gravity.CENTER; previewBox.layoutParams = lp }
        playerView.resizeMode = if (fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
        playerView.setBackgroundColor(bgColor); playerView.setShutterBackgroundColor(bgColor)
    } }

    // ------------------------------------------------------------------ undo / redo
    private fun snap() = Snap(clips.map { it.copy() }, texts.map { it.copy() })
    private fun pushUndo() { undoS.add(snap()); if (undoS.size > 40) undoS.removeAt(0); redoS.clear(); updateUndoUi() }
    private fun restore(s: Snap) {
        clips.clear(); clips.addAll(s.clips.map { it.copy() }); texts.clear(); texts.addAll(s.texts.map { it.copy() })
        sel = if (clips.isEmpty()) -1 else sel.coerceIn(0, clips.size - 1)
        selText = null; overlay.selected = null; timeline.selText = null; clipSel = false; timeline.selClip = -1
        refresh(true); showToolbar()
    }
    private fun undo() { if (undoS.isEmpty()) return; redoS.add(snap()); restore(undoS.removeAt(undoS.size - 1)); updateUndoUi() }
    private fun redo() { if (redoS.isEmpty()) return; undoS.add(snap()); restore(redoS.removeAt(redoS.size - 1)); updateUndoUi() }
    private fun updateUndoUi() { undoBtn.alpha = if (undoS.isEmpty()) 0.35f else 1f; redoBtn.alpha = if (redoS.isEmpty()) 0.35f else 1f }

    // ------------------------------------------------------------------ selection + toolbar
    private fun selectText(t: TextItem, seek: Boolean) {
        selText = t; clipSel = false; overlay.selected = t; timeline.selText = t; timeline.selClip = -1
        if (seek && globalPos() !in t.start..t.end) seekGlobal(t.start + 1)
        showToolbar()
    }
    private fun selectClip(i: Int) { sel = i; clipSel = true; selText = null; overlay.selected = null; timeline.selText = null; timeline.selClip = i; applyPerClip(); showToolbar() }
    private fun deselectAll() { selText = null; clipSel = false; overlay.selected = null; timeline.selText = null; timeline.selClip = -1; applyPerClip(); showToolbar() }
    private fun targetIdx() = if (clipSel && sel in clips.indices) sel else player.currentMediaItemIndex.coerceIn(0, maxOf(0, clips.size - 1))
    private fun soon(n: String) = toast("$n is coming in the next stage")

    private fun showToolbar() {
        sheetOpen = false
        val st = selText
        val list: List<Tool> = when {
            st != null -> listOf(
                Tool(R.drawable.ic_back, "Back") { deselectAll() },
                Tool(R.drawable.ic_edit, "Edit") { textSheet(st) },
                Tool(R.drawable.ic_split, "Split", enabled = false) { },
                Tool(R.drawable.ic_copy, "Duplicate") { pushUndo(); val n = st.copy(x = (st.x + 0.04f).coerceAtMost(1f), y = (st.y + 0.04f).coerceAtMost(1f)); texts.add(n); selectText(n, false) },
                Tool(R.drawable.ic_trash, "Delete", danger = true) { pushUndo(); texts.remove(st); deselectAll() })
            clipSel && sel in clips.indices -> listOf(
                Tool(R.drawable.ic_back, "Back") { deselectAll() },
                Tool(R.drawable.ic_trim, "Trim") { trimSheet() },
                Tool(R.drawable.ic_split, "Split") { splitAtPlayhead() },
                Tool(R.drawable.ic_speed, "Speed") { speedSheet() },
                Tool(R.drawable.ic_filter, "Filter") { filterSheet() },
                Tool(R.drawable.ic_adjust, "Adjust") { adjustSheet() },
                Tool(R.drawable.ic_copy, "Duplicate") { pushUndo(); clips.add(sel + 1, clips[sel].copy()); refresh(true) },
                Tool(R.drawable.ic_trash, "Delete", danger = true) { deleteClip() })
            else -> listOf(
                Tool(R.drawable.ic_canvas, "Canvas") { canvasSheet() },
                Tool(R.drawable.ic_audio, "Audio") { audioSheet() },
                Tool(R.drawable.ic_sticker, "Sticker") { soon("Sticker") },
                Tool(R.drawable.ic_text, "Text") { addText() },
                Tool(R.drawable.ic_effect, "Effect") { soon("Effects") },
                Tool(R.drawable.ic_filter, "Filter") { filterSheet() },
                Tool(R.drawable.ic_adjust, "Adjust") { adjustSheet() },
                Tool(R.drawable.ic_pip, "PIP") { soon("PIP") })
        }
        val row = LinearLayout(this)
        list.forEach { t ->
            val tint = if (!t.enabled) 0x55FFFFFF else if (t.danger) 0xFFFF5A5A.toInt() else Color.WHITE
            val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(6), dp(8), dp(6), dp(6)); minimumWidth = dp(66)
                addView(ImageView(this@MainActivity).apply { setImageResource(t.icon); setColorFilter(tint) }, LinearLayout.LayoutParams(dp(24), dp(24)))
                addView(TextView(this@MainActivity).apply { text = t.label; textSize = 10f; setTextColor(if (t.danger) tint else if (t.enabled) 0xFFCFCFD6.toInt() else 0x55FFFFFF); setPadding(0, dp(3), 0, 0) })
                if (t.enabled) setOnClickListener { t.onClick() } }
            row.addView(v)
        }
        bottomHost.removeAllViews()
        bottomHost.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
    }

    private fun openSheet(title: String, content: View, heightDp: Int = 250) {
        sheetOpen = true
        val r = dpf(16f)
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(C_PANEL); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) } }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), 0, 0, 0) }
        head.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(ico(R.drawable.ic_check) { closeSheet() })
        panel.addView(head, LinearLayout.LayoutParams(-1, dp(44)))
        panel.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(-1, dp(heightDp)))
        bottomHost.removeAllViews(); bottomHost.addView(panel)
    }
    private fun closeSheet() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(window.decorView.windowToken, 0)
        showToolbar()
    }

    private fun lbl(box: LinearLayout, s: String) = box.addView(TextView(this).apply { text = s; setTextColor(C_MUTED); textSize = 12f; setPadding(0, dp(12), 0, dp(4)) })
    private fun vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(16)) }

    private fun chipRow(opts: List<Pair<String, String>>, cur: String, onPick: (String) -> Unit): View {
        val row = LinearLayout(this); val tvs = ArrayList<TextView>()
        opts.forEach { (v, label) ->
            val b = chip(label, v == cur) { }
            tvs.add(b)
            b.setOnClickListener { tvs.forEach { x -> (x.background as GradientDrawable).setColor(C_CHIP) }; (b.background as GradientDrawable).setColor(C_ACC); onPick(v); overlay.invalidate() }
            row.addView(b) }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun slide(box: LinearLayout, label: String, min: Int, max: Int, cur: Int, onChange: (Int) -> Unit) {
        lbl(box, label)
        box.addView(SeekBar(this).apply { this.max = max - min; progress = (cur - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) { onChange(p + min); overlay.invalidate() } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {} }) })
    }

    // ------------------------------------------------------------------ clip tools
    private fun deleteClip() {
        if (sel !in clips.indices) return
        pushUndo(); clips.removeAt(sel); sel = if (clips.isEmpty()) -1 else minOf(sel, clips.size - 1)
        clipSel = false; timeline.selClip = -1; refresh(true); showToolbar()
    }

    private fun splitAtPlayhead() {
        val i = player.currentMediaItemIndex; val c = clips.getOrNull(i) ?: return
        val at = c.start + player.currentPosition
        if (at - c.start < 300 || c.end - at < 300) { toast("Move the playhead inside the clip first"); return }
        pushUndo(); clips.add(i + 1, c.copy(start = at)); c.end = at; sel = i; refresh(true)
    }

    private fun toggleMute() {
        val i = targetIdx(); val c = clips.getOrNull(i) ?: return
        pushUndo(); c.mute = !c.mute; applyPerClip(); toast(if (c.mute) "Clip muted" else "Clip sound on")
    }

    private fun trimSheet() {
        val c = clips.getOrNull(sel) ?: return
        val box = vbox(); val label = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f }
        fun txt(s: Long, e: Long) { label.text = "%.1fs – %.1fs  (source length %.1fs)".format(s / 1000.0, e / 1000.0, c.dur / 1000.0) }
        txt(c.start, c.end); box.addView(label)
        val rs = RangeSlider(this).apply { valueFrom = 0f; valueTo = c.dur.toFloat(); values = listOf(c.start.toFloat(), c.end.toFloat())
            addOnChangeListener { s, _, _ -> txt(s.values[0].toLong(), s.values[1].toLong()) }
            addOnSliderTouchListener(object : RangeSlider.OnSliderTouchListener {
                override fun onStartTrackingTouch(s: RangeSlider) { pushUndo() }
                override fun onStopTrackingTouch(s: RangeSlider) {
                    var a = s.values[0].toLong(); var b = s.values[1].toLong()
                    if (b - a < 300) { if (a + 300 <= c.dur) b = a + 300 else a = b - 300 }
                    c.start = a; c.end = b; refresh(true) } }) }
        box.addView(rs); openSheet("Trim", box, 130)
    }

    private fun speedSheet() {
        val c = clips.getOrNull(sel) ?: return
        val box = vbox(); val opts = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
        lbl(box, "Clip speed")
        box.addView(chipRow(opts.map { it.toString() to "${it}x" }, c.speed.toString()) { v -> pushUndo(); c.speed = v.toFloat(); applyPerClip(); timeline.invalidate() })
        openSheet("Speed", box, 110)
    }

    private fun presetRow(c: Clip, afterApply: () -> Unit): View {
        val presets = listOf(
            "None" to floatArrayOf(0f, 0f, 0f, 0f, 0f), "B&W" to floatArrayOf(0f, .1f, 0f, 0f, 1f), "Warm" to floatArrayOf(.03f, .05f, .15f, .5f, 0f),
            "Cool" to floatArrayOf(0f, .05f, .1f, -.5f, 0f), "Vivid" to floatArrayOf(.02f, .2f, .5f, 0f, 0f), "Fade" to floatArrayOf(.12f, -.25f, -.2f, .1f, 0f),
            "Dramatic" to floatArrayOf(-.05f, .4f, -.15f, 0f, 0f), "Vintage" to floatArrayOf(.05f, -.1f, -.3f, .6f, 0f), "Bright" to floatArrayOf(.15f, .05f, .15f, 0f, 0f),
            "Noir" to floatArrayOf(-.1f, .5f, 0f, 0f, 1f))
        return chipRow(presets.map { it.first to it.first }, "") { name ->
            val v = presets.first { it.first == name }.second
            c.bri = v[0]; c.con = v[1]; c.sat = v[2]; c.warm = v[3]; c.gray = v[4] == 1f; applyPerClip(); afterApply() }
    }

    private fun filterSheet() {
        if (clips.isEmpty()) { toast("Add a video first"); return }
        val c = clips[targetIdx()]; pushUndo()
        val box = vbox(); lbl(box, "Filters")
        box.addView(presetRow(c) { })
        box.addView(chip("Apply to all clips") { clips.forEach { o -> o.bri = c.bri; o.con = c.con; o.sat = c.sat; o.warm = c.warm; o.gray = c.gray }; applyPerClip(); toast("Applied to all clips") })
        openSheet("Filter", box, 150)
    }

    private fun adjustSheet() {
        if (clips.isEmpty()) { toast("Add a video first"); return }
        val c = clips[targetIdx()]; pushUndo()
        val box = vbox()
        slide(box, "Brightness", -100, 100, (c.bri * 100).toInt()) { c.bri = it / 100f; applyPerClip() }
        slide(box, "Contrast", -100, 100, (c.con * 100).toInt()) { c.con = it / 100f; applyPerClip() }
        slide(box, "Saturation", -100, 100, (c.sat * 100).toInt()) { c.sat = it / 100f; applyPerClip() }
        slide(box, "Warmth", -100, 100, (c.warm * 100).toInt()) { c.warm = it / 100f; applyPerClip() }
        box.addView(chip("Reset") { c.bri = 0f; c.con = 0f; c.sat = 0f; c.warm = 0f; c.gray = false; applyPerClip(); adjustSheet() })
        openSheet("Adjust", box, 300)
    }

    // ------------------------------------------------------------------ canvas
    private fun canvasSheet() {
        val box = vbox()
        fun rebuild() {
            box.removeAllViews()
            lbl(box, "Ratio")
            val row = LinearLayout(this)
            listOf("orig" to "Original", "9:16" to "9:16", "16:9" to "16:9", "1:1" to "1:1", "4:5" to "4:5", "3:4" to "3:4").forEach { (k, label) ->
                val a = aspectOf(k); val mw = if (a >= 1f) 28 else (28 * a).toInt(); val mh = if (a >= 1f) (28 / a).toInt() else 28
                val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(10), dp(6), dp(10), dp(6))
                    addView(View(this@MainActivity).apply { background = GradientDrawable().apply { setColor(Color.TRANSPARENT); cornerRadius = dpf(4f); setStroke(dp(2), if (ratio == k) Color.WHITE else C_MUTED) } },
                        LinearLayout.LayoutParams(dp(mw), dp(mh)).apply { bottomMargin = dp(4) })
                    addView(TextView(this@MainActivity).apply { text = label; textSize = 10f; setTextColor(if (ratio == k) Color.WHITE else C_MUTED) })
                    setOnClickListener { ratio = k; fitPreview(); rebuild() } }
                row.addView(v, LinearLayout.LayoutParams(-2, dp(68)))
            }
            box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
            lbl(box, "Background")
            val cr = LinearLayout(this)
            intArrayOf(Color.BLACK, Color.WHITE, 0xFF1A1F3B.toInt(), 0xFFFF5A7A.toInt(), 0xFFFF9F43.toInt(), 0xFFFFD93D.toInt(), 0xFF2ED573.toInt(), 0xFF38B6FF.toInt(), 0xFF7A6CFF.toInt()).forEach { col ->
                cr.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(col); setStroke(dp(if (bgColor == col) 3 else 1), if (bgColor == col) Color.WHITE else C_MUTED) }
                    setOnClickListener { bgColor = col; fitPreview(); rebuild() } }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { setMargins(dp(5), dp(4), dp(5), dp(4)) })
            }
            box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(cr) })
            lbl(box, "Video fit")
            val fr = LinearLayout(this)
            fr.addView(chip("Fit", !fill) { fill = false; fitPreview(); rebuild() }); fr.addView(chip("Fill", fill) { fill = true; fitPreview(); rebuild() })
            box.addView(fr)
        }
        rebuild(); openSheet("Canvas", box, 270)
    }

    // ------------------------------------------------------------------ audio
    private fun setMusic(uri: Uri) {
        try { val r = MediaMetadataRetriever(); r.setDataSource(this, uri); musicDur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L; r.release() }
        catch (e: Exception) { toast("Could not open this audio"); return }
        musicUri = uri; musicPlayer.setMediaItem(MediaItem.fromUri(uri)); musicPlayer.prepare(); musicPlayer.volume = musicVol
        toast("Music added")
    }

    private fun audioSheet() {
        val box = vbox()
        box.addView(chip(if (musicUri == null) "+ Add music" else "Change music") { musicPicker.launch(arrayOf("audio/*")) })
        slide(box, "Music volume", 0, 100, (musicVol * 100).toInt()) { musicVol = it / 100f; musicPlayer.volume = musicVol }
        val row = LinearLayout(this)
        row.addView(chip("Mute clip sound") { toggleMute() })
        row.addView(chip("Remove music") { musicUri = null; musicPlayer.stop(); musicPlayer.clearMediaItems(); toast("Music removed") })
        box.addView(row)
        openSheet("Audio", box, 200)
    }

    // ------------------------------------------------------------------ text
    private fun addText() {
        if (clips.isEmpty()) { toast("Add a video first"); return }
        pushUndo()
        val tot = clips.sumOf { it.effMs }
        val st = globalPos().coerceAtMost(maxOf(0L, tot - 500))
        val t = TextItem(start = st, end = minOf(st + 3000, tot))
        texts.add(t); selectText(t, false); textSheet(t)
    }

    private fun importFont(uri: Uri) {
        try {
            val name = (uri.lastPathSegment ?: "font").substringAfterLast('/').substringAfterLast(':').let { if (it.contains('.')) it else "$it.ttf" }
            val f = File(TextRenderer.fontDir, name)
            contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            Typeface.createFromFile(f)
            TextRenderer.clearCache(); selText?.font = "file:$name"; overlay.invalidate()
            toast("Font added. Reopen Edit to see it in the list.")
        } catch (e: Exception) { toast("This font file could not be loaded") }
    }

    private val swatches = IntArray(42) { i ->
        if (i < 6) intArrayOf(Color.WHITE, 0xFFCCCCCC.toInt(), 0xFF777777.toInt(), 0xFF333333.toInt(), Color.BLACK, 0xFFFFD24A.toInt())[i]
        else { val k = i - 6; Color.HSVToColor(floatArrayOf((k % 12) * 30f, if (k / 12 == 1) 0.45f else 1f, if (k / 12 == 2) 0.6f else 1f)) }
    }

    private fun colorRow(onPick: (Int) -> Unit): View {
        val row = LinearLayout(this)
        swatches.forEach { c -> row.addView(View(this).apply { setBackgroundColor(c)
            layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
            setOnClickListener { onPick(c); overlay.invalidate() } }) }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun previewText(t: TextItem) { seekGlobal(maxOf(0L, t.start - 300)); player.play() }

    private fun textSheet(t: TextItem) {
        pushUndo()
        val tot = clips.sumOf { it.effMs }.coerceAtLeast(1000L)
        val box = vbox()
        box.addView(EditText(this).apply { setText(t.text); hint = "Type your text"; setTextColor(Color.WHITE); setHintTextColor(C_MUTED); setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply { setColor(Color.TRANSPARENT); cornerRadius = dpf(10f); setStroke(dp(2), C_ACC) }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { t.text = e?.toString()?.ifEmpty { " " } ?: " "; overlay.invalidate() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {} }) })
        lbl(box, "Font")
        val fonts = FONT_FAMILIES.map { it to it.removePrefix("sans-serif-").replace("sans-serif", "sans") } +
            (TextRenderer.fontDir?.listFiles()?.map { "file:${it.name}" to it.nameWithoutExtension } ?: emptyList())
        box.addView(chipRow(fonts, t.font) { t.font = it })
        box.addView(chip("+ Import font (.ttf / .otf)") { fontPicker.launch("*/*") })
        val tg = LinearLayout(this)
        fun cb(label: String, init: Boolean, set: (Boolean) -> Unit) = tg.addView(CheckBox(this).apply { text = label; setTextColor(Color.WHITE); isChecked = init
            setOnCheckedChangeListener { _, v -> set(v); overlay.invalidate() } })
        cb("Bold", t.bold) { t.bold = it }; cb("Italic", t.italic) { t.italic = it }; cb("Outline", t.outline) { t.outline = it }
        cb("Shadow", t.shadow) { t.shadow = it }; cb("Box", t.box) { t.box = it }
        box.addView(HorizontalScrollView(this).apply { addView(tg) })
        slide(box, "Size", 2, 40, (t.sizeFrac * 100).toInt()) { t.sizeFrac = it / 100f }
        lbl(box, "Text colour"); box.addView(colorRow { t.color = it })
        lbl(box, "Outline colour"); box.addView(colorRow { t.outlineColor = it; t.outline = true })
        slide(box, "Outline width", 2, 30, (t.outlineW * 100).toInt()) { t.outlineW = it / 100f; t.outline = true }
        lbl(box, "Shadow colour"); box.addView(colorRow { t.shadowColor = it; t.shadow = true })
        lbl(box, "Box colour"); box.addView(colorRow { t.boxColor = (it and 0x00FFFFFF) or 0xCC000000.toInt(); t.box = true })
        val inOpts = TXT_IN.map { it to it }
        lbl(box, "Intro animation"); box.addView(chipRow(inOpts, t.aIn) { t.aIn = it; if (it != "none") previewText(t) })
        lbl(box, "Outro animation"); box.addView(chipRow(inOpts, t.aOut) { t.aOut = it; if (it != "none") previewText(t) })
        lbl(box, "Loop animation"); box.addView(chipRow(TXT_LOOP.map { it to it }, t.aLoop) { t.aLoop = it; if (it != "none") previewText(t) })
        slide(box, "Intro / outro duration (ms)", 200, 2000, t.aDur.toInt()) { t.aDur = it.toLong() }
        lbl(box, "Show from – to")
        box.addView(RangeSlider(this).apply { valueFrom = 0f; valueTo = tot.toFloat()
            values = listOf(t.start.coerceIn(0, tot).toFloat(), t.end.coerceIn(0, tot).toFloat())
            addOnChangeListener { sl, _, _ -> t.start = sl.values[0].toLong(); t.end = maxOf(sl.values[1].toLong(), t.start + 300); overlay.invalidate() } })
        openSheet("Text", box, 280)
    }

    // ------------------------------------------------------------------ drafts
    private fun textJson(t: TextItem) = JSONObject().put("text", t.text).put("size", t.sizeFrac.toDouble()).put("color", t.color).put("x", t.x.toDouble()).put("y", t.y.toDouble())
        .put("rot", t.rot.toDouble()).put("bold", t.bold).put("italic", t.italic).put("font", t.font).put("outline", t.outline).put("outlineColor", t.outlineColor)
        .put("outlineW", t.outlineW.toDouble()).put("shadow", t.shadow).put("shadowColor", t.shadowColor).put("box", t.box).put("boxColor", t.boxColor)
        .put("start", t.start).put("end", t.end).put("aIn", t.aIn).put("aOut", t.aOut).put("aLoop", t.aLoop).put("aDur", t.aDur)

    private fun textFrom(o: JSONObject) = TextItem(o.optString("text", "Your text"), o.optDouble("size", 0.07).toFloat(), o.optInt("color", Color.WHITE),
        o.optDouble("x", 0.5).toFloat(), o.optDouble("y", 0.5).toFloat(), o.optDouble("rot", 0.0).toFloat(), o.optBoolean("bold", true), o.optBoolean("italic", false),
        o.optString("font", "sans-serif"), o.optBoolean("outline", true), o.optInt("outlineColor", Color.BLACK), o.optDouble("outlineW", 0.12).toFloat(),
        o.optBoolean("shadow", false), o.optInt("shadowColor", Color.BLACK), o.optBoolean("box", false), o.optInt("boxColor", 0xCC000000.toInt()),
        o.optLong("start", 0), o.optLong("end", 3000), o.optString("aIn", "none"), o.optString("aOut", "none"), o.optString("aLoop", "none"), o.optLong("aDur", 600))

    private fun saveDraft() {
        val j = JSONObject().put("id", draftId).put("name", projTitle).put("saved", System.currentTimeMillis()).put("ratio", ratio).put("fill", fill).put("bg", bgColor)
        j.put("clips", JSONArray(clips.map { c -> JSONObject().put("uri", c.uri.toString()).put("dur", c.dur).put("start", c.start).put("end", c.end).put("w", c.w).put("h", c.h)
            .put("speed", c.speed.toDouble()).put("bri", c.bri.toDouble()).put("con", c.con.toDouble()).put("sat", c.sat.toDouble()).put("warm", c.warm.toDouble())
            .put("gray", c.gray).put("mute", c.mute) }))
        j.put("texts", JSONArray(texts.map { textJson(it) }))
        musicUri?.let { j.put("music", JSONObject().put("uri", it.toString()).put("vol", musicVol.toDouble()).put("dur", musicDur)) }
        Drafts.save(this, j)
        try {
            val c = clips.first(); val r = MediaMetadataRetriever(); r.setDataSource(this, c.uri)
            val dh = 360; val dw = (dh * (if (c.h > 0) c.w.toFloat() / c.h else 0.56f)).toInt().coerceIn(120, 640)
            val b = r.getScaledFrameAtTime(c.start * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, dw, dh); r.release()
            if (b != null) Drafts.thumb(this, draftId).outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        } catch (e: Exception) { }
    }

    private fun loadDraft(id: String) {
        val j = Drafts.load(this, id) ?: run { toast("Draft could not be opened"); finish(); return }
        draftId = id; ratio = j.optString("ratio", "orig"); fill = j.optBoolean("fill", false); bgColor = j.optInt("bg", Color.BLACK)
        var missing = 0
        val ca = j.optJSONArray("clips") ?: JSONArray()
        for (i in 0 until ca.length()) {
            val o = ca.getJSONObject(i); val u = Uri.parse(o.getString("uri"))
            try { contentResolver.openInputStream(u)?.close() } catch (e: Exception) { missing++; continue }
            clips.add(Clip(u, o.getLong("dur"), o.getLong("start"), o.getLong("end"), o.getInt("w"), o.getInt("h"), o.optDouble("speed", 1.0).toFloat(),
                o.optDouble("bri", 0.0).toFloat(), o.optDouble("con", 0.0).toFloat(), o.optDouble("sat", 0.0).toFloat(), o.optDouble("warm", 0.0).toFloat(),
                o.optBoolean("gray", false), o.optBoolean("mute", false)))
        }
        val ta = j.optJSONArray("texts") ?: JSONArray()
        for (i in 0 until ta.length()) texts.add(textFrom(ta.getJSONObject(i)))
        j.optJSONObject("music")?.let { m -> musicVol = m.optDouble("vol", 0.8).toFloat(); try { setMusic(Uri.parse(m.getString("uri"))) } catch (e: Exception) { } }
        if (missing > 0) toast("$missing video(s) from this draft are no longer available")
        if (clips.isNotEmpty()) sel = 0
        refresh(true)
    }

    private fun confirmExit() {
        if (clips.isEmpty()) { finish(); return }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Save to drafts?")
            .setMessage("Keep this project so you can continue editing it later.")
            .setPositiveButton("Save") { _, _ -> saveDraft(); finish() }
            .setNeutralButton("Cancel", null)
            .setNegativeButton("Discard") { _, _ -> finish() }.show()
    }

    // ------------------------------------------------------------------ export
    private fun buildExportScreen(): FrameLayout {
        val s = FrameLayout(this).apply { setBackgroundColor(C_BG); visibility = View.GONE; isClickable = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(6), dp(12), dp(6)) }
        bar.addView(ico(R.drawable.ic_back) { s.visibility = View.GONE })
        bar.addView(TextView(this).apply { text = "Export"; setTextColor(C_MUTED); textSize = 12f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(View(this), LinearLayout.LayoutParams(dp(44), 1))
        col.addView(bar)
        expHolder = FrameLayout(this)
        expPreview = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        expPreviewBox = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); addView(expPreview, FrameLayout.LayoutParams(-1, -1)) }
        expHolder.addView(expPreviewBox, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        col.addView(expHolder, LinearLayout.LayoutParams(-1, 0, 1f))

        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(C_PANEL); cornerRadius = dpf(16f) } }
        fun seg(label: String, opts: List<String>, cur: String, onPick: (String) -> Unit) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = label; setTextColor(0xFFCFCFD6.toInt()); textSize = 13f }, LinearLayout.LayoutParams(0, -2, 1f))
            val grp = LinearLayout(this).apply { background = GradientDrawable().apply { setColor(C_CHIP); cornerRadius = dpf(10f) }; setPadding(dp(3), dp(3), dp(3), dp(3)) }
            val tvs = ArrayList<TextView>()
            fun paint(v: String) = tvs.forEachIndexed { i, tv -> val on = opts[i] == v
                tv.setTextColor(if (on) Color.BLACK else C_MUTED); (tv.background as GradientDrawable).setColor(if (on) Color.WHITE else Color.TRANSPARENT) }
            opts.forEach { o -> val tv = TextView(this).apply { text = o; textSize = 12f; gravity = Gravity.CENTER; setPadding(dp(12), dp(6), dp(12), dp(6))
                background = GradientDrawable().apply { cornerRadius = dpf(8f) }; setOnClickListener { paint(o); onPick(o) } }
                tvs.add(tv); grp.addView(tv) }
            paint(cur); row.addView(grp)
            panel.addView(row, LinearLayout.LayoutParams(-1, dp(46)))
        }
        seg("Resolution", listOf("480p", "720p", "1080p"), "720p") { expRes = it.removeSuffix("p").toInt(); updateEst() }
        seg("Frame rate", listOf("24", "30", "60"), "30") { expFps = it.toInt(); updateEst() }
        seg("Format", listOf("MP4"), "MP4") { }
        val est = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        est.addView(TextView(this).apply { text = "Estimated size"; setTextColor(0xFFCFCFD6.toInt()); textSize = 13f }, LinearLayout.LayoutParams(0, -2, 1f))
        estLabel = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f }; est.addView(estLabel)
        panel.addView(est, LinearLayout.LayoutParams(-1, dp(46)))
        panel.addView(TextView(this).apply { text = "Your video is rendered by the phone's hardware encoder and saved to Movies / MN SHOT. Keep the app open."; setTextColor(C_MUTED); textSize = 10f; setPadding(0, 0, 0, dp(10)) })
        panel.addView(TextView(this).apply { text = "EXPORT"; setTextColor(Color.BLACK); textSize = 14f; setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dpf(26f) }; setOnClickListener { runExport(expRes, expFps) } }, LinearLayout.LayoutParams(-1, dp(52)))
        col.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), dp(12)) })
        s.addView(col, FrameLayout.LayoutParams(-1, -1))
        return s
    }

    private fun updateEst() {
        val br = when (expRes) { 480 -> 2_500_000L; 720 -> 6_000_000L; else -> 12_000_000L }
        val mb = (br + 128_000) * (clips.sumOf { it.effMs } / 1000.0) / 8.0 / 1e6
        estLabel.text = "~%.0f MB".format(mb)
    }

    private fun openExport() {
        if (clips.isEmpty()) { toast("Add a video first"); return }
        player.pause(); updateEst()
        exportScreen.visibility = View.VISIBLE
        expHolder.post {
            val aw = expHolder.width; val ah = expHolder.height; val asp = aspect()
            var w = aw - dp(60); var h = (w / asp).toInt(); if (h > ah - dp(10)) { h = ah - dp(10); w = (h * asp).toInt() }
            expPreviewBox.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.CENTER)
            expPreviewBox.setBackgroundColor(bgColor)
        }
        val ci = player.currentMediaItemIndex.coerceIn(0, clips.size - 1); val c = clips[ci]
        val posUs = (c.start + player.currentPosition) * 1000
        Thread {
            try {
                val r = MediaMetadataRetriever(); r.setDataSource(this, c.uri)
                val dh = 480; val dw = (dh * (if (c.h > 0) c.w.toFloat() / c.h else 0.56f)).toInt().coerceIn(120, 900)
                val b = r.getScaledFrameAtTime(posUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, dw, dh); r.release()
                runOnUiThread { expPreview.scaleType = if (fill) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER; expPreview.setImageBitmap(b) }
            } catch (e: Exception) { }
        }.start()
    }

    private fun runExport(short: Int, fps: Int) {
        val (w, h) = canvasDims(short)
        val layoutMode = if (fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT
        val items = clips.map { c ->
            val vfx = mutableListOf<Effect>(); val afx = mutableListOf<AudioProcessor>()
            if (c.speed != 1f) { vfx.add(SpeedChangeEffect(c.speed)); afx.add(SonicAudioProcessor().apply { setSpeed(c.speed) }) }
            vfx.addAll(fxList(c))
            vfx.add(Presentation.createForWidthAndHeight(w, h, layoutMode))
            vfx.add(FrameDropEffect.createDefaultFrameDropEffect(fps.toFloat()))
            EditedMediaItem.Builder(mediaItem(c)).setRemoveAudio(c.mute).setEffects(Effects(afx, vfx)).build()
        }
        val totalMs = clips.sumOf { it.effMs }
        val seq = EditedMediaItemSequence.Builder().apply { items.forEach { addItem(it) } }.build()
        val seqs = mutableListOf(seq)
        musicUri?.let { mu ->
            val end = minOf(musicDur, totalMs)
            val mItem = MediaItem.Builder().setUri(mu).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setStartPositionMs(0).setEndPositionMs(end).build()).build()
            val mix = ChannelMixingAudioProcessor()
            mix.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 1).scaleBy(musicVol))
            mix.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(musicVol))
            val me = EditedMediaItem.Builder(mItem).setRemoveVideo(true).setEffects(Effects(listOf<AudioProcessor>(mix), emptyList<Effect>())).build()
            seqs.add(EditedMediaItemSequence.Builder().addItem(me).build())
        }
        val comp = Composition.Builder(seqs).apply {
            if (texts.isNotEmpty()) {
                val ov = TextOverlayBmp(texts.toList(), w, h)
                setEffects(Effects(emptyList(), listOf<Effect>(OverlayEffect(ImmutableList.of<TextureOverlay>(ov)))))
            }
        }.build()

        val out = File(cacheDir, "out_${System.currentTimeMillis()}.mp4")
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; setPadding(dp(20), dp(20), dp(20), dp(10)) }
        val dlg = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Exporting…").setView(bar).setCancelable(false)
            .setNegativeButton("Cancel") { _, _ -> transformer?.cancel() }.show()
        val enc = DefaultEncoderFactory.Builder(this).setRequestedVideoEncoderSettings(
            VideoEncoderSettings.Builder().setBitrate(when (short) { 480 -> 2_500_000; 720 -> 6_000_000; else -> 12_000_000 }).build()).build()
        val tr = Transformer.Builder(this).setEncoderFactory(enc).addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                dlg.dismiss(); pollH.removeCallbacksAndMessages(null)
                val ok = saveToGallery(out); out.delete()
                Toast.makeText(this@MainActivity, if (ok) "Saved to Movies / MN SHOT" else "Could not save the video", Toast.LENGTH_LONG).show()
            }
            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                dlg.dismiss(); pollH.removeCallbacksAndMessages(null); out.delete()
                Toast.makeText(this@MainActivity, "Export failed: ${exportException.message}", Toast.LENGTH_LONG).show()
            }
        }).build()
        transformer = tr
        tr.start(comp, out.absolutePath)
        val holder = ProgressHolder()
        val poll = object : Runnable { override fun run() {
            if (tr.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) bar.progress = holder.progress
            pollH.postDelayed(this, 300) } }
        pollH.post(poll)
    }

    private fun saveToGallery(f: File): Boolean = try {
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "MN_SHOT_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MN SHOT")
        }
        val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
        contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        true
    } catch (e: Exception) { false }

    override fun onStop() { super.onStop(); player.pause(); musicPlayer.pause() }
    override fun onDestroy() {
        super.onDestroy(); ui.removeCallbacksAndMessages(null); pollH.removeCallbacksAndMessages(null)
        transformer?.cancel(); player.release(); musicPlayer.release()
    }
}
