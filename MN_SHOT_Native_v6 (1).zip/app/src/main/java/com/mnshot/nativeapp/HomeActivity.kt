package com.mnshot.nativeapp

import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.style.CharacterStyle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat

class HomeActivity : AppCompatActivity() {
    private lateinit var draftsBox: LinearLayout

    override fun onResume() { super.onResume(); if (::draftsBox.isInitialized) fillDrafts() }

    private fun fillDrafts() {
        draftsBox.removeAllViews()
        val list = Drafts.list(this)
        if (list.isEmpty()) {
            draftsBox.addView(TextView(this).apply {
                text = "Your drafts will appear here.\nStart a video project and save it anytime."
                textSize = 12f; setTextColor(c("#3A3670")); gravity = Gravity.CENTER; minHeight = dp(74); setPadding(dp(12), dp(12), dp(12), dp(12))
                background = GradientDrawable().apply { setColor(c("#55FFFFFF")); cornerRadius = dpf(14f); setStroke(dp(2), c("#663A3670"), dpf(6f), dpf(5f)) } })
            return
        }
        val row = LinearLayout(this)
        list.forEach { j ->
            val id = j.getString("id")
            val tile = FrameLayout(this).apply {
                background = grad("#5B5F97", "#3A3670", 14f); clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dpf(14f)) } }
                elevation = dpf(4f) }
            val f = Drafts.thumb(this, id)
            if (f.exists()) tile.addView(ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(BitmapFactory.decodeFile(f.path)) }, FrameLayout.LayoutParams(-1, -1))
            tile.addView(TextView(this).apply { text = j.optString("name", "Draft"); textSize = 10f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
                setPadding(dp(8), dp(14), dp(8), dp(8)); background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, c("#AA000000"))) },
                FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
            tile.setOnClickListener { startActivity(Intent(this, MainActivity::class.java).putExtra("draft", id)) }
            tile.setOnLongClickListener {
                AlertDialog.Builder(this).setTitle("Delete this draft?").setPositiveButton("Delete") { _, _ -> Drafts.delete(this, id); fillDrafts() }
                    .setNegativeButton("Cancel", null).show(); true }
            row.addView(tile, LinearLayout.LayoutParams(dp(100), dp(140)).apply { marginEnd = dp(10); bottomMargin = dp(6) })
        }
        draftsBox.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density
    private fun c(hex: String) = Color.parseColor(hex)

    private class GradSpan : CharacterStyle() {
        override fun updateDrawState(ds: TextPaint) {
            ds.shader = LinearGradient(0f, 0f, ds.textSize * 3f, 0f, Color.parseColor("#5B3EE8"), Color.parseColor("#1FB6FF"), Shader.TileMode.CLAMP)
        }
    }

    private fun grad(c1: String, c2: String, radiusDp: Float, oval: Boolean = false) =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c(c1), c(c2))).apply {
            if (oval) shape = GradientDrawable.OVAL else cornerRadius = dpf(radiusDp)
        }

    private fun logoTile(sizeDp: Int): View {
        val box = FrameLayout(this)
        box.background = grad("#1E2347", "#0C0E22", sizeDp * 0.27f)
        box.clipToOutline = true
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dpf(sizeDp * 0.27f)) }
        }
        box.elevation = dpf(8f)
        val img = ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground); scaleType = ImageView.ScaleType.FIT_CENTER; scaleX = 1.5f; scaleY = 1.5f }
        box.addView(img, FrameLayout.LayoutParams(-1, -1))
        box.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return box
    }

    private fun header(left: String, right: String?, onRight: (() -> Unit)? = null): LinearLayout {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), 0, dp(4), dp(10)) }
        row.addView(TextView(this).apply { text = left; textSize = 12f; setTypeface(null, Typeface.BOLD); letterSpacing = 0.12f; setTextColor(c("#1D1A45")) },
            LinearLayout.LayoutParams(0, -2, 1f))
        if (right != null) row.addView(TextView(this).apply { text = right; textSize = 12f; setTypeface(null, Typeface.BOLD); letterSpacing = 0.08f; setTextColor(c("#1D1A45"))
            setOnClickListener { onRight?.invoke() } })
        return row
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = Color.TRANSPARENT
        val bg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(c("#DFF6FF"), c("#B7D4FF"), c("#A595FF"), c("#8A74F5")))
        bg.setColors(intArrayOf(c("#DFF6FF"), c("#B7D4FF"), c("#A595FF"), c("#8A74F5")), floatArrayOf(0f, 0.38f, 0.78f, 1f))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // top bar
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(14), dp(12), 0) }
        top.addView(logoTile(36).apply { (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(10); elevation = dpf(4f) })
        top.addView(TextView(this).apply { text = "MN"; textSize = 23f; setTextColor(c("#14122E")); typeface = Typeface.create("sans-serif-black", Typeface.NORMAL) })
        top.addView(TextView(this).apply { text = "SHOT"; textSize = 19f; letterSpacing = 0.2f; setTextColor(c("#14122E")); setPadding(dp(6), 0, 0, 0)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL) })
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        fun ib(res: Int, onClick: () -> Unit) = ImageView(this).apply { setImageResource(res); setPadding(dp(10), dp(10), dp(10), dp(10)); setOnClickListener { onClick() } }
        top.addView(ib(R.drawable.ic_crown) { toast("All features are unlocked") }, LinearLayout.LayoutParams(dp(44), dp(44)))
        top.addView(ib(R.drawable.ic_gear) { toast("Settings are coming soon") }, LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(top)

        // hero
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(24), dp(24), dp(24)) }
        hero.addView(logoTile(92))
        hero.addView(TextView(this).apply {
            val sp = SpannableString("Cut. Shape. Shoot.")
            sp.setSpan(GradSpan(), 11, sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            text = sp; textSize = 27f; setTypeface(null, Typeface.BOLD); setTextColor(c("#171533")); gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(4)) })
        hero.addView(TextView(this).apply { text = "Your video studio, in your pocket."; textSize = 14f; setTextColor(c("#3A3670")); gravity = Gravity.CENTER })
        col.addView(hero, LinearLayout.LayoutParams(-1, 0, 1f).apply { }.also { it.height = 0 })

        // create new
        val create = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, dp(18), 0) }
        create.addView(header("CREATE NEW", null))
        val card = LinearLayout(this).apply { setPadding(dp(10), dp(18), dp(10), dp(14)); elevation = dpf(10f)
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dpf(22f) } }
        fun createBtn(label: String, icon: Int, c1: String, c2: String, badge: String?, onClick: () -> Unit): View {
            val f = FrameLayout(this)
            val colm = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            val circle = FrameLayout(this).apply { background = grad(c1, c2, 0f, true); elevation = dpf(4f) }
            circle.addView(ImageView(this).apply { setImageResource(icon) }, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
            colm.addView(circle, LinearLayout.LayoutParams(dp(62), dp(62)))
            colm.addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(c("#2A2A30")); setTypeface(null, Typeface.BOLD); setPadding(0, dp(8), 0, 0) })
            f.addView(colm, FrameLayout.LayoutParams(-1, -2))
            if (badge != null) f.addView(TextView(this).apply { text = badge; textSize = 9f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); setPadding(dp(6), dp(2), dp(6), dp(2))
                background = GradientDrawable().apply { setColor(c("#2A2A30")); cornerRadius = dpf(8f) } },
                FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { topMargin = -dp(6); marginEnd = dp(6) })
            f.setOnClickListener { onClick() }
            return f
        }
        card.addView(createBtn("Video", R.drawable.ic_video, "#8B6BFF", "#5B8CFF", null) {
            startActivity(Intent(this, MainActivity::class.java).putExtra("pick", true)) }, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(createBtn("Photo", R.drawable.ic_photo, "#5B8CFF", "#38B6FF", null) { toast("Photo editor is coming in the next stage") }, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(createBtn("Collage", R.drawable.ic_collage, "#38B6FF", "#2EE6D6", "Soon") { toast("Collage is coming soon") }, LinearLayout.LayoutParams(0, -2, 1f))
        create.addView(card)
        col.addView(create)

        // what's new
        val wn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), 0) }
        wn.addView(header("WHAT'S NEW", "ALL ›") { toast("More features are on the way") })
        val wnRow = LinearLayout(this)
        listOf(
            Triple("Animations", "In · Out · Combo · Loop", "#7C5CFF" to "#4F8BFF"),
            Triple("Opacity & Mask", "Circle · Heart · Star", "#4F8BFF" to "#22D3EE"),
            Triple("Crop & Replace", "Zoom · Pan · Ratios", "#9B6BFF" to "#D56BFF"),
            Triple("Quick Share", "One tap after export", "#22B8E8" to "#2EE6B6"),
            Triple("Photo", "Slideshows · Freeze", "#FF7AD9" to "#7C5CFF"),
            Triple("PIP & Collage", "Voice · Enhance · Auto cut", "#22D3EE" to "#7C5CFF")
        ).forEach { (t, s, g) ->
            val cardV = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.BOTTOM; setPadding(dp(12), dp(12), dp(12), dp(12))
                background = grad(g.first, g.second, 16f); elevation = dpf(6f); setOnClickListener { toast(t) } }
            cardV.addView(TextView(this).apply { text = t; textSize = 13f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD) })
            cardV.addView(TextView(this).apply { text = s; textSize = 10f; setTextColor(Color.WHITE); alpha = 0.85f })
            wnRow.addView(cardV, LinearLayout.LayoutParams(dp(132), dp(84)).apply { marginEnd = dp(10); bottomMargin = dp(6) })
        }
        wn.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; clipToPadding = false; addView(wnRow) })
        col.addView(wn)

        // drafts
        val dr = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(22), dp(18), dp(22)) }
        dr.addView(header("MY DRAFTS", "ALL ›") { toast("Long-press a draft to delete it") })
        draftsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        dr.addView(draftsBox)
        col.addView(dr)
        fillDrafts()

        val sv = ScrollView(this).apply { isFillViewport = true; addView(col, ViewGroup.LayoutParams(-1, -2)) }
        val root = FrameLayout(this).apply { background = bg; addView(sv, FrameLayout.LayoutParams(-1, -1)) }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); insets }
        setContentView(root)
        WindowCompat.getInsetsController(window, root).apply { isAppearanceLightStatusBars = true; isAppearanceLightNavigationBars = true }
    }
}
