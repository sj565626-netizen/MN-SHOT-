# MN SHOT Native (Stage 1)
Native Kotlin editor: ExoPlayer preview + Media3 Transformer hardware export (offline, not real-time -> smooth video).
Stage 4 added: multiple texts with drag + two-finger pinch/rotate, 13 system fonts + import .ttf/.otf, bold/italic/outline/shadow/box with colour palettes, intro/outro/loop text animations (incl. typewriter), show-from/to timing, scrub bar + play button, preview matches export exactly (same renderer).
Stage 3 added: Filter & adjust per clip (10 presets + brightness, contrast, saturation, warmth sliders, apply to all).
Stage 2 added: split at playhead, per-clip speed (0.25x-4x), background music with volume, mute original audio.
Stage 1: import many videos, trim, reorder, delete, one text overlay, export 720p/1080p to Movies/MN SHOT.
Build: push to GitHub, Actions -> "Build MN SHOT Native APK".
Next stages: split, speed, audio/music, filters, multi-text with pinch, stickers, PIP, transitions, photos.
Home screen: same look as the original MN SHOT (gradient, logo, Create new, What's new, My drafts). Video opens the editor; Photo/Collage/Drafts are placeholders for now.
v0.6: editor redesigned like the original app (top bar + Export, preview, undo/redo, timeline with thumbnails and text tracks, bottom toolbar Canvas/Audio/Sticker/Text/Effect/Filter/Adjust/PIP, sheets, export screen, save-to-drafts dialog, drafts on home).
