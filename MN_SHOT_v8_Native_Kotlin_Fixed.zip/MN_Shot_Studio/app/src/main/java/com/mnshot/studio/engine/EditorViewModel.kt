package com.mnshot.studio.engine

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mnshot.studio.media.MediaGalleryRepository
import com.mnshot.studio.media.NativeVideoExporter
import com.mnshot.studio.model.*
import kotlinx.coroutines.launch
import java.util.UUID

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    var currentScreen by mutableStateOf(AppScreen.HOME)
    var pickerMode by mutableStateOf(PickerMode.VIDEO)
    var pickingForPip by mutableStateOf(false)
    var appendOnPick by mutableStateOf(false)

    var galleryAssets by mutableStateOf<List<MediaAsset>>(emptyList())
    var selectedAssets by mutableStateOf<List<MediaAsset>>(emptyList())
    var selectedAlbum by mutableStateOf("All")

    var project by mutableStateOf(ProjectState())
    private val undoStack = ArrayDeque<ProjectState>()
    private val redoStack = ArrayDeque<ProjectState>()

    var playheadMs by mutableLongStateOf(0L)
    var isPlaying by mutableStateOf(false)
    var activeTool by mutableStateOf<EditorTool?>(null)

    var exportHeight by mutableIntStateOf(1080)
    var exportFps by mutableIntStateOf(30)
    var exportProgress by mutableIntStateOf(0)
    var exportStatus by mutableStateOf("")
    var lastExportedUri by mutableStateOf<Uri?>(null)

    private val exporter = NativeVideoExporter(app)

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    val albums: List<String>
        get() = listOf("All") + galleryAssets.map { it.albumName }.distinct()

    val filteredAssets: List<MediaAsset>
        get() = if (selectedAlbum == "All") galleryAssets else galleryAssets.filter { it.albumName == selectedAlbum }

    private fun mutate(newState: ProjectState) {
        undoStack.addLast(project)
        if (undoStack.size > 35) undoStack.removeFirst()
        redoStack.clear()
        project = newState
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            redoStack.addLast(project)
            project = undoStack.removeLast()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            undoStack.addLast(project)
            project = redoStack.removeLast()
        }
    }

    fun openPicker(mode: PickerMode, append: Boolean = false, forPip: Boolean = false) {
        pickerMode = mode
        appendOnPick = append
        pickingForPip = forPip
        selectedAssets = emptyList()
        selectedAlbum = "All"
        currentScreen = AppScreen.PICKER
        refreshGallery()
    }

    fun refreshGallery() {
        viewModelScope.launch {
            galleryAssets = MediaGalleryRepository.queryMedia(getApplication(), pickerMode, null)
        }
    }

    fun toggleAssetSelection(asset: MediaAsset) {
        if (pickingForPip) {
            selectedAssets = listOf(asset)
            return
        }
        selectedAssets = if (selectedAssets.any { it.id == asset.id }) {
            selectedAssets.filterNot { it.id == asset.id }
        } else {
            selectedAssets + asset
        }
    }

    fun confirmSelectionToEditor() {
        if (selectedAssets.isEmpty()) return
        if (pickingForPip) {
            val pipAsset = selectedAssets.first()
            val pipOverlay = OverlayItem(
                pipUri = pipAsset.uri,
                scale = 0.45f,
                startMs = playheadMs,
                endMs = project.totalDurationMs.coerceAtLeast(3000L)
            )
            mutate(project.copy(overlays = project.overlays + pipOverlay, selectedOverlayId = pipOverlay.id))
            pickingForPip = false
            currentScreen = AppScreen.EDITOR
            return
        }

        val newClips = selectedAssets.map { asset ->
            val dur = if (asset.isVideo && asset.durationMs > 0) asset.durationMs else 3000L
            VideoClip(
                uri = asset.uri,
                isVideo = asset.isVideo,
                sourceDurationMs = dur,
                trimStartMs = 0L,
                trimEndMs = dur
            )
        }

        if (appendOnPick && project.clips.isNotEmpty()) {
            mutate(project.copy(clips = project.clips + newClips))
        } else {
            undoStack.clear()
            redoStack.clear()
            project = ProjectState(clips = newClips, selectedClipIndex = 0)
            playheadMs = 0L
        }
        isPlaying = false
        activeTool = null
        currentScreen = AppScreen.EDITOR
    }

    fun splitSelectedClipAtPlayhead() {
        val idx = project.selectedClipIndex
        val clip = project.clips.getOrNull(idx) ?: return
        var acc = 0L
        for (i in 0 until idx) acc += project.clips[i].effectiveDurationMs
        val localOffsetMs = ((playheadMs - acc) * clip.speed).toLong()
        val splitPoint = clip.trimStartMs + localOffsetMs
        if (splitPoint <= clip.trimStartMs + 250L || splitPoint >= clip.trimEndMs - 250L) return

        val firstHalf = clip.copy(trimEndMs = splitPoint)
        val secondHalf = clip.copy(id = UUID.randomUUID().toString(), trimStartMs = splitPoint)
        val updated = project.clips.toMutableList().apply {
            removeAt(idx)
            add(idx, firstHalf)
            add(idx + 1, secondHalf)
        }
        mutate(project.copy(clips = updated, selectedClipIndex = idx + 1))
    }

    fun updateSelectedClip(transform: (VideoClip) -> VideoClip) {
        val idx = project.selectedClipIndex
        val clip = project.clips.getOrNull(idx) ?: return
        val updated = project.clips.toMutableList().apply { set(idx, transform(clip)) }
        mutate(project.copy(clips = updated))
    }

    fun duplicateSelectedClip() {
        val idx = project.selectedClipIndex
        val clip = project.clips.getOrNull(idx) ?: return
        val copy = clip.copy(id = UUID.randomUUID().toString())
        val updated = project.clips.toMutableList().apply { add(idx + 1, copy) }
        mutate(project.copy(clips = updated, selectedClipIndex = idx + 1))
    }

    fun deleteSelectedClip() {
        if (project.clips.size <= 1) return
        val idx = project.selectedClipIndex
        val updated = project.clips.toMutableList().apply { removeAt(idx) }
        mutate(project.copy(clips = updated, selectedClipIndex = idx.coerceAtMost(updated.lastIndex)))
    }

    fun addTextOverlay(text: String, colorHex: Long = 0xFFFFFFFF, bgHex: Long = 0x88000000, isSticker: Boolean = false) {
        val overlay = OverlayItem(
            isSticker = isSticker,
            text = text,
            colorHex = colorHex,
            bgColorHex = if (isSticker) 0x00000000 else bgHex,
            fontSizeSp = if (isSticker) 44f else 26f,
            startMs = playheadMs,
            endMs = (playheadMs + 3500L).coerceAtMost(project.totalDurationMs.coerceAtLeast(3500L))
        )
        mutate(project.copy(overlays = project.overlays + overlay, selectedOverlayId = overlay.id))
    }

    fun updateOverlay(id: String, transform: (OverlayItem) -> OverlayItem) {
        val updated = project.overlays.map { if (it.id == id) transform(it) else it }
        project = project.copy(overlays = updated)
    }

    fun setBackgroundMusic(uri: Uri) {
        mutate(project.copy(audioTrack = AudioTrackItem(uri = uri, title = "Background Audio")))
    }

    fun startNativeExport() {
        isPlaying = false
        exportProgress = 10
        exportStatus = "Rendering hardware MP4..."
        lastExportedUri = null
        currentScreen = AppScreen.PROGRESS

        exporter.exportProject(
            project = project,
            targetHeight = exportHeight,
            onProgress = { exportProgress = it },
            onComplete = { uri ->
                exportProgress = 100
                exportStatus = "Saved to Movies/MN SHOT"
                lastExportedUri = uri
            },
            onError = { err ->
                exportStatus = "Export Error: $err"
            }
        )
    }

    fun cancelExport() {
        exporter.cancel()
        currentScreen = AppScreen.EXPORT
    }

    fun shareVideo(packageName: String? = null) {
        val uri = lastExportedUri ?: return
        val app = getApplication<Application>()
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            if (!packageName.isNullOrBlank()) setPackage(packageName)
        }
        try {
            app.startActivity(intent)
        } catch (_: Exception) {
            val chooser = Intent.createChooser(intent.apply { setPackage(null) }, "Share Video").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(chooser)
        }
    }
}
