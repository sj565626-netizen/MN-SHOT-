# MN SHOT v8.0 (100% Native Kotlin)

- Auto-extracts ZIP archive and moves project files into root during CI build.
- Auto-accepts Android SDK licenses to prevent interactive prompts.
- 100% Native Kotlin + Jetpack Compose + Media3 ExoPlayer & Transformer (zero WebView).
