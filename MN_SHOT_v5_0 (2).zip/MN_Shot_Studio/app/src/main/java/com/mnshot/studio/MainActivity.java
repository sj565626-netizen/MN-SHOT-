package com.mnshot.studio;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.os.Build;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import android.os.Environment;
import android.content.ContentValues;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

public class MainActivity extends Activity {
    private android.webkit.PermissionRequest pendingPerm;
    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 77 && pendingPerm != null) {
            if (res.length > 0 && res[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) pendingPerm.grant(pendingPerm.getResources());
            else pendingPerm.deny();
            pendingPerm = null;
        }
    }

    private static final int FILE_CHOOSER_REQUEST = 4107;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private File mp4InputFile;
    private FileOutputStream mp4InputStream;
    private volatile Transformer mp4Transformer;
    private volatile boolean nativeMp4Cancelled = false;
    private volatile Uri lastSavedUri = null;

    private final class NativeMp4Bridge {
        @JavascriptInterface public synchronized boolean beginMp4Export() {
            try {
                if (mp4Transformer != null || mp4InputStream != null) return false;
                nativeMp4Cancelled = false;
                mp4InputFile = new File(getCacheDir(), "mnshot-input-" + System.currentTimeMillis() + ".webm");
                mp4InputStream = new FileOutputStream(mp4InputFile);
                return true;
            } catch (IOException e) { notifyWeb(false, "Could not prepare MP4 conversion: " + e.getMessage()); return false; }
        }
        @JavascriptInterface public synchronized boolean appendMp4Chunk(String base64) {
            try {
                if (mp4InputStream == null) return false;
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                mp4InputStream.write(bytes);
                return true;
            } catch (Exception e) { notifyWeb(false, "Could not transfer video data: " + e.getMessage()); return false; }
        }
        @JavascriptInterface public synchronized void finishMp4Export() {
            try {
                if (mp4InputStream == null || mp4InputFile == null) throw new IOException("No video data received");
                mp4InputStream.flush(); mp4InputStream.close(); mp4InputStream = null;
                runOnUiThread(() -> convertWebmToMp4(mp4InputFile));
            } catch (Exception e) { notifyWeb(false, "Could not finish video transfer: " + e.getMessage()); }
        }
        @JavascriptInterface public synchronized void abortMp4Export() {
            try { if (mp4InputStream != null) mp4InputStream.close(); } catch (IOException ignored) {}
            mp4InputStream = null;
            if (mp4InputFile != null) mp4InputFile.delete();
            mp4InputFile = null;
        }
        @JavascriptInterface public boolean shareLastVideo(final String pkg) {
            final Uri uri = lastSavedUri;
            if (uri == null) return false;
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("video/mp4");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    if (pkg != null && !pkg.isEmpty()) {
                        Intent direct = new Intent(send);
                        direct.setPackage(pkg);
                        startActivity(direct);
                    } else {
                        startActivity(Intent.createChooser(send, "Share video"));
                    }
                } catch (Exception first) {
                    try { startActivity(Intent.createChooser(send, "Share video")); }
                    catch (Exception ignored) { notifyWeb(false, "Sharing is not available on this device."); }
                }
            });
            return true;
        }
        @JavascriptInterface public void cancelNativeMp4Export() {
            nativeMp4Cancelled = true;
            Transformer active = mp4Transformer;
            if (active != null) {
                try { active.cancel(); } catch (Exception ignored) {}
            } else {
                abortMp4Export();
                notifyWeb(false, "MP4 conversion cancelled.");
            }
        }
    }

    private void notifyWebProgress(String message) {
        if (webView == null) return;
        String safe = message == null ? "" : message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ");
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.onNativeMp4Progress)window.onNativeMp4Progress('" + safe + "')", null); });
    }

    private void notifyWeb(boolean success, String message) {
        if (webView == null) return;
        String safe = message == null ? "" : message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ");
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.onNativeMp4Result)window.onNativeMp4Result(" + success + ", '" + safe + "')", null); });
    }

    private void convertWebmToMp4(File input) {
        try {
            nativeMp4Cancelled = false;
            File output = new File(getCacheDir(), "MN_Cut_export-" + System.currentTimeMillis() + ".mp4");
            if (output.exists()) output.delete();
            mp4Transformer = new Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(new Transformer.Listener() {
                    @Override public void onCompleted(Composition composition, ExportResult exportResult) {
                        try {
                            if (nativeMp4Cancelled) {
                                notifyWeb(false, "MP4 conversion cancelled.");
                            } else if (!output.isFile() || output.length() == 0) {
                                throw new IOException("Converter returned an empty MP4 file");
                            } else {
                                Uri saved = publishMp4(output);
                                lastSavedUri = saved;
                                notifyWeb(true, "MP4 saved to Downloads: " + saved.getLastPathSegment());
                            }
                        } catch (Exception e) { notifyWeb(false, "MP4 could not be saved: " + e.getMessage()); }
                        finally { input.delete(); output.delete(); mp4Transformer = null; }
                    }
                    @Override public void onError(Composition composition, ExportResult exportResult, ExportException exportException) {
                        try {
                            if (nativeMp4Cancelled) notifyWeb(false, "MP4 conversion cancelled.");
                            else notifyWeb(false, "This device could not convert the video to MP4: " + exportException.getMessage());
                        } finally { input.delete(); output.delete(); mp4Transformer = null; }
                    }
                }).build();
            EditedMediaItem item = new EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input))).build();
            mp4Transformer.start(item, output.getAbsolutePath());
            notifyWebProgress("Android MP4 conversion started. Keep MN SHOT open.");
        } catch (Exception e) {
            input.delete();
            mp4Transformer = null;
            notifyWeb(false, "MP4 conversion could not start: " + e.getMessage());
        }
    }

    private Uri publishMp4(File source) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, "MN_Cut_export-" + System.currentTimeMillis() + ".mp4");
            values.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Downloads folder is unavailable");
            try {
                try (InputStream in = new FileInputStream(source); OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Could not open Downloads output");
                    byte[] buffer = new byte[64 * 1024]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }
                values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                return uri;
            } catch (IOException e) {
                getContentResolver().delete(uri, null, null);
                throw e;
            }
        }
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = getFilesDir();
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create app Downloads folder");
        File dest = new File(dir, "MN_Cut_export-" + System.currentTimeMillis() + ".mp4");
        try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(dest)) {
            byte[] buffer = new byte[64 * 1024]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        }
        return Uri.fromFile(dest);
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        getWindow().setStatusBarColor(Color.rgb(23, 19, 28));
        getWindow().setNavigationBarColor(Color.rgb(23, 19, 28));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(23, 19, 28));
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep the editor self-contained; do not navigate away from its local assets.
                return !"file".equals(request.getUrl().getScheme());
            }
        });
        webView.addJavascriptInterface(new NativeMp4Bridge(), "MNCutNativeMp4");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final android.webkit.PermissionRequest r) {
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        pendingPerm = r;
                        requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 77);
                    } else r.grant(r.getResources());
                });
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                boolean multiple = params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE;
                String type = "*/*";
                try {
                    String[] accept = params == null ? null : params.getAcceptTypes();
                    if (accept != null && accept.length > 0 && accept[0] != null && !accept[0].trim().isEmpty()) type = accept[0].trim();
                } catch (Exception ignored) {}
                try {
                    Intent open = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    open.addCategory(Intent.CATEGORY_OPENABLE);
                    open.setType(type);
                    open.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
                    open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(open, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception first) {
                    try {
                        Intent get = new Intent(Intent.ACTION_GET_CONTENT);
                        get.addCategory(Intent.CATEGORY_OPENABLE);
                        get.setType(type);
                        get.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
                        startActivityForResult(get, FILE_CHOOSER_REQUEST);
                        return true;
                    } catch (Exception second) {
                        fileCallback = null;
                        callback.onReceiveValue(null);
                        return false;
                    }
                }
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] result = parsePicked(resultCode, data);
            if (fileCallback != null) {
                fileCallback.onReceiveValue(result);
                fileCallback = null;
                if (resultCode == RESULT_OK && result == null) diag("Picker returned no file. [" + String.valueOf(data) + "]");
            } else {
                diag("Picker result was lost because the app restarted while choosing. Please try again.");
            }
        }
    }

    private Uri[] parsePicked(int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null) return null;
        java.util.ArrayList<Uri> out = new java.util.ArrayList<>();
        android.content.ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                Uri u = clip.getItemAt(i).getUri();
                if (u != null) out.add(u);
            }
        }
        if (out.isEmpty() && data.getData() != null) out.add(data.getData());
        if (out.isEmpty()) {
            try {
                Uri s = (Uri) data.getParcelableExtra(Intent.EXTRA_STREAM);
                if (s != null) out.add(s);
            } catch (Exception ignored) {}
        }
        return out.isEmpty() ? null : out.toArray(new Uri[0]);
    }

    private void diag(String message) {
        if (webView == null) return;
        String safe = message.replace("\\", "\\\\").replace("'", "\\'");
        webView.evaluateJavascript("if(window.__mnDiag)window.__mnDiag('" + safe + "')", null);
    }

    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("(window.__mnBack && window.__mnBack()) ? '1' : '0'", value -> {
            if (value == null || !value.contains("1")) super.onBackPressed();
        });
    }

    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (mp4Transformer != null) { try { mp4Transformer.cancel(); } catch (Exception ignored) {} mp4Transformer = null; }
        if (mp4InputStream != null) { try { mp4InputStream.close(); } catch (IOException ignored) {} mp4InputStream = null; }
        if (mp4InputFile != null) { mp4InputFile.delete(); mp4InputFile = null; }
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
