package com.mnshot.studio

import android.net.Uri
import androidx.media3.common.MediaItem

/** Builds a MediaItem with an optional trim range (clipping lives on MediaItem in Media3). */
object MediaClip {
    fun item(uri: Uri, startMs: Long = 0L, endMs: Long? = null): MediaItem {
        val builder = MediaItem.Builder().setUri(uri)
        if (startMs > 0L || endMs != null) {
            val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs)
            if (endMs != null) clip.setEndPositionMs(endMs)
            builder.setClippingConfiguration(clip.build())
        }
        return builder.build()
    }
}
