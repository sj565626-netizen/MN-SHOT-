package com.mnshot.studio

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Transformer
import java.io.File

/** Phase 16: composition builder for a video sequence plus one or more audio sequences.
 * Audio tracks currently begin at timeline zero and are mixed as parallel sequences.
 * Timeline positioning, gain controls, and fades are future work.
 */
object AudioTimelineExportTools {
    fun export(context: Context, clips: List<MultiClipExportTools.ClipSource>, audioUris: List<Uri>) {
        if (clips.isEmpty()) { Toast.makeText(context, "Timeline is empty", Toast.LENGTH_LONG).show(); return }
        if (audioUris.isEmpty()) { MultiClipExportTools.export(context, clips); return }
        try {
            val videoItems = clips.map { source ->
                EditedMediaItem.Builder(MediaClip.item(source.uri, source.startMs, source.endMs))
                    .setRemoveAudio(false)
                    .build()
            }
            val videoSequence = EditedMediaItemSequence.Builder(*videoItems.toTypedArray()).build()
            val audioSequences = audioUris.map { uri ->
                val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(uri)).setRemoveVideo(true).build()
                EditedMediaItemSequence.Builder(audioItem).build()
            }
            val composition = Composition.Builder(listOf(videoSequence) + audioSequences).build()
            val outputDir = context.getExternalFilesDir("Movies") ?: context.filesDir
            val output = File(outputDir, "MN_SHOT_mix_${System.currentTimeMillis()}.mp4")
            val transformer = Transformer.Builder(context).build()
            transformer.addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: androidx.media3.transformer.ExportResult) {
                    try {
                    val saved = ExportSaveTools.publish(context, output)
                    Toast.makeText(context, "Mixed export saved to Movies/MN SHOT${if (saved == null) " (save failed)" else ""}", Toast.LENGTH_LONG).show()
                } catch (e: Exception) { Toast.makeText(context, "Export finished but saving failed: ${e.message}", Toast.LENGTH_LONG).show() }
                }
                override fun onError(composition: Composition, exportResult: androidx.media3.transformer.ExportResult, exportException: androidx.media3.transformer.ExportException) {
                    output.delete()
                    Toast.makeText(context, "Audio mix export failed: ${exportException.message}", Toast.LENGTH_LONG).show()
                }
            })
            transformer.start(composition, output.absolutePath)
            Toast.makeText(context, "Video and audio export started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Could not prepare audio composition: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
