package com.mnshot.studio

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Transformer
import java.io.File

/** Phase 14 multi-clip sequential composition exporter. */
object MultiClipExportTools {
    data class ClipSource(val uri: Uri, val startMs: Long = 0, val endMs: Long? = null)

    fun export(context: Context, clips: List<ClipSource>) {
        if (clips.isEmpty() || clips.any { it.startMs < 0 || (it.endMs != null && it.endMs <= it.startMs) }) {
            Toast.makeText(context, "Timeline or clip range is invalid", Toast.LENGTH_LONG).show(); return
        }
        val items = clips.map { source ->
            EditedMediaItem.Builder(MediaClip.item(source.uri, source.startMs, source.endMs))
                .setRemoveAudio(false)
                .build()
        }
        val sequence = EditedMediaItemSequence.Builder(*items.toTypedArray()).build()
        val composition = Composition.Builder(listOf(sequence)).build()
        val outputDir = context.getExternalFilesDir("Movies") ?: context.filesDir
        val output = File(outputDir, "MN_SHOT_timeline_${System.currentTimeMillis()}.mp4")
        val transformer = Transformer.Builder(context).build()
        transformer.addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: androidx.media3.transformer.ExportResult) {
                try {
                    val saved = ExportSaveTools.publish(context, output)
                    Toast.makeText(context, "Export saved to Movies/MN SHOT${if (saved == null) " (save failed)" else ""}", Toast.LENGTH_LONG).show()
                } catch (e: Exception) { Toast.makeText(context, "Export finished but saving failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
            override fun onError(composition: Composition, exportResult: androidx.media3.transformer.ExportResult, exportException: androidx.media3.transformer.ExportException) {
                output.delete()
                Toast.makeText(context, "Timeline export failed: ${exportException.message}", Toast.LENGTH_LONG).show()
            }
        })
        transformer.start(composition, output.absolutePath)
        Toast.makeText(context, "Multi-clip export started", Toast.LENGTH_SHORT).show()
    }
}
