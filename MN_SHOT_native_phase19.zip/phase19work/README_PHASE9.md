# MN SHOT Native Phase 9

Phase 9 adds a basic native preview filter selector. See `NATIVE_PHASE9_STATUS.md` for scope and limitations. This remains an incremental port, not a fully native, fully tested editor.
