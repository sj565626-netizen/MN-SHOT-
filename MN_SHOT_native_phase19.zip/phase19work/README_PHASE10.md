# MN SHOT Native — Phase 10

This incremental project ZIP includes previous scaffold phases plus Phase 10 native preview controls.

Phase 10: preview playback-speed presets and 90-degree rotation. Both are preview/session-only and not encoded into output files yet. Build/device verification remains outstanding.
