# Phase 7 — Native audio-track picker and preview (code added; build unverified)

- Android Storage Access Framework picker for audio files (`audio/*`)
- Add audio source URIs to an editor audio-track list
- Independent Media3 ExoPlayer playback preview for selected audio
- Remove tracks from the session list
- Persist read permission where the picker grants it

Limitations: audio tracks are session UI items and preview sources only. They are not mixed into video export, synchronized to clip timing, volume-adjustable, trimmed, or rendered in a final video yet. No Android build/device verification was performed.
