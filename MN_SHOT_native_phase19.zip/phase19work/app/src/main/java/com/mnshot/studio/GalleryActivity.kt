package com.mnshot.studio

import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.content.ContentUris
import android.provider.MediaStore
import android.net.Uri
import android.os.Build
import android.view.View
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.graphics.Bitmap
import android.util.TypedValue

/** Native gallery screen: browses device photos/videos and returns a selected URI. */
class GalleryActivity : Activity() {
    private val items = mutableListOf<MediaItem>()
    private lateinit var grid: GridView
    private lateinit var status: TextView
    private var mode = "all"
    private val req = 802
    data class MediaItem(val uri: Uri, val video: Boolean, val title: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra("mode") ?: "all"
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(20,20,28)); setPadding(14,14,14,14) }
        val header=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val back=TextView(this).apply { text="‹"; textSize=30f; setTextColor(Color.WHITE); setPadding(12,4,20,4); setOnClickListener{finish()} }
        val title=TextView(this).apply { text="Select media"; textSize=20f; setTextColor(Color.WHITE) }
        header.addView(back); header.addView(title); root.addView(header)
        status=TextView(this).apply { text="Photos and videos"; textSize=13f; setTextColor(Color.LTGRAY); setPadding(4,10,4,10) }; root.addView(status)
        grid=GridView(this).apply { numColumns=3; verticalSpacing=5; horizontalSpacing=5; stretchMode=GridView.STRETCH_COLUMN_WIDTH }
        root.addView(grid,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
        grid.setOnItemClickListener { _,_,position,_ ->
            val selected=items[position]
            setResult(RESULT_OK, android.content.Intent().putExtra("selected_uri",selected.uri.toString()).putExtra("selected_video",selected.video))
            finish()
        }
        checkAccessAndLoad()
    }
    private fun checkAccessAndLoad() {
        val permission = if(Build.VERSION.SDK_INT>=33) android.Manifest.permission.READ_MEDIA_IMAGES else android.Manifest.permission.READ_EXTERNAL_STORAGE
        if(Build.VERSION.SDK_INT>=33) {
            val img=checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES)==PackageManager.PERMISSION_GRANTED
            val vid=checkSelfPermission(android.Manifest.permission.READ_MEDIA_VIDEO)==PackageManager.PERMISSION_GRANTED
            if(!img && !vid){requestPermissions(arrayOf(android.Manifest.permission.READ_MEDIA_IMAGES,android.Manifest.permission.READ_MEDIA_VIDEO),req);return}
        } else if(checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(permission),req);return}
        loadMedia()
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults); if(requestCode==req) loadMedia()}
    private fun loadMedia() {
        items.clear()
        val collections= mutableListOf<Pair<Uri,Boolean>>()
        if(mode!="photo") collections.add(MediaStore.Video.Media.EXTERNAL_CONTENT_URI to true)
        if(mode!="video") collections.add(MediaStore.Images.Media.EXTERNAL_CONTENT_URI to false)
        for((collection,isVideo) in collections){
            val cols=arrayOf(MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME)
            try {
                contentResolver.query(collection,cols,null,null,MediaStore.MediaColumns.DATE_ADDED+" DESC")?.use { c ->
                    val idCol=c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID); val nameCol=c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                    while(c.moveToNext()) { val id=c.getLong(idCol); items.add(MediaItem(ContentUris.withAppendedId(collection,id),isVideo,c.getString(nameCol) ?: "Media")) }
                }
            } catch(_:SecurityException) { }
        }
        items.sortByDescending { it.uri.lastPathSegment?.toLongOrNull() ?: 0L }
        status.text=if(items.isEmpty()) "No media visible. Allow media access in permissions." else "${items.size} items · tap to select"
        grid.adapter=ThumbAdapter()
    }
    private inner class ThumbAdapter:BaseAdapter(){
        override fun getCount()=items.size; override fun getItem(position:Int)=items[position]; override fun getItemId(position: Int)=position.toLong()
        override fun getView(position:Int,convertView:View?,parent:android.view.ViewGroup?):View {
            val image=(convertView as? ImageView) ?: ImageView(this@GalleryActivity).apply { scaleType=ImageView.ScaleType.CENTER_CROP }
            image.layoutParams=AbsListView.LayoutParams(-1,dp(124)); image.setBackgroundColor(Color.rgb(45,45,58)); image.setImageDrawable(null)
            try { if(Build.VERSION.SDK_INT>=29) image.setImageBitmap(contentResolver.loadThumbnail(items[position].uri,android.util.Size(dp(124),dp(124)),null)) else image.setImageURI(items[position].uri) } catch(_:Exception){}
            return image
        }
    }
    private fun dp(v:Int)=TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,v.toFloat(),resources.displayMetrics).toInt()
}
