package com.mnshot.studio

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Transformer
import java.io.File

/** Native Media3 clip export. Source files are never modified. */
object ClipExportTools {
    fun exportClip(context: Context, uri: Uri, startMs: Long, endMs: Long, label: String) {
        if (startMs < 0 || endMs <= startMs) {
            Toast.makeText(context, "Invalid trim range", Toast.LENGTH_SHORT).show(); return
        }
        val output = File(context.getExternalFilesDir(null), "MN_SHOT_${label}_${System.currentTimeMillis()}.mp4")
        val item = EditedMediaItem.Builder(MediaItem.fromUri(uri)).setClipStartMs(startMs).setClipEndMs(endMs).build()
        val transformer = Transformer.Builder(context).build()
        transformer.addListener(object : Transformer.Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult) {
                Toast.makeText(context, "Export saved in app files: ${output.name}", Toast.LENGTH_LONG).show()
            }
            override fun onError(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult, exportException: androidx.media3.transformer.ExportException) {
                output.delete(); Toast.makeText(context, "Export failed: ${exportException.message}", Toast.LENGTH_LONG).show()
            }
        })
        transformer.startTransformation(item, output.absolutePath)
        Toast.makeText(context, "Export started", Toast.LENGTH_SHORT).show()
    }
}
