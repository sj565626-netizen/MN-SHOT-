package com.mnshot.studio

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.widget.FrameLayout
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import android.text.InputType
import android.widget.EditText
import android.app.AlertDialog

/** Phase 5: native clip-list/timeline management scaffold. */
class EditorActivity : Activity() {
    data class Clip(val uri: Uri, val video: Boolean, val label: String)
    private val clips = mutableListOf<Clip>()
    private var player: ExoPlayer? = null
    private var audioPlayer: ExoPlayer? = null
    private val audioTracks = mutableListOf<Uri>()
    private val overlays = mutableListOf<TextStickerTools.Overlay>()
    private lateinit var audioList: LinearLayout
    private lateinit var playerView: PlayerView
    private lateinit var preview: LinearLayout
    private lateinit var timeline: LinearLayout
    private lateinit var clipStatus: TextView
    private var selected = 0
    private var selectedFilter: FilterPreset? = null
    private var previewSpeed = 1.0f
    private var previewRotation = 0f
    private data class FilterPreset(val name: String, val tint: Int)
    private val filterPresets = listOf(
        FilterPreset("Original", Color.TRANSPARENT),
        FilterPreset("Warm", Color.argb(42, 255, 142, 64)),
        FilterPreset("Cool", Color.argb(38, 72, 150, 255)),
        FilterPreset("Rose", Color.argb(35, 255, 70, 130)),
        FilterPreset("Mono look", Color.argb(55, 80, 80, 80))
    )
    private val addClipRequest = 550

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val firstUri = intent.getStringExtra("selected_uri")?.let(Uri::parse) ?: run { finish(); return }
        val firstIsVideo = intent.getBooleanExtra("selected_video", true)
        clips.add(Clip(firstUri, firstIsVideo, firstUri.lastPathSegment ?: "Clip 1"))
        window.statusBarColor = Color.rgb(18,18,24); window.navigationBarColor = Color.rgb(18,18,24)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(18,18,24)); setPadding(12,12,12,12) }
        val header=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        header.addView(Button(this).apply{text="‹";setOnClickListener{finish()}})
        header.addView(TextView(this).apply{text="MN SHOT · Editor";textSize=18f;setTextColor(Color.WHITE);setPadding(12,0,0,0}) )
        root.addView(header)
        preview=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setBackgroundColor(Color.BLACK) }
        root.addView(preview,LinearLayout.LayoutParams(-1,0,1f))
        clipStatus=TextView(this).apply { setTextColor(Color.LTGRAY); textSize=13f; gravity=Gravity.CENTER; setPadding(8,8,8,8) }
        root.addView(clipStatus)
        val toolRow=LinearLayout(this).apply{gravity=Gravity.CENTER}
        listOf("Trim","Split","Audio","Text","Sticker","Filter","Speed","Rotate","Export").forEach { name ->
            toolRow.addView(Button(this).apply {
                text=name
                setOnClickListener { when(name) {
                    "Trim" -> trimSelected()
                    "Split" -> splitSelected()
                    "Audio" -> AudioTrackTools.pickAudio(this@EditorActivity)
                    "Text" -> TextStickerTools.addText(this@EditorActivity){overlays.add(it);renderPreview()}
                    "Sticker" -> TextStickerTools.addSticker(this@EditorActivity){overlays.add(it);renderPreview()}
                    "Filter" -> showFilters()
                    "Speed" -> showSpeed()
                    "Rotate" -> rotatePreview()
                    "Export" -> exportTimeline()
                } }
            }, LinearLayout.LayoutParams(0,-2,1f))
        }
        root.addView(toolRow)
        val controls=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        controls.addView(Button(this).apply{text="+ Add clip";setOnClickListener{startActivityForResult(Intent(this@EditorActivity,GalleryActivity::class.java).putExtra("mode","all"),addClipRequest)}},LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(Button(this).apply{text="← Move";setOnClickListener{moveSelected(-1)}},LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(Button(this).apply{text="Move →";setOnClickListener{moveSelected(1)}},LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(Button(this).apply{text="Remove";setOnClickListener{removeSelected()}},LinearLayout.LayoutParams(0,-2,1f))
        root.addView(controls)
        timeline=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val scroller=HorizontalScrollView(this).apply{isFillViewport=true;addView(timeline)}
        root.addView(scroller,LinearLayout.LayoutParams(-1,-2))
        audioList=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(TextView(this).apply{text="Audio tracks";setTextColor(Color.WHITE);textSize=16f;setPadding(4,10,4,4)})
        root.addView(audioList)
        setContentView(root)
        renderPreview(); renderTimeline(); renderAudioTracks()
    }
    private fun renderPreview(){
        player?.release();player=null;preview.removeAllViews()
        val clip=clips.getOrNull(selected) ?: return
        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        if(clip.video){
            playerView=PlayerView(this).apply{setBackgroundColor(Color.BLACK)}
            frame.addView(playerView, FrameLayout.LayoutParams(-1,-1))
            playerView.rotation = previewRotation
            player=ExoPlayer.Builder(this).build().also{playerView.player=it;it.setMediaItem(androidx.media3.common.MediaItem.fromUri(clip.uri));it.prepare();it.setPlaybackSpeed(previewSpeed)}
        }else{
            frame.addView(ImageView(this).apply{setImageURI(clip.uri);scaleType=ImageView.ScaleType.FIT_CENTER;rotation=previewRotation},FrameLayout.LayoutParams(-1,-1))
        }
        // Draw overlays on top of the preview. They remain preview-only until export composition is implemented.
        overlays.forEach { overlay ->
            frame.addView(TextView(this).apply {
                text = overlay.content; textSize = overlay.sizeSp; setTextColor(overlay.color)
                gravity = Gravity.CENTER; setShadowLayer(4f, 2f, 2f, Color.BLACK)
                setPadding(12, 8, 12, 8)
            }, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        }
        selectedFilter?.let { preset ->
            if (preset.tint != Color.TRANSPARENT) {
                frame.addView(android.view.View(this).apply { setBackgroundColor(preset.tint) },
                    FrameLayout.LayoutParams(-1, -1))
            }
        }
        preview.addView(frame, LinearLayout.LayoutParams(-1,-1))
        clipStatus.text="Clip ${selected+1} of ${clips.size} · ${clip.label}"
    }


    /** Phase 15: connect the editor Export action to the multi-clip composition exporter.
     * Photos are rejected for now because this composition path currently accepts video only.
     */
    private fun exportTimeline() {
        if (clips.isEmpty()) {
            Toast.makeText(this, "Timeline is empty", Toast.LENGTH_SHORT).show(); return
        }
        if (clips.any { !it.video }) {
            Toast.makeText(this, "Timeline merge currently supports video clips only; remove photos first", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this).setTitle("Export timeline")
            .setMessage("Export ${clips.size} video clips in timeline order? Preview overlays and filters are not included. Added audio tracks begin at timeline zero.")
            .setPositiveButton("Export") { _, _ ->
                AudioTimelineExportTools.export(this, clips.map { MultiClipExportTools.ClipSource(it.uri) }, audioTracks.toList())
            }.setNegativeButton("Cancel", null).show()
    }

    private fun exportSelectedClip() {
        val clip = clips.getOrNull(selected) ?: return
        if (!clip.video) {
            Toast.makeText(this, "Photo export is not yet available", Toast.LENGTH_LONG).show(); return
        }
        val options = arrayOf("Export original clip")
        AlertDialog.Builder(this).setTitle("Export selected video")
            .setItems(options) { _, which -> startNativeExport(clip.uri, which) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun startNativeExport(uri: Uri, option: Int) {
        val outputDir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES) ?: filesDir
        val output = java.io.File(outputDir, "MN_SHOT_export_${System.currentTimeMillis()}.mp4")
        val mediaItem = androidx.media3.transformer.EditedMediaItem.Builder(
            androidx.media3.common.MediaItem.fromUri(uri)
        ).build()
        val transformer = androidx.media3.transformer.Transformer.Builder(this).build()
        val dialog = android.app.ProgressDialog(this).apply {
            setTitle("Exporting video")
            setMessage("Preparing export…")
            setProgressStyle(android.app.ProgressDialog.STYLE_HORIZONTAL)
            max = 100; progress = 0; setCancelable(false); show()
        }
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val progressTask = object : Runnable {
            override fun run() {
                if (!dialog.isShowing) return
                val state = transformer.getProgress(androidx.media3.transformer.ProgressHolder())
                // Progress is refreshed by Media3 callbacks; indeterminate until completion.
                dialog.setMessage("Rendering selected clip…")
                handler.postDelayed(this, 500)
            }
        }
        transformer.addListener(object : androidx.media3.transformer.Transformer.Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult) {
                handler.removeCallbacks(progressTask); dialog.dismiss()
                Toast.makeText(this@EditorActivity, "Export complete: ${output.name} (app Movies folder)", Toast.LENGTH_LONG).show()
            }
            override fun onError(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult, exportException: androidx.media3.transformer.ExportException) {
                handler.removeCallbacks(progressTask); dialog.dismiss(); output.delete()
                Toast.makeText(this@EditorActivity, "Export failed: ${exportException.message}", Toast.LENGTH_LONG).show()
            }
        })
        handler.post(progressTask)
        transformer.startTransformation(mediaItem, output.absolutePath)
    }

    private fun showFilters() {
        val names = filterPresets.map { it.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Preview filter")
            .setItems(names) { _, which ->
                selectedFilter = filterPresets[which]
                renderPreview()
                Toast.makeText(this, "${filterPresets[which].name} preview selected", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }


    private fun showSpeed() {
        val options = arrayOf("0.5×", "0.75×", "1.0× (Normal)", "1.25×", "1.5×", "2.0×")
        val values = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        AlertDialog.Builder(this).setTitle("Preview playback speed")
            .setItems(options) { _, which ->
                previewSpeed = values[which]
                player?.setPlaybackSpeed(previewSpeed)
                Toast.makeText(this, "Preview speed: ${options[which]}", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun rotatePreview() {
        previewRotation = (previewRotation + 90f) % 360f
        renderPreview()
        Toast.makeText(this, "Preview rotated ${previewRotation.toInt()}°", Toast.LENGTH_SHORT).show()
    }

    private fun renderTimeline(){
        timeline.removeAllViews()
        clips.forEachIndexed { index, clip ->
            val tile=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(12,12,12,12);setBackgroundColor(if(index==selected) Color.rgb(92,112,255) else Color.rgb(44,44,58));setOnClickListener{selected=index;renderPreview();renderTimeline()}}
            tile.addView(TextView(this).apply{text=if(clip.video)"▶ VIDEO" else "▧ PHOTO";textSize=13f;setTextColor(Color.WHITE);gravity=Gravity.CENTER})
            tile.addView(TextView(this).apply{text="${index+1}";textSize=18f;setTextColor(Color.WHITE);gravity=Gravity.CENTER})
            tile.addView(TextView(this).apply{text=clip.label.take(18);textSize=11f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER})
            timeline.addView(tile,LinearLayout.LayoutParams(132,120).apply{rightMargin=8})
        }
    }


    private fun renderAudioTracks(){
        audioList.removeAllViews()
        if(audioTracks.isEmpty()) audioList.addView(TextView(this).apply{text="No audio tracks added";setTextColor(Color.LTGRAY)})
        audioTracks.forEachIndexed { index, uri ->
            val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
            row.addView(TextView(this).apply{text="Audio ${index+1}: ${uri.lastPathSegment ?: "track"}";setTextColor(Color.WHITE);setPadding(8,8,8,8)},LinearLayout.LayoutParams(0,-2,1f))
            row.addView(Button(this).apply{text="Play";setOnClickListener{playAudio(uri)}})
            row.addView(Button(this).apply{text="Remove";setOnClickListener{audioTracks.removeAt(index);if(audioPlayer?.isPlaying==true){audioPlayer?.stop();audioPlayer?.release();audioPlayer=null};renderAudioTracks()}})
            audioList.addView(row)
        }
    }
    private fun playAudio(uri:Uri){
        audioPlayer?.release()
        audioPlayer=ExoPlayer.Builder(this).build().also { it.setMediaItem(androidx.media3.common.MediaItem.fromUri(uri));it.prepare();it.play() }
        Toast.makeText(this,"Audio preview playing",Toast.LENGTH_SHORT).show()
    }

    private fun secondsField(hint: String): EditText = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setHint(hint)
    }
    private fun trimSelected() {
        val clip=clips.getOrNull(selected) ?: return
        if(!clip.video){Toast.makeText(this,"Trim is for video clips",Toast.LENGTH_SHORT).show();return}
        val start=secondsField("Start (seconds)"); val end=secondsField("End (seconds)")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8);addView(start);addView(end)}
        android.app.AlertDialog.Builder(this).setTitle("Trim selected video").setView(box).setPositiveButton("Export range") { _, _ ->
            val a=start.text.toString().toDoubleOrNull() ?: 0.0; val b=end.text.toString().toDoubleOrNull() ?: 0.0
            ClipExportTools.exportClip(this,clip.uri,(a*1000).toLong(),(b*1000).toLong(),"trim")
        }.setNegativeButton("Cancel",null).show()
    }
    private fun splitSelected() {
        val clip=clips.getOrNull(selected) ?: return
        if(!clip.video){Toast.makeText(this,"Split is for video clips",Toast.LENGTH_SHORT).show();return}
        val point=secondsField("Split at (seconds)")
        android.app.AlertDialog.Builder(this).setTitle("Split video into 2 files").setView(point).setPositiveButton("Export split") { _, _ ->
            val cutMs=((point.text.toString().toDoubleOrNull() ?: 0.0)*1000).toLong()
            val duration=player?.duration ?: -1L
            if(cutMs<=0 || duration<=0 || cutMs>=duration){Toast.makeText(this,"Enter a split time inside the video duration",Toast.LENGTH_SHORT).show();return@setPositiveButton}
            ClipExportTools.exportClip(this,clip.uri,0L,cutMs,"split_1")
            ClipExportTools.exportClip(this,clip.uri,cutMs,duration,"split_2")
        }.setNegativeButton("Cancel",null).show()
    }
    private fun moveSelected(direction:Int){
        val target=selected+direction
        if(target !in clips.indices){Toast.makeText(this,"Cannot move further",Toast.LENGTH_SHORT).show();return}
        val clip=clips.removeAt(selected);clips.add(target,clip);selected=target;renderPreview();renderTimeline()
    }
    private fun removeSelected(){
        if(clips.size<=1){Toast.makeText(this,"At least one clip must remain",Toast.LENGTH_SHORT).show();return}
        clips.removeAt(selected);selected=(selected.coerceAtMost(clips.lastIndex));renderPreview();renderTimeline()
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==AudioTrackTools.REQUEST_AUDIO&&resultCode==RESULT_OK){val uri=data?.data ?: return;try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};audioTracks.add(uri);renderAudioTracks();return};if(requestCode==addClipRequest&&resultCode==RESULT_OK){val uri=data?.getStringExtra("selected_uri")?.let(Uri::parse) ?: return;val video=data.getBooleanExtra("selected_video",true);clips.add(Clip(uri,video,uri.lastPathSegment ?: "Clip ${clips.size+1}"));selected=clips.lastIndex;renderPreview();renderTimeline()}}
    override fun onStop(){super.onStop();player?.release();player=null;audioPlayer?.release();audioPlayer=null}
}
