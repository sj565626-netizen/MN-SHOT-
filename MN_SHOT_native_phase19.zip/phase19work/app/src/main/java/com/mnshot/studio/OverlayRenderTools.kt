package com.mnshot.studio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

/** Phase 17 groundwork: rasterize a simple text/emoji overlay for later export compositing. */
object OverlayRenderTools {
    data class RenderedOverlay(val bitmap: Bitmap, val bounds: RectF)

    fun renderTextOrSticker(
        content: String,
        width: Int = 1080,
        height: Int = 240,
        textSizePx: Float = 72f,
        color: Int = android.graphics.Color.WHITE,
        bold: Boolean = true
    ): RenderedOverlay {
        val bitmap = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.textSize = textSizePx.coerceIn(12f, 240f)
            typeface = if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
            textAlign = Paint.Align.CENTER
            setShadowLayer(4f, 2f, 2f, android.graphics.Color.BLACK)
        }
        val baseline = (height / 2f) - (paint.ascent() + paint.descent()) / 2f
        canvas.drawText(content.take(120), width / 2f, baseline, paint)
        return RenderedOverlay(bitmap, RectF(0f, 0f, width.toFloat(), height.toFloat()))
    }
}
