package com.mnshot.studio

import android.net.Uri

/**
 * Phase 13 timeline-export groundwork.
 * Keeps the ordered video sources/range data in one place for a future
 * Media3 Composition exporter. This planner does NOT encode or mux media.
 */
object TimelineExportTools {
    data class Source(val uri: Uri, val startMs: Long = 0L, val endMs: Long? = null)
    data class Plan(val sources: List<Source>, val warnings: List<String>)

    fun plan(sources: List<Source>): Plan {
        val warnings = mutableListOf<String>()
        if (sources.isEmpty()) warnings += "Timeline is empty"
        sources.forEachIndexed { index, source ->
            if (source.startMs < 0) warnings += "Clip ${index + 1}: start time is negative"
            if (source.endMs != null && source.endMs <= source.startMs)
                warnings += "Clip ${index + 1}: end must be after start"
        }
        return Plan(sources.toList(), warnings)
    }
}
