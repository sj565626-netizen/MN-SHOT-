package com.mnshot.studio

import android.app.Activity
import android.content.Intent
import android.net.Uri

/** Phase 7: launch the Android document picker for a user-selected audio file. */
object AudioTrackTools {
    const val REQUEST_AUDIO = 770
    fun pickAudio(activity: Activity) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        activity.startActivityForResult(intent, REQUEST_AUDIO)
    }
}
