package com.mnshot.studio

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Native preview-only text/sticker overlay scaffold. Export compositing is not yet wired. */
object TextStickerTools {
    data class Overlay(val content: String, val isSticker: Boolean, val color: Int, val sizeSp: Float)

    fun addText(activity: Activity, onAdd: (Overlay) -> Unit) {
        val input = EditText(activity).apply { hint = "Enter text" }
        val sizes = EditText(activity).apply { hint = "Size (sp), default 28" }
        sizes.setText("28")
        val box = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 12, 24, 12); addView(input); addView(sizes) }
        AlertDialog.Builder(activity).setTitle("Add text overlay").setView(box)
            .setPositiveButton("Add") { _, _ ->
                val content = input.text.toString().trim()
                if (content.isNotEmpty()) onAdd(Overlay(content, false, Color.WHITE, (sizes.text.toString().toFloatOrNull() ?: 28f).coerceIn(12f, 96f)))
            }.setNegativeButton("Cancel", null).show()
    }

    fun addSticker(activity: Activity, onAdd: (Overlay) -> Unit) {
        val stickers = listOf("⭐", "❤️", "🔥", "😂", "🎉", "✨", "🌈", "👍", "🎬", "🎵")
        val list = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        stickers.forEach { emoji ->
            list.addView(TextView(activity).apply { text = emoji; textSize = 30f; gravity = Gravity.CENTER; setPadding(16, 8, 16, 8); setOnClickListener { onAdd(Overlay(emoji, true, Color.WHITE, 42f)); } })
        }
        AlertDialog.Builder(activity).setTitle("Choose sticker").setView(list).setNegativeButton("Close", null).show()
    }
}
