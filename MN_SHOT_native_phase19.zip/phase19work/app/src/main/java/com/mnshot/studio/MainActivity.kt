package com.mnshot.studio

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.graphics.drawable.GradientDrawable

/** Phase 2: first native Kotlin dashboard scaffold. Editor functionality is ported in later phases. */
class MainActivity : Activity() {
    private val bg = Color.rgb(20,20,28)
    private val panel = Color.rgb(35,35,52)
    private val accent = Color.rgb(92,112,255)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        buildDashboard()
    }
    private fun rounded(color:Int, radius:Float=22f): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius=radius }
    private fun buildDashboard() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18,18,18,18) }
        val top=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val mark=TextView(this).apply { text="MN  SHOT"; textSize=22f; setTextColor(Color.WHITE); setTypeface(null,1) }
        top.addView(mark, LinearLayout.LayoutParams(0,-2,1f))
        top.addView(makeButton("✦",panel){ toast("All features unlocked") })
        top.addView(makeButton("⚙",panel){ toast("Settings will be ported in a later phase") })
        root.addView(top)
        val hero=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(0,36,0,32) }
        hero.addView(TextView(this).apply { text="Cut. Shape. Shoot."; textSize=26f; setTextColor(Color.WHITE); setTypeface(null,1); gravity=Gravity.CENTER })
        hero.addView(TextView(this).apply { text="Your video studio, in your pocket."; textSize=14f; setTextColor(Color.LTGRAY); gravity=Gravity.CENTER; setPadding(0,8,0,0) })
        root.addView(hero)
        label(root,"CREATE NEW")
        val card=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(8,12,8,12); background=rounded(panel) }
        card.addView(createTile("▶","Video") { pick("video/*") }, LinearLayout.LayoutParams(0,120,1f))
        card.addView(createTile("▧","Photo") { pick("image/*") }, LinearLayout.LayoutParams(0,120,1f))
        card.addView(createTile("▦","Collage") { pick("image/*") }, LinearLayout.LayoutParams(0,120,1f))
        root.addView(card)
        label(root,"WHAT'S NEW")
        val news= listOf("Animations" to "In · Out · Combo · Loop", "Opacity & Mask" to "Circle · Heart · Star", "Crop & Replace" to "Zoom · Pan · Ratios", "Quick Share" to "Share exported videos", "Photo" to "Slideshows · Freeze", "PIP & Collage" to "Voice · Enhance · Auto cut")
        val scroll=ScrollView(this)
        val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        news.forEach { (a,b)->
            val item=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,14,16,14); background=rounded(panel); setOnClickListener { toast("$a — details will be ported") } }
            item.addView(TextView(this).apply { text=a; textSize=16f; setTextColor(Color.WHITE); setTypeface(null,1) })
            item.addView(TextView(this).apply { text=b; textSize=12f; setTextColor(Color.LTGRAY) })
            list.addView(item,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 })
        }
        scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }
    private fun label(parent:LinearLayout,s:String){ parent.addView(TextView(this).apply{text=s; textSize=12f; setTextColor(Color.LTGRAY); setTypeface(null,1); setPadding(0,16,0,10)}) }
    private fun createTile(symbol:String,name:String,action:()->Unit):LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setOnClickListener{action()}; addView(TextView(this@MainActivity).apply{text=symbol; textSize=30f; setTextColor(accent); gravity=Gravity.CENTER}); addView(TextView(this@MainActivity).apply{text=name; textSize=15f; setTextColor(Color.WHITE); setTypeface(null,1); gravity=Gravity.CENTER; setPadding(0,10,0,0)}) }
    private fun makeButton(s:String,c:Int,action:()->Unit):TextView=TextView(this).apply { text=s; textSize=20f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=rounded(c,18f); setPadding(16,12,16,12); setOnClickListener{action()} }
    private fun pick(mime:String){ val mode=if(mime=="video/*") "video" else if(mime=="image/*") "photo" else "all"; startActivityForResult(Intent(this,GalleryActivity::class.java).putExtra("mode",mode),501) }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==501 && resultCode==RESULT_OK){ val uri=data?.getStringExtra("selected_uri"); if(uri!=null) startActivity(Intent(this,EditorActivity::class.java).putExtra("selected_uri",uri).putExtra("selected_video",data?.getBooleanExtra("selected_video",true) ?: true)) } }
    private fun toast(s:String){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show() }
}
