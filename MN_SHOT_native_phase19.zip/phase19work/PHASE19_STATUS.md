# Phase 19 — Export save destination + build workflow

Concrete changes in this phase:
- Added `ExportSaveTools` to copy successful multi-clip/audio renders into the Android Movies collection (`Movies/MN SHOT`) via MediaStore on Android 10+.
- Multi-clip and audio composition exporters now publish their completed render instead of leaving it only in the app-private directory.
- Added GitHub Actions workflow that installs Gradle 8.9 and JDK 17, runs `assembleDebug`, and uploads the APK artifact.

Limitations: Android build was not run in this environment. Single-clip export and trim/split exporters may still save to app-private storage. This is not a full native conversion or completed editor.
