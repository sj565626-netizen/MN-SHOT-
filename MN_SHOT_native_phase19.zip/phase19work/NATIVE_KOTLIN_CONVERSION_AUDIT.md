# MN Shot Studio — Native Kotlin conversion audit (Phase 1)

## Source inventory
- `MainActivity.java`: Android media gallery queries, permission handling, thumbnails, image save, WebView integration and Media3 WebM-to-MP4 export.
- `index.html`, `mnshot.css`, `mnshot.js`: UI and editor logic (these are the web layer that must be reimplemented, not simply wrapped).
- `Media3 Transformer`: used for MP4 conversion/export path.

## JavaScript bridge contract detected
- `shareLastVideo`
- `cancelNativeMp4Export`
- `hasPermission`
- `requestPermission`
- `openSettings`
- `listAlbums`
- `listMedia`
- `requestThumbs`
- `setPicked`
- `saveImage`

## Conversion phases
1. **UI parity:** port dashboard and all editor panels to native Kotlin UI (Compose or Views), preserving layout, labels, colors, icons and interaction flow.
2. **Media library:** native MediaStore queries, albums, thumbnails, selected media and permission UX.
3. **Editor state/timeline:** clip model, timeline, playhead, undo/redo and project state.
4. **Editing tools:** transitions, text, stickers, crop, adjustments, masks, PIP, freeze, audio and effects.
5. **Export:** native Media3 pipeline and progress/cancel/share/save.
6. **Parity testing:** compare screen-by-screen and test each feature; no claim of 100% parity before testing.

## Important
This is an audit only, not a finished native conversion. The original web assets are retained as visual/behavioral reference during the staged port.
