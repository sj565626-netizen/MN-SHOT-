# Native Phase 5 — Clip list and timeline management

Implemented in this phase:
- Editor stores selected media as a clip entry.
- Native Add Clip opens the Kotlin gallery and appends another media entry.
- Timeline tiles show clip index/type/name and can be selected.
- Move selected clip left/right within the clip list.
- Remove selected clip (keeps at least one clip).
- Selecting a video clip loads it into Media3 preview; photo clips show an image preview.

Not implemented / not verified:
- Trim, split, transitions, audio mixing, effects and export remain placeholders.
- Clip durations and a time-based timeline ruler are not implemented.
- Android Gradle build/device testing has not been run in this environment.
- UI is a native scaffold and is not yet a pixel-identical reproduction of the original web UI.
