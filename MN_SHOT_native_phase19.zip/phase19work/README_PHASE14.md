# Phase 14 — Multi-clip sequential composition (experimental)

Adds `MultiClipExportTools`, which constructs a Media3 `Composition` from ordered clip sources and starts a sequential MP4 export. Each clip supports optional start/end trims. Audio is retained per source.

This is experimental code and has not been compiled or tested on an Android device. It is not yet wired to the editor UI. Photos, external audio mixing, overlays, transitions, filters and full timeline UI integration are not supported by this phase. Review/compile against the project's Media3 1.5.1 dependency before relying on it.
