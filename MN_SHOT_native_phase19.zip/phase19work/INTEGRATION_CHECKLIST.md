# MN SHOT Integration Checklist

- [ ] GitHub Actions debug build succeeds
- [ ] Install debug APK on physical device
- [ ] Gallery/media picker works with limited selection permissions
- [ ] Video playback and photo preview
- [ ] Clip add/select/reorder/remove
- [ ] Trim and split range validation
- [ ] Audio picker and preview
- [ ] Text and sticker preview
- [ ] Filter and adjustment preview
- [ ] Export selected clip and trimmed range
- [ ] Verify output file playback, dimensions, and duration
- [ ] Confirm storage cleanup and failure messaging
- [ ] Test app rotation/background/return
