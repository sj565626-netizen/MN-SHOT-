# Phase 12 — Integration & Build Workflow

This phase adds a GitHub Actions workflow for assembling a debug APK on GitHub-hosted Ubuntu.

## Build in GitHub
1. Upload/push the project contents to a GitHub repository on the `main` branch.
2. Open **Actions** and select **MN SHOT Android Build**.
3. Run workflow or push to `main`.
4. If it succeeds, download the `MN-SHOT-debug-apk` artifact from that run.

## Local build
Requires JDK 17, Android SDK platform 35 and Gradle 8.9:

```bash
gradle assembleDebug
```

## Known limitations / test checklist
- This project has not been compiled or device-tested in this handoff.
- Export scaffolding currently exports a selected clip/range, not a full multi-clip timeline.
- Audio mixing, text/sticker compositing, filter grading, and adjustment rendering are not yet guaranteed to be included in export.
- Test gallery permission handling on Android 13/14/15, media selection, playback, trim ranges, export success/failure, and orientation changes.
- Verify output codec compatibility and available storage on a physical device.

Workflow success is the first automated build verification; it is not a substitute for device tests.
