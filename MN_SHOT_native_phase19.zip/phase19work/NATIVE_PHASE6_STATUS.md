# Phase 6 — Native Trim/Split export code

- Added native Media3 clipping/export helper (`ClipExportTools.kt`).
- Trim dialog accepts start/end seconds and exports a separate MP4 file.
- Split dialog exports two separate MP4 segments at the chosen split point (using the preview player's duration).
- Source media is not modified; output files are saved in app-specific external storage.
- Trim/Split are video-only in this phase.

## Validation
Not Gradle-built or device-tested in this environment. Media3 API compatibility, output file visibility and export edge cases still require Android build/device testing. This is code implementation, not verified build status.
