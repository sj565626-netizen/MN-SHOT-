# MN SHOT native Kotlin conversion — Phase 2

Implemented in this phase:
- Kotlin Android plugin configured.
- Added a programmatic Android-native `MainActivity.kt` dashboard scaffold (no WebView used by this Activity).
- Dashboard has native create tiles for Video, Photo and Collage, headings, and What's New list.
- Video and photo tiles invoke Android system content picker.
- Original Java WebView activity retained as `MainActivity_WebView_legacy.java` for reference only; it is not the launcher activity.

Not yet ported/working in native form:
- Editor canvas and preview, timeline and clip model, audio editing, effects, undo/redo, native export pipeline, drafts, and the exact detailed styling/icon set.
- The dashboard is a first scaffold, not a pixel-identical recreation yet.

This phase is not claimed to be a fully functional editor or verified APK. Build verification requires an Android/Gradle build environment.
